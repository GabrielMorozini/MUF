extends Node3D
## PSX Bystanders showcase: every person in every look, on a stage of the free room pieces in the hall's finishes.
##
## Left / Right   person          Up / Down   look            the buttons: a clip each, the accessories on and off
## T  the head turns to the camera on / off      P  PSX look      O  smooth / stepped (15) / stepped (12)
## L  lamp / daylight      F1  back to the waiting hall (or room)      Esc  the closing screen      Mouse drag orbits,
## the wheel zooms. (2.0: a person without a clip, a minor's Hit or Fall, shows its button greyed.)
## A clip that needs furniture shows a plain stand-in for it, at the heights the clips fit (CordatixBystanderSpot): a
## seat (the station bench if the project has it), a desk, a counter, a wall. A clip that moves the body plays in place.

const DATA := "res://cordatix/psx_bystanders/data/people.json"
const PEOPLE_DIR := "res://cordatix/psx_bystanders/people/"
const PROPS := "res://cordatix/psx_bystanders/props/"
const ROOM_PIECES := "res://cordatix/haunted_psx_spaces/pieces/"
const FINISHES := "res://cordatix/psx_bystanders/finishes/materials/"
const FONT := "res://cordatix/shared/fonts/IBMPlexMono-Regular.ttf"
const PSX := preload("res://cordatix/shared/shaders/psx_materials.gd")
const CLIPS := ["Idle", "IdleShift", "IdleWait", "LookAround", "LookBehind", "Walk", "Stroll", "Run", "Flee",
	"TurnLeft", "TurnRight", "Talk", "Listen", "Nod", "ShakeHead", "Wave", "Point", "PhoneLook", "PhoneCall", "SitDown",
	"Sit", "SitPhone", "SitType", "StandUp", "CounterIdle", "LeanWall", "Startle", "Cower", "BackAway", "Hit", "Fall",
	"SitLean", "SitTalk", "PhoneWalk", "Carry", "CarryIdle"]
const SEATED := ["SitDown", "Sit", "SitPhone", "SitType", "StandUp", "SitLean", "SitTalk"]
const ORDER := ["office_worker", "businessman", "security_guard", "service_worker", "young_man", "young_woman",
	"medical_worker", "old_woman", "old_man", "traveller", "girl", "boy", "teen_girl", "teen_boy", "police_officer",
	"firefighter", "paramedic", "chef", "mechanic", "elderly_man"]
const CLOSING := "res://cordatix/psx_bystanders/demo/closing_screen.gd"
const STAGE := Vector3(2.0, 0.0, 2.6)
const FREE_WALL := "wallpaper_motel_rose"
const FREE_FLOOR := "carpet_motel_tumbling"
const FREE_CEILING := "ceiling_plaster_aged"

var data: Dictionary
var keys: Array = []
var index := 0
var look := 1
var person: CordatixBystander
var clip := "Idle"
var camera: Camera3D
var env: WorldEnvironment
var lamp: OmniLight3D
var sun: DirectionalLight3D
var label: Label
var acc_box: VBoxContainer
var clip_buttons := {}
var seat: Node3D
var desk: Node3D
var counter: Node3D
var wall: Node3D
var yaw := 20.0
var pitch := 8.0
var dist_scale := 1.0
var stepped := 0
var psx := false
var looking := true
var daylight := false
var _drag := false
var closing: CanvasLayer = null


func _ready() -> void:
	data = JSON.parse_string(FileAccess.get_file_as_string(DATA))
	# (2.0) the people whose scenes are there (the Godot download in two: its first part alone has the first ten)
	keys = data.keys().filter(func(k): return ResourceLoader.exists(PEOPLE_DIR + k + ".tscn"))
	keys.sort_custom(func(a, b): return _order(a) < _order(b))
	_build_stage()
	_build_ui()
	show_person(keys[0], 1)
	if ResourceLoader.exists(CLOSING):
		closing = load(CLOSING).new()
		# the full pack's page, or the free sampler's in its own project (the hall's constants)
		var Hall = load("res://cordatix/psx_bystanders/demo/hall.gd")
		var full: bool = ResourceLoader.exists(Hall.FULL_ONLY)
		closing.pack_name = Hall.PACK_NAME if full else Hall.SAMPLER_NAME
		closing.rate_url = Hall.RATE_URL if full else Hall.SAMPLER_RATE_URL
		closing.font = load(FONT)
		add_child(closing)


func _order(k: String) -> int:
	var i := ORDER.find(k)
	return i if i >= 0 else 100


# ------------------------------------------------------------------------------------------------ stage
func _room_piece(n: String, cell: Vector2i, rot_deg := 0.0, wall_finish := "wall_paint_station") -> Node3D:
	var p: Node3D = load(ROOM_PIECES + n + ".tscn").instantiate()
	p.position = Vector3(cell.x * 2.0, 0.0, cell.y * 2.0)
	p.rotation.y = deg_to_rad(rot_deg)
	add_child(p)
	var to := {FREE_WALL: wall_finish, FREE_FLOOR: "floor_terrazzo_station", FREE_CEILING: "ceiling_paint_station"}
	for mi in p.find_children("*", "MeshInstance3D", true, false):
		var mesh: Mesh = (mi as MeshInstance3D).mesh
		for k in mesh.get_surface_count():
			var m := mesh.surface_get_material(k)
			var name := "" if m == null else m.resource_name
			if to.has(name) and ResourceLoader.exists(FINISHES + to[name] + ".tres"):
				(mi as MeshInstance3D).set_surface_override_material(k, load(FINISHES + to[name] + ".tres"))
	return p


func _stand_in(size: Vector3, centre: Vector3) -> Node3D:
	## A plain grey block at the height a clip fits: not an asset of the pack, only where the clip's hands or body go.
	var b := CSGBox3D.new()
	b.size = size
	b.position = centre
	var m := StandardMaterial3D.new()
	m.albedo_color = Color(0.42, 0.43, 0.45)
	m.roughness = 1.0
	b.material = m
	add_child(b)
	return b


func _build_stage() -> void:
	# a 3 x 4 room, its south end open to the camera, the back wall tiled as the hall's behind its counters
	for i in 3:
		for j in 4:
			_room_piece("floor", Vector2i(i, j))
			_room_piece("ceiling", Vector2i(i, j))
	for i in 3:
		_room_piece("wall", Vector2i(i, 0), 0.0, "wall_tile_station")
	for j in 4:
		_room_piece("wall_window" if j == 1 else "wall", Vector2i(0, j), 90.0)
		_room_piece("wall", Vector2i(2, j), -90.0)
	_room_piece("window", Vector2i(0, 1), 90.0)
	env = WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.background_color = Color(0.03, 0.035, 0.04)
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.ambient_light_color = Color(0.2, 0.21, 0.25)
	e.ambient_light_energy = 0.5
	env.environment = e
	add_child(env)
	camera = Camera3D.new()
	camera.fov = 50.0
	camera.near = 0.05
	add_child(camera)
	camera.current = true
	lamp = OmniLight3D.new()
	lamp.light_color = Color(1.0, 0.9, 0.74)
	lamp.light_energy = 1.2
	lamp.omni_range = 7.0
	lamp.position = STAGE + Vector3(-0.8, 2.4, 1.2)
	add_child(lamp)
	sun = DirectionalLight3D.new()
	sun.light_color = Color(0.92, 0.95, 1.0)
	sun.light_energy = 0.9
	sun.rotation_degrees = Vector3(-35, 30, 0)
	add_child(sun)
	# the stand-ins: the person faces +Z (the camera) at STAGE
	var bench_path := PROPS + "station_bench.tscn"
	if ResourceLoader.exists(bench_path):
		seat = load(bench_path).instantiate()
		seat.rotation.y = PI
		add_child(seat)
		var mark: Node3D = seat.get_node_or_null("Seat2")
		if mark:
			seat.global_position += STAGE - mark.global_position
	else:
		seat = _stand_in(Vector3(0.5, 0.45, 0.42), STAGE + Vector3(0, 0.225, -(CordatixBystanderSpot.SEAT_FRONT + 0.21)))
	desk = _stand_in(Vector3(1.1, CordatixBystanderSpot.DESK_HEIGHT, 0.55),
		STAGE + Vector3(0, CordatixBystanderSpot.DESK_HEIGHT * 0.5, CordatixBystanderSpot.DESK_EDGE + 0.275))
	counter = _stand_in(Vector3(1.3, CordatixBystanderSpot.COUNTER_HEIGHT, 0.45),
		STAGE + Vector3(0, CordatixBystanderSpot.COUNTER_HEIGHT * 0.5, CordatixBystanderSpot.COUNTER_EDGE + 0.225))
	wall = _stand_in(Vector3(1.6, 2.3, 0.1), STAGE + Vector3(0, 1.15, -(CordatixBystanderSpot.WALL_BACK + 0.05)))


func _furniture() -> void:
	seat.visible = clip in SEATED
	desk.visible = clip == "SitType"
	counter.visible = clip == "CounterIdle"
	wall.visible = clip == "LeanWall"


# ------------------------------------------------------------------------------------------------ UI
func _font_label(size: int, colour: Color) -> Label:
	var l := Label.new()
	l.add_theme_font_override("font", load(FONT))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", colour)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	l.add_theme_constant_override("shadow_offset_x", 1)
	l.add_theme_constant_override("shadow_offset_y", 1)
	return l


func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	label = _font_label(14, Color(0.93, 0.91, 0.84))
	label.position = Vector2(16, 12)
	layer.add_child(label)
	var help := _font_label(12, Color(0.7, 0.68, 0.6))
	help.text = "Left/Right person   Up/Down look   T head to the camera   P PSX   O stepped   L light   F1 back   " \
		+ "drag orbit   wheel zoom"
	help.anchor_top = 1.0
	help.anchor_bottom = 1.0
	help.position = Vector2(16, -28)
	layer.add_child(help)
	var panel := PanelContainer.new()
	panel.anchor_left = 1.0
	panel.anchor_right = 1.0
	panel.offset_left = -300
	panel.offset_top = 12
	panel.offset_right = -12
	layer.add_child(panel)
	var col := VBoxContainer.new()
	panel.add_child(col)
	col.add_child(_font_label(13, Color(0.93, 0.91, 0.84)))
	(col.get_child(0) as Label).text = "Clips"
	var grid := GridContainer.new()
	grid.columns = 3
	col.add_child(grid)
	var font: FontFile = load(FONT)
	for c in CLIPS:
		var b := Button.new()
		b.text = c
		b.add_theme_font_override("font", font)
		b.add_theme_font_size_override("font_size", 11)
		b.focus_mode = Control.FOCUS_NONE
		b.pressed.connect(play_clip.bind(c))
		grid.add_child(b)
		clip_buttons[c] = b
	var acc_title := _font_label(13, Color(0.93, 0.91, 0.84))
	acc_title.text = "Accessories"
	col.add_child(acc_title)
	acc_box = VBoxContainer.new()
	col.add_child(acc_box)


func _accessory_buttons() -> void:
	for c in acc_box.get_children():
		c.queue_free()
	var font: FontFile = load(FONT)
	for a in person.accessory_keys():
		if a == "phone" or a == "box":
			var l := _font_label(11, Color(0.7, 0.68, 0.6))
			l.text = "phone: in the phone clips" if a == "phone" else "box: in Carry and CarryIdle"
			acc_box.add_child(l)
			continue
		var cb := CheckButton.new()
		cb.text = a
		cb.add_theme_font_override("font", font)
		cb.add_theme_font_size_override("font_size", 11)
		cb.focus_mode = Control.FOCUS_NONE
		cb.button_pressed = person.wears(a)
		cb.toggled.connect(func(on): person.set_accessory(a, on))
		acc_box.add_child(cb)


# ------------------------------------------------------------------------------------------------ API
func show_person(key: String, n := 1) -> void:
	if person:
		person.queue_free()
	index = keys.find(key)
	var looks: Array = data[key].get("looks", [])
	look = clampi(n, 1, maxi(looks.size(), 1))
	person = load(PEOPLE_DIR + key + ".tscn").instantiate()
	person.behaviour_enabled = false
	person.look = look
	person.psx = psx
	person.stepped_fps = [0.0, 15.0, 12.0][stepped]
	person.look_at_player = looking
	person.pace_spread = 0.0
	person.position = STAGE
	person.rotation.y = PI          # facing +Z, the camera
	add_child(person)
	_accessory_buttons()
	for c in clip_buttons:
		# (2.0) a clip this person does not have (a minor's Hit and Fall) greyed out
		(clip_buttons[c] as Button).disabled = not person.has_clip(c)
	play_clip(clip if person.has_clip(clip) else "Idle")


func play_clip(c: String) -> void:
	clip = c
	if person and person.anim and person.anim.has_animation(c):
		person.position = STAGE          # BackAway carries the person back half a metre: each play from the mark
		person.reset_physics_interpolation()
		person.play(c, 0.15)
	_furniture()


func set_psx(on: bool) -> void:
	psx = on
	if person:
		person.psx = on
	for n in find_children("*", "MeshInstance3D", true, false):
		if person and person.is_ancestor_of(n):
			continue
		for k in (n as MeshInstance3D).mesh.get_surface_count():
			var key := "std%d" % k
			var m: Material = n.get_active_material(k)
			if on and m is StandardMaterial3D:
				n.set_meta(key, [m, n.get_surface_override_material(k)])
				n.set_surface_override_material(k, PSX.to_psx(m))
			elif not on and n.has_meta(key):
				n.set_surface_override_material(k, n.get_meta(key)[1])
				n.remove_meta(key)


func set_daylight(on: bool) -> void:
	daylight = on
	sun.visible = on
	lamp.light_energy = 0.7 if on else 1.2
	env.environment.ambient_light_energy = 0.9 if on else 0.5


func frame_camera(y: float, p: float, d: float) -> void:
	yaw = y
	pitch = p
	dist_scale = d


# ------------------------------------------------------------------------------------------------ loop
func _process(_delta: float) -> void:
	if person == null:
		return
	var d: Dictionary = data[keys[index]]
	var h := float(d.get("height", 1.7))
	var focus := STAGE + Vector3(0, h * (0.4 if clip in SEATED or clip in ["Cower", "Fall"] else 0.55), 0)
	var dist := h * 1.5 * dist_scale + 0.6
	var rot := Basis(Vector3.UP, deg_to_rad(yaw)) * Basis(Vector3.RIGHT, deg_to_rad(-pitch))
	camera.position = focus + rot * Vector3(0, 0, dist)
	camera.look_at(focus, Vector3.UP)
	var lk: Dictionary = d["looks"][look - 1] if look - 1 < d.get("looks", []).size() else {}
	label.text = "%s    look %d of %d: %s (%s)    %s    %d triangles\n%s%s%s%s" % [d.get("name", keys[index]), look,
		d.get("looks", []).size(), lk.get("name", ""), lk.get("role", ""), clip, int(lk.get("triangles", 0)),
		lk.get("note", ""), "    head to the camera" if looking else "", "    PSX" if psx else "",
		["", "    stepped 15", "    stepped 12"][stepped]]
	for c in clip_buttons:
		(clip_buttons[c] as Button).modulate = Color(1.0, 0.85, 0.4) if c == clip else Color(1, 1, 1)


func _unhandled_input(ev: InputEvent) -> void:
	if ev is InputEventMouseButton:
		if ev.button_index == MOUSE_BUTTON_LEFT:
			_drag = ev.pressed
		elif ev.button_index == MOUSE_BUTTON_WHEEL_UP and ev.pressed:
			dist_scale = maxf(0.35, dist_scale * 0.9)
		elif ev.button_index == MOUSE_BUTTON_WHEEL_DOWN and ev.pressed:
			dist_scale = minf(2.5, dist_scale * 1.1)
	elif ev is InputEventMouseMotion and _drag:
		yaw -= ev.relative.x * 0.3
		pitch = clampf(pitch + ev.relative.y * 0.2, -10.0, 60.0)
	elif ev is InputEventKey and ev.pressed and not ev.echo:
		var n: int = data[keys[index]].get("looks", []).size()
		match ev.keycode:
			KEY_RIGHT:
				show_person(keys[(index + 1) % keys.size()], 1)
			KEY_LEFT:
				show_person(keys[(index - 1 + keys.size()) % keys.size()], 1)
			KEY_DOWN:
				show_person(keys[index], look % n + 1)
			KEY_UP:
				show_person(keys[index], (look - 2 + n) % n + 1)
			KEY_T:
				looking = not looking
				person.look_at_player = looking
			KEY_P:
				set_psx(not psx)
			KEY_O:
				stepped = (stepped + 1) % 3
				person.stepped_fps = [0.0, 15.0, 12.0][stepped]
			KEY_L:
				set_daylight(not daylight)
			KEY_F1:
				get_tree().change_scene_to_file(_back())
			KEY_ESCAPE:
				if closing:
					closing.toggle()


func _back() -> String:
	## F1: back to the scene that opened the showcase (the waiting hall, or the free sampler's room); opened on its own,
	## the project's main scene if it is one of the demo's, else the hall.
	var back := String(get_tree().root.get_meta("bystanders_back", ""))
	if back == "":
		var main := String(ProjectSettings.get_setting("application/run/main_scene", ""))
		back = main if main.begins_with("res://cordatix/psx_bystanders/demo/") \
			else "res://cordatix/psx_bystanders/demo/hall.tscn"
	return back
