extends Node3D
## PSX Bystanders demo: a small bus station's waiting hall of the free Haunted PSX room pieces in this pack's own
## finishes, with its benches, ticket window, newsstand and departures board, and a crowd of the pack's people in it
## (`layout` "room": a small waiting room with two benches, the free sampler's main scene).
## WASD move, mouse look, Shift run, E talk to the one you face (E again, or walk off, to end), X scare (once: those
## near you back away, the others start; again: they flee), C calm, L day / night, N a new crowd, R the same crowd
## again, P PSX look, O stepped animation, F1 the showcase, Esc the closing screen (Rate on itch, Back, Quit).
## 2.0: by day the crowd has its children and teenagers (families on the benches, schoolmates walking through), by night
## nobody under 18; neighbours on a bench talk in turn, some walk with a box or looking at their phones. It opens by day.
##
## A layout (LAYOUTS below) is rooms of 2 m cells, doorways, windows, each room's finishes (a side of a room can have
## its own wall), the props, the lamps and the room's own spots. The crowd (CordatixBystanderCrowd) fills every spot it
## has: the props' own (a bench's seats, the ticket window's counter and its clerk's desk, the kiosk's counter and its
## clerk's place, the board's reader) and the room's (a line at the ticket window, a pair who talk, walls to lean on,
## places to wait). A prop the project does not have is left out, and so are its spots.

const PDIR := "res://cordatix/psx_bystanders/"
const PROPS := "res://cordatix/psx_bystanders/props/"
const ROOM_PIECES := "res://cordatix/haunted_psx_spaces/pieces/"
const FINISHES := "res://cordatix/psx_bystanders/finishes/materials/"
const FONT := "res://cordatix/shared/fonts/IBMPlexMono-Regular.ttf"
const PSX := preload("res://cordatix/shared/shaders/psx_materials.gd")
const Player := preload("res://cordatix/psx_bystanders/demo/player.gd")
## The free pieces' surfaces a room's finishes replace.
const FREE_WALL := "wallpaper_motel_rose"
const FREE_FLOOR := "carpet_motel_tumbling"
const FREE_CEILING := "ceiling_plaster_aged"
const FREE_GLASS := "window_glass_night"

## rooms: name -> [i0, j0, i1, j1] inclusive cells (x = 2 i, z = 2 j); doors: [room a, room b, cell i, cell j, side,
## door] (room b "": a doorway with nothing behind it; door "door": the free wooden door in it); windows: [cell i, cell
## j, side]; side n (-z), s (+z), w (-x), e (+x); finishes: room -> {wall, n / s / w / e (a side's own wall), floor,
## ceiling, day (the windows' glass by day)}, materials in finishes/materials/ ("" or missing: the free piece's own);
## props: [key, x, z, yaw degrees (its front faces -z at 0, +z at 180, -x at 90, +x at 270), {spot name: who}];
## lamps: [x, z] (a station lamp: its origin on the floor under its rose); spots: [name, kind, x, z, yaw, {ahead (a
## spot's name, or a prop's "key/Spot"), partner, look_at [x, y, z], who, phone}]; spawn: [x, z, yaw]; crowd: its
## fill, max_same and wanderers (CordatixBystanderCrowd).
const LAYOUTS := {
	"hall": {
		"rooms": {"hall": [0, 0, 6, 4]},
		"doors": [
			["hall", "", 3, 4, "s", ""],          # the way in from the street
			["hall", "", 6, 2, "e", ""],          # the way out to the buses
		],
		"windows": [[1, 4, "s"], [5, 4, "s"], [0, 1, "w"], [0, 3, "w"], [6, 1, "e"], [6, 3, "e"]],
		"finishes": {
			"hall": {"wall": "wall_paint_station", "n": "wall_tile_station", "floor": "floor_terrazzo_station",
				"ceiling": "ceiling_paint_station", "day": "window_glass_day"},
		},
		"props": [
			["ticket_booth", 2.0, -0.09, 180.0, {"Clerk": ["office_worker", "service_worker", "businessman"]}],
			["departures_board", 6.0, -0.9, 180.0, {}],
			["newsstand_kiosk", 10.4, 0.6, 180.0, {"Clerk": ["service_worker", "young_woman", "young_man", "old_man"]}],
			["station_bench", 5.0, 4.0, 0.0, {}],
			["station_bench", 8.0, 4.0, 0.0, {}],
			["station_bench", 5.0, 4.6, 180.0, {}],
			["station_bench", 8.0, 4.6, 180.0, {}],
		],
		# four lamps a row, the first west of the ticket booth (with three a row, its west face was black at night)
		"lamps": [[0.4, 2.2], [4.4, 2.2], [8.4, 2.2], [12.4, 2.2], [0.4, 6.2], [4.4, 6.2], [8.4, 6.2], [12.4, 6.2]],
		"spots": [
			["Line1", "QUEUE", 2.0, 1.85, 0.0, {"ahead": "ticket_booth/Counter"}],
			["Line2", "QUEUE", 2.0, 2.75, 0.0, {"ahead": "Line1"}],
			["Line3", "QUEUE", 2.0, 3.65, 0.0, {"ahead": "Line2"}],
			["Line4", "QUEUE", 2.0, 4.55, 0.0, {"ahead": "Line3"}],
			["TalkA", "TALK", 10.4, 7.4, 270.0, {"partner": "TalkB"}],
			["TalkB", "TALK", 11.5, 7.4, 90.0, {"partner": "TalkA"}],
			["LeanWest", "LEAN", -0.7, 4.0, 270.0, {}],
			["LeanSouth", "LEAN", 9.0, 8.7, 0.0, {}],
			["WaitBuses", "WAIT", 11.3, 2.7, 270.0, {"phone": 0.5}],
			["WaitStreet", "WAIT", 7.2, 7.5, 0.0, {"phone": 0.5}],
		],
		"spawn": [6.0, 8.2, 0.0],
		# (2.0) six wanderers, four in ten of those off the phone carrying a box, a third on their phones: the day's
		# hall shows the new clips (with five, a quarter and 0.3, the store's day walk saw no box and no phone walk in its
		# first three seeds)
		"crowd": {"fill": 0.85, "max_same": 2, "wanderers": 6, "carry": 0.4, "phone_walk": 0.35},
		# (2.0) neighbours on a bench who talk in turn when both are seated: [bench (its order in props), seat, seat]
		"pairs": [[3, "Seat1", "Seat2"], [4, "Seat2", "Seat3"], [5, "Seat1", "Seat2"], [6, "Seat2", "Seat3"]],
	},
	"room": {
		"rooms": {"room": [0, 0, 2, 1]},
		"doors": [
			["room", "", 1, 1, "s", ""],          # the way in
		],
		"windows": [[0, 0, "w"], [2, 0, "e"]],
		"finishes": {
			"room": {"wall": "wall_paint_station", "floor": "floor_terrazzo_station",
				"ceiling": "ceiling_paint_station", "day": "window_glass_day"},
		},
		"props": [
			["station_bench", 0.9, -0.62, 180.0, {}],
			["station_bench", 3.5, -0.62, 180.0, {}],
		],
		"lamps": [[0.9, 0.9], [3.5, 0.9]],
		"spots": [
			["TalkA", "TALK", 2.0, 1.6, 270.0, {"partner": "TalkB"}],
			["TalkB", "TALK", 3.1, 1.6, 90.0, {"partner": "TalkA"}],
			["LeanEast", "LEAN", 4.7, 2.0, 90.0, {}],
			["WaitDoor", "WAIT", 0.4, 2.3, 0.0, {"phone": 0.5}],
		],
		"spawn": [2.0, 2.5, 0.0],
		"crowd": {"fill": 1.0, "max_same": 2, "wanderers": 0},
		"pairs": [[0, "Seat1", "Seat2"]],
	},
}

const LAMP := {"energy": 1.0, "range": 7.0, "color": Color(1.0, 0.9, 0.74)}
## The closing screen (the series' template, copied unchanged): Esc opens it, "Rate on itch" opens the page's rating form.
const CLOSING := "res://cordatix/psx_bystanders/demo/closing_screen.gd"
const PACK_NAME := "PSX Bystanders NPC Pack"
const RATE_URL := "https://cordatix.itch.io/psx-bystanders-npc-pack/rate"
## The free sampler's (its project has two of the people: the businessman is the full pack's): its own page's form.
const SAMPLER_NAME := "PSX Bystanders NPC Pack Free Sampler"
const SAMPLER_RATE_URL := "https://cordatix.itch.io/psx-bystanders-npc-pack-free/rate"
const FULL_ONLY := "res://cordatix/psx_bystanders/people/businessman.tscn"

## Which layout: "hall" (the waiting hall, the full pack's main scene) or "room" (a small waiting room with two
## benches: the free sampler's main scene, demo/room.tscn).
@export var layout := "hall"

var L: Dictionary

var player: CharacterBody3D
var crowd: CordatixBystanderCrowd
var region: NavigationRegion3D
var env: WorldEnvironment
var label: Label
var day := false
var psx := false
var stepped := 0
var talking: CordatixBystander = null
var _scared := -100.0
var _clock := 0.0
var _glass: Array = []           # [MeshInstance3D, surface]: the windows' glass, night or day
var _lamps: Array = []           # the lamps' lights
var _daylight: Array = []        # the windows' light by day
var _events: Array = []
var closing: CanvasLayer = null


func _ready() -> void:
	L = LAYOUTS.get(layout, LAYOUTS["hall"])
	_environment()
	region = NavigationRegion3D.new()
	add_child(region)
	_build()
	_props_and_spots()
	_bake()
	player = Player.new()
	var sp: Array = L["spawn"]
	player.position = Vector3(sp[0], 0.05, sp[1])
	player.rotation.y = deg_to_rad(sp[2])
	add_child(player)
	_ui()
	set_day(true)                      # (2.0) it opens by day: the families are there (set_day fills the crowd)
	Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	if ResourceLoader.exists(CLOSING):
		closing = load(CLOSING).new()
		var full := ResourceLoader.exists(FULL_ONLY)
		closing.pack_name = PACK_NAME if full else SAMPLER_NAME
		closing.rate_url = RATE_URL if full else SAMPLER_RATE_URL
		closing.font = load(FONT)
		add_child(closing)


# -------------------------------------------------------------------------------------------- the room
func _environment() -> void:
	env = WorldEnvironment.new()
	var e := Environment.new()
	e.background_mode = Environment.BG_COLOR
	e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	e.fog_enabled = true
	env.environment = e
	add_child(env)


func _room_of(i: int, j: int) -> String:
	for r in L["rooms"]:
		var b: Array = L["rooms"][r]
		if i >= b[0] and i <= b[2] and j >= b[1] and j <= b[3]:
			return r
	return ""


func _put(n: String, i: int, j: int, side := "n") -> Node3D:
	var p: Node3D = load(ROOM_PIECES + n + ".tscn").instantiate()
	p.position = Vector3(i * 2.0, 0.0, j * 2.0)
	p.rotation.y = deg_to_rad({"n": 0.0, "w": 90.0, "e": -90.0, "s": 180.0}[side])
	region.add_child(p)
	return p


func _build() -> void:
	var steps := {"n": Vector2i(0, -1), "s": Vector2i(0, 1), "w": Vector2i(-1, 0), "e": Vector2i(1, 0)}
	var back := {"n": "s", "s": "n", "w": "e", "e": "w"}
	var doorways := {}
	var leaves := {}
	for d in L["doors"]:
		var a := "%d,%d,%s" % [d[2], d[3], d[4]]
		var o: Vector2i = Vector2i(d[2], d[3]) + steps[d[4]]
		doorways[a] = true
		if d[1] != "":
			doorways["%d,%d,%s" % [o.x, o.y, back[d[4]]]] = true
		if d[5] == "door":
			leaves[a] = true
	var windows := {}
	for w in L["windows"]:
		windows["%d,%d,%s" % [w[0], w[1], w[2]]] = true
	for r in L["rooms"]:
		var b: Array = L["rooms"][r]
		for i in range(b[0], b[2] + 1):
			for j in range(b[1], b[3] + 1):
				_finish(_put("floor", i, j), r, "")
				_finish(_put("ceiling", i, j), r, "")
				for side in ["n", "s", "w", "e"]:
					var o: Vector2i = Vector2i(i, j) + steps[side]
					if _room_of(o.x, o.y) == r:
						continue
					var edge := "%d,%d,%s" % [i, j, side]
					if doorways.has(edge):
						_finish(_put("wall_doorway", i, j, side), r, side)
						if leaves.has(edge):
							_put("door_wood", i, j, side).set("auto_open", true)
					elif windows.has(edge):
						_finish(_put("wall_window", i, j, side), r, side)
						_window(_put("window", i, j, side), r, i, j, side)
					else:
						_finish(_put("wall", i, j, side), r, side)


func _finish_of(room: String, what: String, side := "") -> String:
	## A room's finish for a wall (a side's own, else the room's), its floor, ceiling or day glass: "" keeps the free
	## piece's own (a finish the project does not have is passed over).
	var f: Dictionary = L.get("finishes", {}).get(room, {})
	for name in ([String(f.get(side, ""))] if side != "" else []) + [String(f.get(what, ""))]:
		if name != "" and ResourceLoader.exists(FINISHES + name + ".tres"):
			return name
	return ""


func _finish(n: Node3D, room: String, side: String) -> void:
	## The room's finishes on a free piece: its wall (a side's own, or the room's) over the rose wallpaper, its floor
	## over the carpet, its ceiling over the plaster.
	var to := {FREE_WALL: _finish_of(room, "wall", side), FREE_FLOOR: _finish_of(room, "floor"),
		FREE_CEILING: _finish_of(room, "ceiling")}
	for mi in n.find_children("*", "MeshInstance3D", true, false):
		var mesh: Mesh = (mi as MeshInstance3D).mesh
		for k in mesh.get_surface_count():
			var m := mesh.surface_get_material(k)
			var name := "" if m == null else m.resource_name
			if to.get(name, "") != "":
				(mi as MeshInstance3D).set_surface_override_material(k, load(FINISHES + to[name] + ".tres"))


func _window(n: Node3D, room: String, i: int, j: int, side: String) -> void:
	## A window's glass, night or day (set_day), and by day a soft light coming in at it.
	for mi in n.find_children("*", "MeshInstance3D", true, false):
		var mesh: Mesh = (mi as MeshInstance3D).mesh
		for k in mesh.get_surface_count():
			var m := mesh.surface_get_material(k)
			if m and m.resource_name == FREE_GLASS:
				_glass.append([mi, k, m, _finish_of(room, "day")])
	var l := OmniLight3D.new()
	var inward: Vector3 = {"n": Vector3(0, 0, 1), "s": Vector3(0, 0, -1), "w": Vector3(1, 0, 0),
		"e": Vector3(-1, 0, 0)}[side]
	var face: Vector3 = -inward * 0.9
	l.position = Vector3(i * 2.0, 1.6, j * 2.0) + face + inward * 0.6
	l.light_color = Color(0.86, 0.9, 1.0)
	l.light_energy = 0.7
	l.omni_range = 5.5
	add_child(l)
	_daylight.append(l)


func _props_and_spots() -> void:
	crowd = CordatixBystanderCrowd.new()
	crowd.name = "Crowd"
	crowd.populate_on_ready = false
	var cs: Dictionary = L.get("crowd", {})
	crowd.fill = float(cs.get("fill", 0.85))
	crowd.max_same = int(cs.get("max_same", 2))
	crowd.wanderers = int(cs.get("wanderers", 2))
	crowd.carry = float(cs.get("carry", 0.0))
	crowd.phone_walk = float(cs.get("phone_walk", 0.25))
	crowd.seed = 1
	add_child(crowd)
	var named := {}
	var benches := []
	for pd in L["props"]:
		var path: String = PROPS + pd[0] + ".tscn"
		if not ResourceLoader.exists(path):
			continue
		var p: Node3D = load(path).instantiate()
		p.position = Vector3(pd[1], 0.0, pd[2])
		p.rotation.y = deg_to_rad(pd[3])
		region.add_child(p)
		benches.append(p)
		var who: Dictionary = pd[4]
		for s in p.find_children("*", "Marker3D", true, false):
			if s is CordatixBystanderSpot:
				if who.has(s.name):
					s.who = PackedStringArray(who[s.name])
				crowd.spots.append(s)
				if not named.has("%s/%s" % [pd[0], s.name]):
					named["%s/%s" % [pd[0], s.name]] = s
	# (2.0) neighbours on a bench: each seat the other's partner, a pair who talk sitting down
	for pr in L.get("pairs", []):
		if pr[0] < benches.size():
			var a = benches[pr[0]].find_child(pr[1], true, false)
			var b = benches[pr[0]].find_child(pr[2], true, false)
			if a is CordatixBystanderSpot and b is CordatixBystanderSpot:
				a.partner = b
				b.partner = a
	for lp in L["lamps"]:
		_lamp(Vector3(lp[0], 0.0, lp[1]))
	var made := []
	for sd in L["spots"]:
		var s := CordatixBystanderSpot.new()
		s.name = sd[0]
		s.kind = CordatixBystanderSpot.Kind.keys().find(sd[1])
		s.position = Vector3(sd[2], 0.0, sd[3])
		s.rotation.y = deg_to_rad(sd[4])
		add_child(s)
		named[s.name] = s
		made.append([s, sd[5]])
	for m in made:
		var s: CordatixBystanderSpot = m[0]
		var o: Dictionary = m[1]
		if o.has("ahead"):
			s.ahead = named.get(o["ahead"], null)
		if o.has("partner"):
			s.partner = named.get(o["partner"], null)
		if o.has("phone"):
			s.phone = float(o["phone"])
		if o.has("who"):
			s.who = PackedStringArray(o["who"])
		crowd.spots.append(s)


func _lamp(at: Vector3) -> void:
	## A station lamp (the pack's prop, its light in it), or, without it, a light where its globe would be.
	var path := PROPS + "station_lamp.tscn"
	if ResourceLoader.exists(path):
		var p: Node3D = load(path).instantiate()
		p.position = at
		region.add_child(p)
		for l in p.find_children("*", "OmniLight3D", true, false):
			_lamps.append(l)
		return
	var l := OmniLight3D.new()
	l.position = at + Vector3(0, 2.35, 0)
	l.light_color = LAMP["color"]
	l.light_energy = LAMP["energy"]
	l.omni_range = LAMP["range"]
	add_child(l)
	_lamps.append(l)


func _bake() -> void:
	## The README's settings: 0.1 m cells, a 0.3 m agent (Godot's defaults close the series' 1.0 m doorways).
	var nm := NavigationMesh.new()
	nm.geometry_parsed_geometry_type = NavigationMesh.PARSED_GEOMETRY_STATIC_COLLIDERS
	nm.cell_size = 0.1
	nm.cell_height = 0.1
	nm.agent_radius = 0.3
	nm.agent_height = 1.7
	nm.agent_max_climb = 0.2
	NavigationServer3D.map_set_cell_size(get_world_3d().navigation_map, nm.cell_size)
	NavigationServer3D.map_set_cell_height(get_world_3d().navigation_map, nm.cell_height)
	region.navigation_mesh = nm
	region.bake_navigation_mesh(false)


# -------------------------------------------------------------------------------------------- day and night
func set_day(on: bool) -> void:
	# (2.0) by day the crowd has its children and teenagers, by night nobody under 18: a new crowd from the same seed
	if crowd.minors != on or crowd.members().is_empty():
		crowd.minors = on
		talking = null
		crowd.populate(crowd.seed)
		set_psx(psx)
	day = on
	var e := env.environment
	if on:
		e.background_color = Color(0.72, 0.75, 0.78)
		e.ambient_light_color = Color(0.62, 0.66, 0.72)
		e.ambient_light_energy = 0.55
		e.fog_light_color = Color(0.5, 0.52, 0.55)
		e.fog_density = 0.008
	else:
		e.background_color = Color(0.02, 0.025, 0.04)
		e.ambient_light_color = Color(0.16, 0.18, 0.24)
		e.ambient_light_energy = 0.3
		e.fog_light_color = Color(0.04, 0.045, 0.06)
		e.fog_density = 0.02
	for l in _daylight:
		l.visible = on
	for l in _lamps:
		if not l.has_meta("energy"):
			l.set_meta("energy", l.light_energy)
		l.light_energy = float(l.get_meta("energy")) * (0.55 if on else 1.0)     # by day the lamps are lit but weak
	for g in _glass:
		var mi: MeshInstance3D = g[0]
		var k: int = g[1]
		var to: String = g[3]
		var m: Material = load(FINISHES + to + ".tres") if on and to != "" else g[2]
		mi.set_surface_override_material(k, PSX.to_psx(m) if psx and m is StandardMaterial3D else m)


# -------------------------------------------------------------------------------------------- PSX and stepped
func set_psx(on: bool) -> void:
	psx = on
	crowd.psx = on
	for b in crowd.members():
		b.psx = on
	for n in find_children("*", "MeshInstance3D", true, false):
		var inside := false
		for b in crowd.members():
			if b.is_ancestor_of(n):
				inside = true
				break
		if inside:
			continue
		for k in (n as MeshInstance3D).mesh.get_surface_count():     # every surface: walls carry three
			var key := "std%d" % k
			var m: Material = n.get_active_material(k)
			if on and m is StandardMaterial3D:
				n.set_meta(key, [m, n.get_surface_override_material(k)])
				n.set_surface_override_material(k, PSX.to_psx(m))
			elif not on and n.has_meta(key):
				n.set_surface_override_material(k, n.get_meta(key)[1])     # the room's finish, or none
				n.remove_meta(key)


# -------------------------------------------------------------------------------------------- the player
func _faced() -> CordatixBystander:
	## The person the player looks at: within 2.6 m and 25 degrees of the view's middle, the nearest.
	var cam: Camera3D = player.camera
	var fwd := -cam.global_transform.basis.z
	var best: CordatixBystander = null
	var best_d := 2.6
	for b in crowd.members():
		var to: Vector3 = b.global_position + Vector3(0, 1.3, 0) - cam.global_position
		var d := to.length()
		if d < best_d and rad_to_deg(fwd.angle_to(to)) < 25.0:
			best = b
			best_d = d
	return best


func _talk() -> void:
	if talking and is_instance_valid(talking):
		talking.end_talk()
		talking = null
		return
	var b := _faced()
	if b:
		b.talk_to_player(player)
		talking = b
		_events.append("talked_to: %s" % _who(b))


func _who(b: CordatixBystander) -> String:
	var lk: Dictionary = b.looks()[b.look - 1] if b.look - 1 < b.looks().size() else {}
	return "%s (%s)" % [b.data.get("name", b.person), lk.get("name", "")]


const BACK_AWAY := 2.5         # metres: a scare this near makes a person back away from you, not start


func _scare() -> void:
	var again := _clock - _scared < 4.0
	_scared = _clock
	var at := player.global_position
	if again:
		CordatixBystander.alarm(get_tree(), at, 10.0, "flee")
	else:
		CordatixBystander.alarm(get_tree(), at, BACK_AWAY, "back_away")
		for b in crowd.members():
			var d: float = b.global_position.distance_to(at)
			if d > BACK_AWAY and d <= 7.0:
				b.startle(at)
	_events.append("scare: %s" % ("they flee" if again else "the near ones back away, the others start"))


func _calm() -> void:
	for b in crowd.members():
		b.calm()


func _process(delta: float) -> void:
	_clock += delta
	if talking and (not is_instance_valid(talking) or talking.global_position.distance_to(player.global_position) > 3.5):
		if is_instance_valid(talking):
			talking.end_talk()
		talking = null
	var t := "WASD move   mouse look   Shift run   E talk   X scare   C calm   L %s   N new crowd   R again   P PSX%s   " \
		% ["night (nobody under 18)" if day else "day (families)", " (on)" if psx else ""]
	t += "O stepped%s   F1 showcase\n" % ["", " (15)", " (12)"][stepped]
	t += "%s   crowd %d (seed %d)" % ["day" if day else "night", crowd.members().size(), crowd.seed]
	if talking:
		t += "   talking with %s: the game's dialogue starts at talked_to" % _who(talking)
	label.text = t + "\n" + "\n".join(_events.slice(-3))


func _ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	label = Label.new()
	label.position = Vector2(16, 12)
	label.add_theme_font_override("font", load(FONT))
	label.add_theme_font_size_override("font_size", 13)
	label.add_theme_color_override("font_color", Color(0.92, 0.9, 0.82))
	label.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.8))
	label.add_theme_constant_override("shadow_offset_x", 1)
	label.add_theme_constant_override("shadow_offset_y", 1)
	layer.add_child(label)


func _unhandled_input(ev: InputEvent) -> void:
	if ev is InputEventKey and ev.pressed and not ev.echo:
		match ev.keycode:
			KEY_E:
				_talk()
			KEY_X:
				_scare()
			KEY_C:
				_calm()
			KEY_L:
				set_day(not day)
			KEY_N:
				talking = null
				crowd.populate(crowd.seed + 1)
				set_psx(psx)
			KEY_R:
				talking = null
				crowd.populate(crowd.seed)
				set_psx(psx)
			KEY_P:
				set_psx(not psx)
				set_day(day)
			KEY_O:
				stepped = (stepped + 1) % 3
				crowd.stepped_fps = [0.0, 15.0, 12.0][stepped]
				for b in crowd.members():
					b.stepped_fps = crowd.stepped_fps
			KEY_ESCAPE:
				if closing:
					closing.toggle()
				else:
					Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
			KEY_F1:
				get_tree().root.set_meta("bystanders_back", scene_file_path)     # the showcase's F1 comes back here
				get_tree().change_scene_to_file("res://cordatix/psx_bystanders/demo/showcase.tscn")
