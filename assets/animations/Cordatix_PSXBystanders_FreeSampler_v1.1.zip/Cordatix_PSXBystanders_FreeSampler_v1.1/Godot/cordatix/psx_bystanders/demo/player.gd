extends CharacterBody3D
## PSX Bystanders demo player: walk, run, look. Its camera is what the people's heads turn to.

const WALK := 2.4
const RUN := 4.6
const SENS := 0.0025

var camera: Camera3D
var gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)
var input_enabled := true


func _ready() -> void:
	add_to_group("player")
	var shape := CollisionShape3D.new()
	var capsule := CapsuleShape3D.new()
	capsule.radius = 0.3
	capsule.height = 1.7
	shape.shape = capsule
	shape.position.y = 0.85
	add_child(shape)
	camera = Camera3D.new()
	camera.position.y = 1.6
	camera.fov = 70.0
	camera.near = 0.05
	camera.far = 60.0
	add_child(camera)
	camera.current = true


func _unhandled_input(event: InputEvent) -> void:
	if not input_enabled:
		return
	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		rotate_y(-event.relative.x * SENS)
		camera.rotate_x(-event.relative.y * SENS)
		camera.rotation.x = clampf(camera.rotation.x, deg_to_rad(-85.0), deg_to_rad(85.0))
	elif event is InputEventMouseButton and event.pressed:
		Input.set_mouse_mode(Input.MOUSE_MODE_CAPTURED)
	# (Esc is the demo's: its closing screen frees the mouse, 2.0)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y -= gravity * delta
	var dir := Vector3.ZERO
	if input_enabled:
		var f := -transform.basis.z
		var r := transform.basis.x
		if Input.is_key_pressed(KEY_W):
			dir += f
		if Input.is_key_pressed(KEY_S):
			dir -= f
		if Input.is_key_pressed(KEY_D):
			dir += r
		if Input.is_key_pressed(KEY_A):
			dir -= r
	dir.y = 0.0
	var sp := RUN if Input.is_key_pressed(KEY_SHIFT) and input_enabled else WALK
	if dir.length() > 0.01:
		dir = dir.normalized()
	velocity.x = dir.x * sp
	velocity.z = dir.z * sp
	move_and_slide()
