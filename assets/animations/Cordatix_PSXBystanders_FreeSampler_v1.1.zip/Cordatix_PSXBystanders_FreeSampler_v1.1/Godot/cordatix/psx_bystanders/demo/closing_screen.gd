extends CanvasLayer
## Cordatix: a demo's closing screen (a template item for every Cordatix demo). Each pack's builder copies this file, unchanged, into
## its own demo folder (`res://cordatix/<pack>/demo/closing_screen.gd`): no class_name, so the packs' copies never
## clash in one project (the Mega Pack's).
##
## Esc opens it over the demo, paused: the pack's name, a line of thanks, and three buttons. "Rate on itch" opens the
## pack's rating page in the browser only when it is clicked (nothing opens by itself, no advert); "Back" returns to
## the demo; "Quit" ends it. Esc again, or Back, closes it.
##
##   var closing = preload("res://cordatix/<pack>/demo/closing_screen.gd").new()
##   closing.pack_name = "PSX Horror Villagers"
##   closing.rate_url = "https://cordatix.itch.io/<page>/rate"
##   add_child(closing)
##   ...
##   closing.toggle()        # on the demo's Esc

signal opened
signal closed

## The pack's name, as its page says it.
var pack_name := ""
## The pack's page's rating form (`https://cordatix.itch.io/<page>/rate`): for a free demo, the paid page's.
var rate_url := ""
## The line under the name.
var thanks := "Thanks for trying it. If it earns its place in your game, a rating on itch helps other developers find it."
## The font (the demo's own), if any.
var font: Font

var rate_button: Button
var back_button: Button
var quit_button: Button
var _was_paused := false
var _mouse := Input.MOUSE_MODE_VISIBLE


func _ready() -> void:
	layer = 60
	process_mode = Node.PROCESS_MODE_ALWAYS
	visible = false
	var dim := ColorRect.new()
	dim.color = Color(0.04, 0.04, 0.04, 0.78)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(dim)
	var centre := CenterContainer.new()
	centre.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(centre)
	var panel := PanelContainer.new()
	var box := StyleBoxFlat.new()
	box.bg_color = Color(0.067, 0.067, 0.063)                 # the pages' #111110
	box.border_color = Color(0.878, 0.478, 0.184)             # PSX Horror's orange #E07A2F
	box.set_border_width_all(2)
	box.set_content_margin_all(22)
	panel.add_theme_stylebox_override("panel", box)
	centre.add_child(panel)
	var col := VBoxContainer.new()
	col.add_theme_constant_override("separation", 14)
	panel.add_child(col)
	var title := _label(pack_name, 24)
	col.add_child(title)
	var line := _label(thanks, 15)
	line.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	line.custom_minimum_size = Vector2(460, 0)
	col.add_child(line)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 12)
	row.alignment = BoxContainer.ALIGNMENT_CENTER
	col.add_child(row)
	rate_button = _button("Rate on itch", row)
	back_button = _button("Back", row)
	quit_button = _button("Quit", row)
	rate_button.pressed.connect(rate)
	back_button.pressed.connect(close)
	quit_button.pressed.connect(func(): get_tree().quit())


## Opens the screen if it is shut, shuts it if it is open.
func toggle() -> void:
	if visible:
		close()
	else:
		open()


func open() -> void:
	if visible:
		return
	visible = true
	_was_paused = get_tree().paused
	get_tree().paused = true
	if DisplayServer.get_name() != "headless":
		_mouse = Input.mouse_mode
		Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	rate_button.grab_focus()
	opened.emit()


func close() -> void:
	if not visible:
		return
	visible = false
	get_tree().paused = _was_paused
	if DisplayServer.get_name() != "headless":
		Input.mouse_mode = _mouse
	closed.emit()


## The rating page, in the browser: only on the button.
func rate() -> void:
	if rate_url != "":
		OS.shell_open(rate_url)


func _unhandled_input(e: InputEvent) -> void:
	if visible and e is InputEventKey and e.pressed and not e.echo and (e as InputEventKey).physical_keycode == KEY_ESCAPE:
		close()
		get_viewport().set_input_as_handled()


func _label(text: String, size: int) -> Label:
	var l := Label.new()
	l.text = text
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	if font:
		l.add_theme_font_override("font", font)
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", Color(0.93, 0.91, 0.84))      # the pages' text #EDE8D6
	return l


func _button(text: String, row: HBoxContainer) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(130, 34)
	if font:
		b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", 15)
	row.add_child(b)
	return b
