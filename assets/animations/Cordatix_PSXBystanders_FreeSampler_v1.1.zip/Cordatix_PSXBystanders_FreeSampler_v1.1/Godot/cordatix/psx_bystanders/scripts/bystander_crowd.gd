class_name CordatixBystanderCrowd
extends Node3D
## Cordatix PSX Bystanders: fills a level's spots with people (Godot 4.3+).
##
## The spots are this node's CordatixBystanderSpot children (and their children), or the ones in `spots`. populate()
## puts a person at each spot, already doing what it says, drawn from `people` (empty: every person of the pack) in a
## look and with accessories drawn from the seed: never the same person in the same look twice in one crowd, the same
## person at most `max_same` times (in different looks); a spot's `who` takes the first person it names. A share of
## the spots stays empty (`fill`), a line filled from its head back (a QUEUE spot with none ahead, or the served
## counter its line waits for), and a few people wander from spot to spot (`wanderers`, from seats and places to wait,
## lean or look). What is worn only standing (a bag on the back) stays off on a person it seats, leans or lets wander
## (to a seat, perhaps). The same seed gives the same crowd.
##
## 2.0: a look's role accessories (a helmet, a police cap, a medical bag: data/people.json "role") stay with their own
## look in the accessory draw; `minors` lets it place the children and teenagers (off: a night scene's crowd); some of
## the wanderers walk on their phones (`phone_walk`) or carry a box (`carry`), drawn from the seed apart from the rest
## of the draw (a crowd of 1.0's people from a seed is the crowd 1.0 made from it).
##
## With `populate_on_ready` it fills itself once the level is ready; a populate() or load_save() of the level's own
## before then (in its _ready) takes its place. Each populate() makes new people (connect their signals again on
## `populated`).

signal populated(count: int)

const PEOPLE_DIR := "res://cordatix/psx_bystanders/people/"

@export var people: PackedStringArray = []
@export var seed := 1
## The share of the spots that get a person (0..1). TALK spots fill in pairs, a QUEUE from its head back.
@export_range(0.0, 1.0) var fill := 0.85
@export var max_same := 2
## How many of them wander from spot to spot.
@export var wanderers := 0
## Accessories off or on now and then (glasses on a person who wears none in that look...): the share of changes. A
## role's accessories (data/people.json "role") are never changed.
@export_range(0.0, 1.0) var accessory_change := 0.2
## Places the children and teenagers (2.0; CordatixBystander.is_minor). Off for a scene nobody under 18 is in.
@export var minors := true
## The share of its wanderers who walk looking at their phones (2.0, PhoneWalk).
@export_range(0.0, 1.0) var phone_walk := 0.25
## The share of its wanderers who carry a box (2.0, Carry and CarryIdle): they go only to places to wait, look or queue.
@export_range(0.0, 1.0) var carry := 0.0
@export var spots: Array[CordatixBystanderSpot] = []
@export var populate_on_ready := true
## PS1 vertex snapping on every person it makes.
@export var psx := false
@export var stepped_fps := 0.0
## Keeps its lines going: when a line has fewer than two waiting, one of its wanderers who is free goes to stand at its
## end (every few seconds), the one longest out of a line: a served line needs `wanderers` at 2 or more, and the more
## there are, the more faces take a turn. Off (or with no wanderers): a line empties as its people are served and leave.
@export var feed_lines := true

var _made: Array = []
var _pending := false
var _lines: Array = []                # each line's places, its head first
var _feed_t := 3.0
var _clock := 0.0
var _lined := {}                      # each member's last time in a line (s; by instance id)


func _ready() -> void:
	if populate_on_ready:
		_pending = true
		_populate_pending.call_deferred()


func _populate_pending() -> void:
	if _pending:                        # the level's own populate() or load_save() came first: that one stands
		populate(seed)


## The spots it fills.
func crowd_spots() -> Array:
	if not spots.is_empty():
		return spots.duplicate()
	var out := []
	for n in find_children("*", "Node3D", true, false):
		if n is CordatixBystanderSpot:
			out.append(n)
	return out


## The people it made.
func members() -> Array:
	return _made.filter(func(b): return is_instance_valid(b))


## Takes every person it made out of the level at once (their names and spots free for the next ones).
func clear() -> void:
	_pending = false
	for b in _made:
		if is_instance_valid(b):
			if b.current_spot:
				b.current_spot.release(b)
			if b.spot:
				b.spot.release(b)            # given, and held for it until it began
			if b.get_parent():
				b.get_parent().remove_child(b)
			b.queue_free()
	_made.clear()
	_lined.clear()


func populate(new_seed := seed) -> int:
	clear()
	seed = new_seed
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(seed) * 7919 + 13
	var rng2 := RandomNumberGenerator.new()           # (2.0) phones and boxes: apart from the rest of the draw
	rng2.seed = hash(seed) * 104729 + 7
	var pool: Array = Array(people) if not people.is_empty() else CordatixBystander.people()
	pool = pool.filter(func(k): return ResourceLoader.exists(PEOPLE_DIR + k + ".tscn"))
	if pool.is_empty():
		push_warning("CordatixBystanderCrowd: no people to place")
		return 0
	# every (person, look) once, in an order drawn from the seed; a person again only in another look
	var data := CordatixBystander.load_data()
	var cards: Array = []
	for k in pool:
		var n: int = data.get(k, {}).get("looks", []).size()
		for lk in range(1, n + 1):
			cards.append([k, lk])
	_shuffle(cards, rng)
	var all_spots := crowd_spots()
	all_spots.sort_custom(func(a, b): return String(a.get_path()) < String(b.get_path()))
	_lines = _lines_of(all_spots)
	var chosen := _choose_spots(all_spots, rng)
	# the spots that say who goes there take their people first, from the same draw
	var order: Array = chosen.filter(func(sp): return not sp.who.is_empty())
	order.append_array(chosen.filter(func(sp): return sp.who.is_empty()))
	var used := {}
	var count := 0
	var wandering := 0
	for s in order:
		if not s.is_free():
			continue                                # someone of the level's own stands there
		var card = _draw(cards, used, s, data)
		if card == null:
			continue                                # nobody fits it, or nobody left in a new look: it stays empty
		used[card[0]] = int(used.get(card[0], 0)) + 1
		var b: CordatixBystander = load(PEOPLE_DIR + card[0] + ".tscn").instantiate()
		b.name = "%s_%d" % [String(card[0]).capitalize().replace(" ", ""), count + 1]
		b.look = card[1]
		b.psx = psx
		b.stepped_fps = stepped_fps
		b.mode = CordatixBystander.Mode.STAY
		if wandering < wanderers and _can_wander_from(s):
			b.mode = CordatixBystander.Mode.WANDER
			wandering += 1
			b.phone_walk = rng2.randf() < phone_walk
			b.carrying = rng2.randf() < carry and not b.phone_walk
		b.spot = s
		add_child(b)
		# its spot is its own from now on, before it begins (made a physics frame into the level, a wanderer took a
		# spot given to another before that one began, and the other stood where it was made)
		s.claim(b)
		var sits: bool = b.mode == CordatixBystander.Mode.WANDER or s.kind in [CordatixBystanderSpot.Kind.SEAT,
			CordatixBystanderSpot.Kind.DESK, CordatixBystanderSpot.Kind.LEAN]
		for a in b.accessory_keys():
			if a != "phone" and a != "box" and not b.role_accessory(a) and rng.randf() < accessory_change:
				b.set_accessory(a, not b.wears(a))
			if sits and b.standing_only(a) and b.wears(a):
				b.set_accessory(a, false)
		_made.append(b)
		count += 1
	populated.emit(count)
	return count


## The next card of the draw that may go to `s` (a person not yet max_same times, one `s.who` names), taken out of it.
func _draw(cards: Array, used: Dictionary, s: CordatixBystanderSpot, data: Dictionary):
	for i in cards.size():
		var c = cards[i]
		if int(used.get(c[0], 0)) >= max_same:
			continue
		if not minors and float(data.get(c[0], {}).get("age", 40)) < CordatixBystander.MINOR_AGE:
			continue
		if not s.who.is_empty():
			var looks: Array = data.get(c[0], {}).get("looks", [])
			var lk: String = String(looks[c[1] - 1].get("key", "")) if c[1] - 1 < looks.size() else ""
			if not (c[0] in s.who or "%s:%s" % [c[0], lk] in s.who):
				continue
		cards.remove_at(i)
		return c
	return null


## A spot a wanderer may start from: a seat, a place to wait, lean or look (not a line, a counter, a desk, a pair's
## place or a reserved one: someone leaving them breaks what they are for).
func _can_wander_from(s: CordatixBystanderSpot) -> bool:
	return not s.reserved and s.kind in [CordatixBystanderSpot.Kind.SEAT, CordatixBystanderSpot.Kind.WAIT,
		CordatixBystanderSpot.Kind.LEAN, CordatixBystanderSpot.Kind.LOOK]


## The crowd as it is now: its seed and each person's own save (CordatixBystander.get_save) in the order it made them
## (the same seed makes the same people in the same order: load_save matches them so); an empty one for a person gone.
func get_save() -> Dictionary:
	var m := []
	for b in _made:
		m.append(b.get_save() if is_instance_valid(b) and not b.is_queued_for_deletion() else {})
	return {"seed": seed, "members": m}


## The same crowd again (its seed), each person put back as the save found it: at the spot it had (a line moved on,
## a wanderer elsewhere), or where it stood in the clip it played. In a level's _ready too: it takes the place of the
## populate on ready.
func load_save(d: Dictionary) -> void:
	populate(int(d.get("seed", seed)))
	for b in _made:
		if is_instance_valid(b) and b.spot:
			b.spot.release(b)                   # each takes the spot the save gives it, not the one the seed gave
	var m: Array = d.get("members", [])
	var gone := []
	for i in mini(_made.size(), m.size()):
		var b = _made[i]
		if not is_instance_valid(b):
			continue
		if (m[i] as Dictionary).is_empty():
			gone.append(b)                  # a person the game had taken out
		else:
			b.load_save(m[i])
	for b in gone:
		_made.erase(b)
		if b.current_spot:
			b.current_spot.release(b)
		b.get_parent().remove_child(b)
		b.queue_free()


func _physics_process(delta: float) -> void:
	if not feed_lines or _lines.is_empty() or Engine.is_editor_hint():
		return
	_clock += delta
	_feed_t -= delta
	if _feed_t > 0.0:
		return
	_feed_t = 4.0
	for b in members():
		var at = b.current_spot
		if at and at.occupant == b and (at.kind == CordatixBystanderSpot.Kind.QUEUE \
				or at.kind == CordatixBystanderSpot.Kind.COUNTER):
			_lined[b.get_instance_id()] = _clock
	for line in _lines:
		# its end: the place behind the last one taken (a free counter with someone at the place behind it is theirs to
		# step up to: given to a wanderer, the one waiting there waited for good)
		var waiting := 0
		var last := -1
		for i in line.size():
			if is_instance_valid(line[i]) and not line[i].is_free():
				waiting += 1
				last = i
		var end: CordatixBystanderSpot = line[last + 1] if last + 1 < line.size() else null
		if end == null or not is_instance_valid(end) or waiting >= 2:
			continue
		# a wanderer at ease (idle, or at a spot that is not a line's or a counter's): the one longest out of a line (one
		# never in one first), the nearest of those (the nearest alone was the one just served: with two or three
		# wanderers, the same two took every turn at the counter)
		var best: CordatixBystander = null
		var best_t := INF
		var best_d := INF
		for b in members():
			if b.mode != CordatixBystander.Mode.WANDER or not b.state in ["idle", "spot"] or b.clip in ["SitDown", "StandUp"]:
				continue
			var at = b.current_spot
			if at and (at.kind == CordatixBystanderSpot.Kind.QUEUE or at.kind == CordatixBystanderSpot.Kind.COUNTER):
				continue
			var t: float = _lined.get(b.get_instance_id(), -INF)
			var dd: float = b.global_position.distance_to(end.global_position)
			if t < best_t or (t == best_t and dd < best_d):
				best_t = t
				best_d = dd
				best = b
		if best and best.use_spot(end):
			_lined[best.get_instance_id()] = _clock


## Every line among `all_spots`, its head first: a QUEUE spot with none ahead, or the spot its first QUEUE spot waits
## for (a served counter), then each QUEUE spot behind it.
func _lines_of(all_spots: Array) -> Array:
	var lines: Array = []
	for s in all_spots:
		var head: bool = s.kind == CordatixBystanderSpot.Kind.QUEUE and (s.ahead == null or not s.ahead in all_spots)
		if s.kind != CordatixBystanderSpot.Kind.QUEUE:
			head = all_spots.any(func(t): return t.kind == CordatixBystanderSpot.Kind.QUEUE and t.ahead == s)
		if not head:
			continue
		var line := [s]
		var more := true
		while more:
			more = false
			for t in all_spots:
				if t.kind == CordatixBystanderSpot.Kind.QUEUE and t.ahead == line[-1] and not t in line:
					line.append(t)
					more = true
					break
		lines.append(line)
	return lines


func _shuffle(a: Array, rng: RandomNumberGenerator) -> void:
	for i in range(a.size() - 1, 0, -1):
		var j := rng.randi_range(0, i)
		var t = a[i]
		a[i] = a[j]
		a[j] = t


func _choose_spots(all_spots: Array, rng: RandomNumberGenerator) -> Array:
	## The spots to fill: `fill` of them, a TALK pair both or neither, a line from its head back (no gap in a line):
	## a line's head is a QUEUE spot with none ahead, or the spot its first QUEUE spot waits for (a served counter).
	var lines := _lines_of(all_spots)
	var in_line := {}
	for line in lines:
		for t in line:
			in_line[t] = true
	var units: Array = []
	var seen := {}
	for s in all_spots:
		if seen.has(s) or in_line.has(s) or s.kind == CordatixBystanderSpot.Kind.QUEUE:
			continue
		if s.kind == CordatixBystanderSpot.Kind.TALK and s.partner and s.partner in all_spots:
			units.append([s, s.partner])
			seen[s.partner] = true
		else:
			units.append([s])
		seen[s] = true
	_shuffle(units, rng)
	var total := all_spots.size()
	var want := int(round(total * fill))
	var out: Array = []
	for line in lines:
		var n := int(round(line.size() * fill))
		for i in n:
			out.append(line[i])
	for u in units:
		if out.size() + u.size() > want and out.size() >= want:
			break
		out.append_array(u)
	return out
