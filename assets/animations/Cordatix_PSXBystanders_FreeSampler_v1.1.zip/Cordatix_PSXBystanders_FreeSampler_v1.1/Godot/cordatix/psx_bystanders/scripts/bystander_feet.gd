class_name CordatixBystanderFeet
extends SkeletonModifier3D
## Cordatix PSX Bystanders: a foot on the floor stays where it is (Godot 4.3+).
##
## The clips play in place and the person moves its body at each gait's own speed; wherever the two part a little (a
## start, a stop, a turn on the spot, the last steps onto a mark), a planted foot would slide over the floor. This holds
## a foot the clip sets down where it touched the floor, the leg bent to it (two bones, the knee the way the clip bends
## it off its own hip and ankle and never behind the hips, the foot the way the clip holds it), until the clip lifts it
## again. A foot held too far from where the clip has it, or turned too far from it, takes a step there, one foot at a
## time and the other standing, as a person shifts their feet after a stop or turns on the spot. When a held foot is
## out of a straight leg's reach, the hips come down a little to it. A clip's toe under the floor (a blend out of a
## crouch dips them) counts as on the floor at its own place: no foot is held, set down or stepped under the floor, and
## no step sets off until the clip's toes are back up. Only the legs and the hips change, and nothing while `weight`
## is 0 (the person sets it: off while it sits or lies down).
##
## Godot applies modifiers after the clip and puts the clip's pose back once the frame is drawn: read the pose shown
## (the legs as this holds them) in Skeleton3D's skeleton_updated signal, or from `toes`.

## 0..1: how much it holds (eased in and out over 0.2 s). The person sets it from the clip it plays.
@export_range(0.0, 1.0) var weight := 1.0
## Holds a planted foot's facing as well as its place (standing, turning on the spot). Off, a planted foot turns on its
## ball with the body (walking round a corner).
var hold_facing := true
## Standing still: once it has been calm a moment, a smaller drift is tidied with a step.
var calm := false
## Coming to a stop (settle_now): the smaller drift is tidied at once, the foot furthest from under the body first.
var settle := false
## PS1-style steps (the person's stepped_fps): it moves on this many times a second, as the stepped body does.
var stepped_fps := 0.0
## A step: how long it takes (s) and how high the foot lifts (m).
var step_time := 0.3
var step_lift := 0.05
## A held foot steps once it is this far (m) or turned this many degrees from where the clip has it; when calm, the
## tidy limits.
var drift_step := 0.09
var turn_step := 28.0
## Walking (hold_facing off) the clip lifts each foot soon: a step of its own only past this.
var drift_gait := 0.2
var drift_tidy := 0.035
var turn_tidy := 12.0
var calm_wait := 0.35
## The most the hips come down for a held foot out of reach (m); past it the foot is let go a little.
var max_drop := 0.06

## Read by tests: the toes' places as shown this frame (world: left, right), the knees where the clip has them (world),
## the steps taken, the weight in use, how far the hips are down.
var toes: Array = [Vector3.ZERO, Vector3.ZERO]
var clip_knees: Array = [Vector3.ZERO, Vector3.ZERO]
var steps := 0
var applied := 0.0
var drop := 0.0

const FREE := 0         # the clip's own place (in the air, or nothing held)
const HELD := 1         # held where it touched the floor
const STEP := 2         # stepping from where it was held to where the clip has it
const LIFT := 3         # the clip lifts it: from where it was held to the clip's place, quickly
const LIFT_TIME := 0.12
const LIFT_LONG := 0.05   # m: a lift's way longer than this takes longer than LIFT_TIME, up to a step's time (2.0)
const LIFT_DROP := 0.025  # m the hips come down at most for a foot the clip lifts (as it leaves)
const PLANT := 0.012    # m above its standing height: the toes are on the floor
const STRAIGHT := 0.02  # m: a clip's knee this far off its own hip-ankle line or less is (nearly) a straight leg
const KNEE_LEAD := 12.0 # degrees the clip may bend a held foot's knee past the held leg before the foot is let go
const HINGE_FROM := 0.03  # m^2: the clip's thigh and shin far enough from straight (about 8 degrees) to show the hinge
const UNPLANT := 0.02   # m above it: a held foot is lifted
const DIP_WAIT := 0.01  # m a clip's toe is under its standing height (blending out of a crouch): no step sets off

var _ids: Array = []    # per side: [upper leg, lower leg, foot, toes]
var _hips := -1
var _h0: Array = [0.0, 0.0]
var _mode: Array = [FREE, FREE]
var _pos: Array = [Vector3.ZERO, Vector3.ZERO]      # held: where (world); stepping, lifting: where it set off from
var _fwd: Array = [Vector3.FORWARD, Vector3.FORWARD]  # held: the way it faces (world, flat); stepping, lifting: at set off
var _t: Array = [0.0, 0.0]
var _hinge: Array = [Vector3.ZERO, Vector3.ZERO]    # each knee's hinge (the thigh's own axes), from the clip's bent leg
var _land: Array = [Vector3.INF, Vector3.INF]       # stepping: where the clip set the foot down, once it has (world)
var _land_f: Array = [Vector3.FORWARD, Vector3.FORWARD]
var _lift_time: Array = [LIFT_TIME, LIFT_TIME]       # (2.0) each lift's own time: longer for a longer way
var _calm_t := 0.0
var _since_step := 1.0
var _drifting := false
var _settle_t := 0.0
var _rest_toe: Array = [Vector3.ZERO, Vector3.ZERO]   # each toe's place standing at rest (skeleton space)
var _acc := 0.0
var _last := Vector3.INF


## Lets go of both feet: after the person is put somewhere at once (place_at_spot, a loaded save).
func reset() -> void:
	_mode = [FREE, FREE]
	drop = 0.0
	_last = Vector3.INF


## Whether a foot is on its way (a step, a lift) or held further from where the clip has it than a tidy step allows.
func drifting() -> bool:
	return _drifting


## It has come to a stop: for up to `seconds` (or until nothing drifts) it brings its feet under it at once, the one
## left furthest behind or ahead first (a walk stops mid-stride: waiting for the stop's blend to show how far, the
## foot left behind stretched the leg and the hips came down 5 cm for it).
func settle_now(seconds := 1.0) -> void:
	_settle_t = seconds
	settle = true


func _resolve(sk: Skeleton3D) -> void:
	_ids.clear()
	_hips = sk.find_bone("Hips")
	for s in ["Left", "Right"]:
		var a := [sk.find_bone(s + "UpperLeg"), sk.find_bone(s + "LowerLeg"), sk.find_bone(s + "Foot"),
			sk.find_bone(s + "Toes")]
		if _hips < 0 or a.has(-1):
			_ids.clear()
			return
		_ids.append(a)
	for i in 2:
		_rest_toe[i] = sk.get_bone_global_rest(_ids[i][3]).origin
		_h0[i] = _rest_toe[i].y


func _process_modification() -> void:
	var sk := get_skeleton()
	if sk == null or not sk.is_inside_tree():
		return                          # (a person taken out of the level before its skeleton's update came)
	if _ids.is_empty():
		_resolve(sk)
		if _ids.is_empty():
			return
	var dt := get_process_delta_time()
	# (2.0) drawn under 45 times a second: a lift is not set down before half of it (below)
	var coarse := dt > 1.0 / 45.0
	if stepped_fps > 0.0:
		# stepped: it moves on with the steps, a whole step at a time
		_acc += dt
		var st := 1.0 / stepped_fps
		dt = 0.0
		while _acc >= st - 0.0001:
			_acc -= st
			dt += st
	var xf := sk.global_transform
	if _last != Vector3.INF and _last.distance_to(xf.origin) > 0.75:
		reset()                                    # put somewhere else at once: nothing to hold
	_last = xf.origin
	applied = move_toward(applied, weight, dt / 0.2)
	_calm_t = _calm_t + dt if calm else 0.0
	_since_step += dt
	if _settle_t > 0.0:
		_settle_t -= dt
		settle = _settle_t > 0.0
	# the clip's legs (skeleton space), its toes and the way its feet face (world). A toe under its standing height is
	# taken as on the floor at its own flat place: held, a step's landing and its way, the hips' drop all go from there
	# (a blend out of a crouch dips the clip's toes 5 cm under the floor: a step landed there and the hips came down 6 cm
	# for it, after calm() from Cower)
	var legs := []
	var at := []
	var af := []
	var ground := []                # (2.0) each toe's place on the floor (its standing height): where it is held and lands
	var dip := 0.0
	for i in 2:
		var ids: Array = _ids[i]
		var leg := [sk.get_bone_global_pose(ids[0]), sk.get_bone_global_pose(ids[1]), sk.get_bone_global_pose(ids[2]),
			sk.get_bone_global_pose(ids[3])]
		legs.append(leg)
		clip_knees[i] = xf * (leg[1] as Transform3D).origin
		var tl: Vector3 = (leg[3] as Transform3D).origin
		dip = maxf(dip, _h0[i] - tl.y)
		at.append(xf * Vector3(tl.x, maxf(tl.y, _h0[i]), tl.z))
		ground.append(xf * Vector3(tl.x, _h0[i], tl.z))
		af.append(_flat(xf.basis * (leg[2] as Transform3D).basis.z))
	if applied <= 0.0:
		for i in 2:
			_mode[i] = FREE
			toes[i] = xf * (legs[i][3] as Transform3D).origin
		drop = 0.0
		return
	# what each foot does
	for i in 2:
		var h: float = (legs[i][3] as Transform3D).origin.y - _h0[i]
		match _mode[i]:
			FREE:
				if h < PLANT:
					_hold(i, ground[i], af[i])    # on the floor (2.0: a toe up to PLANT over it was held there, 1.2 cm up)
			HELD:
				if h > UNPLANT:
					if stepped_fps > 0.0:
						_mode[i] = FREE              # stepped: the clip's next pose is a step on anyway
					else:
						_set_off(i, LIFT, at[i], af[i])
						# (2.0) a lift's time grows with its way: a standing foot let go far from the clip's (into a
						# crouch out of a flight) was carried there in 0.12 s and held 3.9 cm up as it was set down.
						# Not in a gait: there the clip lifts each foot as the body goes on, and a quick lift keeps up
						# with it (a long one dragged a flight's first foot 6 cm along the floor behind the running
						# body, the hips 6 cm down for it)
						if hold_facing:
							var way := _flat_len((_pos[i] as Vector3) - (at[i] as Vector3))
							_lift_time[i] = clampf(LIFT_TIME * way / LIFT_LONG, LIFT_TIME, step_time)
				elif not hold_facing:
					_fwd[i] = af[i]                # walking: it turns on its ball with the body
			STEP:
				_t[i] += dt
				if h < PLANT and _t[i] >= step_time * 0.5 and _land[i] == Vector3.INF:
					# the clip has the foot down: the step lands there (drawn more often than the body moves, at 144 a
					# second, the clip's planted foot went back with the gait between the body's moves, and the step's
					# end slid 5 cm after it)
					_land[i] = ground[i]          # (2.0) on the floor, not up to PLANT over it
					_land_f[i] = af[i]
				if _t[i] >= step_time:
					_since_step = 0.0
					if h < PLANT:
						var sh := _shown(i, at[i], af[i])
						_hold(i, sh[0], sh[1])
					else:
						_mode[i] = FREE
			LIFT:
				_t[i] += dt
				if _t[i] >= _lift_time[i]:
					_mode[i] = FREE
				elif h < PLANT and _t[i] >= _lift_time[i] * (0.75 if stepped_fps > 0.0 else (0.5 if coarse else 0.0)):
					# (stepped: not set down before three quarters of the lift: at 12 poses a second its first pose
					# set the foot down 19 cm on along the floor, a shuffle, not a step; drawn 30 times a second, not
					# before half of it: a walk's start, its toes rising and dipping about PLANT, lifted and set down
					# a girl's foot a frame at a time, 21 cm along the floor; drawn 144 times a second, at once: held
					# back, a flight's foot set down 3.8 cm in a 60th)
					# set down again on the way: held where it is, on the floor (2.0: held at the lift's arc, up to 4 cm
					# over the floor for a third of a second)
					var sh := _shown(i, at[i], af[i])
					_hold(i, Vector3(sh[0].x, (ground[i] as Vector3).y, sh[0].z), sh[1])
	# the legs: where each foot is shown, the ankle that needs, and how far down the hips must come for it
	var hp: Transform3D = sk.get_bone_global_pose(_hips)
	var inv := xf.affine_inverse()
	# the way the hips face (skeleton space, flat): square to the line from the left hip joint to the right one
	var fwd := _flat(Vector3.UP.cross((legs[1][0] as Transform3D).origin - (legs[0][0] as Transform3D).origin))
	var plan := []
	var need := 0.0
	for i in 2:
		var leg: Array = legs[i]
		var U: Transform3D = leg[0]
		var L: Transform3D = leg[1]
		var F: Transform3D = leg[2]
		var T: Transform3D = leg[3]
		var sh := _shown(i, at[i], af[i])
		var p: Vector3 = (at[i] as Vector3).lerp(sh[0], applied)
		var f := _turn_flat(af[i], sh[1], applied)
		var fs := _flat(inv.basis * f)
		var cf := _flat(F.basis.z)
		var rf := F.basis
		if fs.length() > 0.5 and cf.length() > 0.5:
			rf = Basis(Vector3.UP, cf.signed_angle_to(fs, Vector3.UP)) * F.basis
		var toe := F.basis.inverse() * (T.origin - F.origin)
		var ankle := inv * p - rf * toe
		var l1 := U.origin.distance_to(L.origin)
		var l2 := L.origin.distance_to(F.origin)
		var reach := (l1 + l2) * 0.995
		var d := ankle - U.origin
		var across := Vector2(d.x, d.z).length()
		if across < reach and _mode[i] != FREE:
			# a foot on the floor; one on its way as much as it is near the floor: a step more and more as it comes down
			# (only once down, the hips came down for it in a frame and both knees jumped), a lift less and less as it
			# leaves
			var on := 1.0
			var most := max_drop
			if _mode[i] == STEP or _mode[i] == LIFT:
				var u := clampf(_t[i] / (step_time if _mode[i] == STEP else _lift_time[i]), 0.0, 1.0)
				on = u * u * (3.0 - 2.0 * u)
				if _mode[i] == LIFT:
					on = 1.0 - on
					most = LIFT_DROP           # (a quick turn's foot let go far behind it: the hips came down 5.6 cm)
			need = maxf(need, minf(-d.y - sqrt(reach * reach - across * across), most) * on)
		if _mode[i] == HELD and _bend(l1, l2, d.length()) < _bend(l1, l2, U.origin.distance_to(F.origin)) - KNEE_LEAD:
			# the clip bends this knee well past the held leg (it sets off on a step while its toes are still down): let
			# it go now (let go only once the toes were up, from a leg held straight, it came into the clip's bent leg
			# 15 degrees a frame: the knee snapped)
			# (standing, a step of its own: let go into a crouch out of a run, a quick lift took the knee 50 cm in 0.12
			# s, 11 cm in a frame)
			if hold_facing:
				_set_off(i, STEP, at[i], af[i])
				steps += 1
			else:
				_set_off(i, LIFT, at[i], af[i])
		plan.append([rf, ankle, toe, l1, l2])
	# (a held foot out of reach even so is shown as near as its leg reaches: no leg is stretched)
	need = clampf(need, 0.0, max_drop)
	# the hips come back up once no foot is on its way (rising as a foot left where it was held, they stretched the
	# leg lifting from there straight, and it bent again: the knee wobbled)
	var moving: bool = _mode[0] == STEP or _mode[0] == LIFT or _mode[1] == STEP or _mode[1] == LIFT
	drop = need if need > drop else (drop if moving else move_toward(drop, need, 0.3 * dt))
	var down := Vector3(0.0, -drop, 0.0)
	if drop > 0.00001:
		var parent := sk.get_bone_parent(_hips)
		var pb := sk.get_bone_global_pose(parent).basis if parent >= 0 else Basis()
		sk.set_bone_pose_position(_hips, sk.get_bone_pose_position(_hips) + pb.inverse() * down)
	# one foot steps at a time, the other one held, a beat after the last step
	var tidy := settle or _calm_t >= calm_wait
	var lim_d := drift_tidy if tidy else (drift_step if hold_facing else drift_gait)
	var lim_t := turn_tidy if tidy else turn_step
	var worst := -1
	var over := 1.0
	_drifting = _mode[0] == STEP or _mode[1] == STEP or _mode[0] == LIFT or _mode[1] == LIFT
	for i in 2:
		if _mode[i] != HELD:
			continue
		var drift := _flat_len(_pos[i] - at[i])
		var turned := rad_to_deg(absf((_fwd[i] as Vector3).signed_angle_to(af[i], Vector3.UP))) if hold_facing else 0.0
		if drift > drift_tidy or turned > turn_tidy:
			_drifting = true
		var o := maxf(drift / lim_d, turned / lim_t)
		if settle:
			# stopping: how far it is from under the body (its place at rest, 8 cm to spare for a wider stance) counts
			# at once, before the stop's blend has moved the clip's feet there
			o = maxf(o, (_flat_len(_pos[i] - xf * (_rest_toe[i] as Vector3)) - 0.08) / lim_d)
		if o > over:
			over = o
			worst = i
	if settle and _settle_t < 0.7 and not _drifting:
		_settle_t = 0.0
		settle = false
	# no step while the clip's toes are under the floor (a blend out of a crouch): it would go where they are on the way
	if worst >= 0 and _mode[0] == HELD and _mode[1] == HELD and _since_step > 0.06 and dip < DIP_WAIT:
		_set_off(worst, STEP, at[worst], af[worst])
		steps += 1
	for i in 2:
		var leg: Array = legs[i]
		var pl: Array = plan[i]
		toes[i] = xf * _solve(sk, i, hp, leg[0], leg[1], leg[2], pl[0], pl[1], pl[2], pl[3], pl[4], down, fwd)


func _hold(i: int, p: Vector3, f: Vector3) -> void:
	_mode[i] = HELD
	_pos[i] = p
	_fwd[i] = f


func _set_off(i: int, m: int, at: Vector3, af: Vector3) -> void:
	var sh := _shown(i, at, af)
	_pos[i] = sh[0]
	_fwd[i] = sh[1]
	_t[i] = 0.0
	_mode[i] = m
	_land[i] = Vector3.INF
	# (stepped: a lift of two poses at least, one of them in the air)
	_lift_time[i] = maxf(LIFT_TIME, 2.0 / stepped_fps) if stepped_fps > 0.0 else LIFT_TIME


## Where foot `i` is shown (world toe, flat facing), given where the clip has it.
func _shown(i: int, at: Vector3, af: Vector3) -> Array:
	match _mode[i]:
		HELD:
			return [_pos[i], _fwd[i]]
		STEP:
			var s := clampf(_t[i] / step_time, 0.0, 1.0)
			var e := s * s * (3.0 - 2.0 * s)
			var to: Vector3 = _land[i] if _land[i] != Vector3.INF else at
			var p: Vector3 = (_pos[i] as Vector3).lerp(to, e)
			p.y += step_lift * sin(PI * s)
			return [p, _turn_flat(_fwd[i], _land_f[i] if _land[i] != Vector3.INF else af, e)]
		LIFT:
			# a quick step: off the floor first (a foot the clip lifts slowly, as a walk blends in, had come 13 cm
			# along the floor on its way to the clip's place), as high as the way is long, at most a step's lift
			var s := clampf(_t[i] / _lift_time[i], 0.0, 1.0)
			var e := s * s * (3.0 - 2.0 * s)
			var p: Vector3 = (_pos[i] as Vector3).lerp(at, e)
			p.y += clampf(_flat_len(_pos[i] - at) * 0.4, 0.0, step_lift) * sin(PI * s)
			return [p, _turn_flat(_fwd[i], af, e)]
	return [at, af]


## Two bones: the leg (hips lowered by `down`) bent so its ankle is at `ankle` (skeleton space), the foot turned to
## `rf`. The knee goes the way the clip's knee stands off the clip's own hip and ankle (a nearly straight leg: the way
## the hips face), never behind the hips (`fwd`, flat, skeleton space). Taken off the line to the held ankle instead,
## a held foot ahead of the clip's put the clip's nearly straight knee behind that line: the knee bent backward, then
## came forward in a frame. Returns where its toes are (skeleton space).
func _solve(sk: Skeleton3D, i: int, hp: Transform3D, U: Transform3D, L: Transform3D, F: Transform3D, rf: Basis,
		ankle: Vector3, toe: Vector3, l1: float, l2: float, down: Vector3, fwd: Vector3) -> Vector3:
	var ids: Array = _ids[i]
	var hip := U.origin + down
	var knee := L.origin + down
	var foot := F.origin + down
	var d := ankle - hip
	var dist := clampf(d.length(), absf(l1 - l2) + 0.001, (l1 + l2) * 0.9999)
	var dir := d.normalized() if d.length() > 0.00001 else Vector3.DOWN
	var cd := (foot - hip).normalized() if (foot - hip).length() > 0.00001 else dir
	var pole := (knee - hip) - cd * (knee - hip).dot(cd)
	# the knee's hinge, kept in the thigh's own axes from the clip's leg whenever it is bent: a nearly straight leg bends
	# the way its own knee faces (eased into the hips' way instead, it swung 30 degrees in two frames as the clip's leg
	# came straight in a turn: the leg turned out, the hips not)
	var hc := (knee - hip).cross(foot - knee)
	if hc.length() > HINGE_FROM:
		_hinge[i] = (U.basis.inverse() * hc).normalized()
	var straight := fwd
	if _hinge[i] != Vector3.ZERO:
		var way := cd.cross((U.basis * (_hinge[i] as Vector3)).normalized())
		if way.length() > 0.5:
			straight = way.normalized()
	# the clip's own bend, eased into that as its leg comes straight (no switch from one to the other)
	var w := clampf(pole.length() / STRAIGHT, 0.0, 1.0)
	var want := straight * (1.0 - w)
	if pole.length() > 0.00001:
		want += pole.normalized() * w
	var bend := want - dir * want.dot(dir)
	var front := fwd - dir * fwd.dot(dir)
	if front.length() > 0.001:
		front = front.normalized()
		if bend.dot(front) < 0.0:
			bend -= 2.0 * bend.dot(front) * front     # behind the hips: the same bend, in front
		if bend.length() < 0.001:
			bend = front
	if bend.length() < 0.001:
		bend = Vector3.FORWARD - dir * Vector3.FORWARD.dot(dir)
	bend = bend.normalized()
	var a := (l1 * l1 - l2 * l2 + dist * dist) / (2.0 * dist)
	var k2 := hip + dir * a + bend * sqrt(maxf(0.0, l1 * l1 - a * a))
	var a2 := hip + dir * dist
	var q1 := _arc(knee - hip, k2 - hip)
	var ub := Basis(q1) * U.basis
	var q2 := _arc(q1 * (foot - knee), a2 - k2)
	var lb := Basis(q2) * ub * (U.basis.inverse() * L.basis)
	sk.set_bone_pose_rotation(ids[0], (hp.basis.inverse() * ub).get_rotation_quaternion())
	sk.set_bone_pose_rotation(ids[1], (ub.inverse() * lb).get_rotation_quaternion())
	sk.set_bone_pose_rotation(ids[2], (lb.inverse() * rf).get_rotation_quaternion())
	return a2 + rf * toe


## How far (degrees) a leg of `l1` and `l2` bends at its knee to put its ankle `dist` from its hip.
static func _bend(l1: float, l2: float, dist: float) -> float:
	var dd := clampf(dist, absf(l1 - l2) + 0.001, l1 + l2)
	return 180.0 - rad_to_deg(acos(clampf((l1 * l1 + l2 * l2 - dd * dd) / (2.0 * l1 * l2), -1.0, 1.0)))


static func _arc(a: Vector3, b: Vector3) -> Quaternion:
	if a.length() < 0.00001 or b.length() < 0.00001:
		return Quaternion.IDENTITY
	var an := a.normalized()
	var bn := b.normalized()
	if an.dot(bn) > 0.999999:
		return Quaternion.IDENTITY
	return Quaternion(an, bn)


static func _flat(v: Vector3) -> Vector3:
	var f := Vector3(v.x, 0.0, v.z)
	return f.normalized() if f.length() > 0.00001 else Vector3.ZERO


static func _flat_len(v: Vector3) -> float:
	return Vector2(v.x, v.z).length()


## From facing `a` to `b` (flat), a share `w` of the way round.
static func _turn_flat(a: Vector3, b: Vector3, w: float) -> Vector3:
	if a == Vector3.ZERO or b == Vector3.ZERO:
		return b if b != Vector3.ZERO else a
	return a.rotated(Vector3.UP, a.signed_angle_to(b, Vector3.UP) * clampf(w, 0.0, 1.0))
