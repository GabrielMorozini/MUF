@tool
class_name CordatixBystander
extends CharacterBody3D
## Cordatix PSX Bystanders: one script for every person (Godot 4.3+).
##
## Shows the person in one of its looks with the accessories that look wears (or the ones you pick), plays the clips
## and moves the body at the speed each gait was made for (the clips play in place, so the feet stay planted; a
## one-shot that travels, BackAway, carries it back along its facing as it plays), and does what a spot says
## (CordatixBystanderSpot: sit, type at a desk, stand at a counter, lean on a wall, wait, talk with a partner, queue,
## look at something). It turns its head and chest to the player who comes near, within limits and at most 30 degrees
## a second, stops to talk to the player, and starts, backs away, cowers or flees when told.
##
## In the editor it stands in its idle clip, in the look you pick, with the accessories you tick. What is worn only
## standing (data/people.json "standing": a bag on the back) comes off from SitDown to StandUp and while it leans, where
## it would go through a seat's back or the wall, and is back on when it stands.
## The player is the node in the group "player" (its camera, or `look_target`, is what the head turns to).

signal arrived(spot: Node3D)
signal sat_down
signal stood_up
signal noticed_player(player: Node3D)
signal talked_to(player: Node3D)
signal talk_ended
signal startled
signal backed_away
signal fled
signal bystander_event(event_name: String, data: Dictionary)

## STAY does `idle_clip` where it stands (at `spot`, doing what the spot says, if one is set); SPOT walks to `spot` and
## stays there; WANDER goes from spot to spot (`spots`, or every free spot within `wander_radius`), a while at each.
enum Mode { STAY, SPOT, WANDER }

const DATA_PATH := "res://cordatix/psx_bystanders/data/people.json"
const MATERIALS := "res://cordatix/psx_bystanders/materials/"
const PSX_PATH := "res://cordatix/shared/shaders/psx_materials.gd"
const GROUP := "cordatix_bystander"
const PHONE_CLIPS := ["PhoneLook", "PhoneCall", "SitPhone", "PhoneWalk"]
## The clips that show the carried box (2.0): it is held in both hands, as the phone in the phone clips.
const BOX_CLIPS := ["Carry", "CarryIdle"]
const SEATED := ["SitDown", "Sit", "SitPhone", "SitType", "StandUp", "SitLean", "SitTalk"]
## The clips that take off what is worn only standing: seated, a seat's back would cut through it, leaning, the wall.
const STOWED_IN := ["SitDown", "Sit", "SitPhone", "SitType", "StandUp", "LeanWall", "SitLean", "SitTalk"]
## Loops that start anywhere in their cycle (the rest begin where another clip ends: Sit after SitDown).
const PHASE_FREE := ["Idle", "IdleShift", "IdleWait", "Walk", "Stroll", "Run", "Flee", "Talk", "Listen", "PhoneLook",
	"PhoneWalk", "Carry", "CarryIdle",
	"PhoneCall"]
const SETTLE := 0.6          # metres from a spot where it stops following the navigation mesh and steps onto the mark
const TURN_CLIP_FROM := 50.0  # degrees: a smaller turn is made standing, a larger one with TurnLeft or TurnRight
const GAITS := ["Walk", "Stroll", "Run", "Flee", "PhoneWalk", "Carry"]
## The clips it does not stand in (seated, lying): its feet are the clip's own there (CordatixBystanderFeet off).
const OFF_FEET := ["SitDown", "Sit", "SitPhone", "SitType", "StandUp", "Fall", "SitLean", "SitTalk"]
## The seated loops a SEAT spot chooses among (2.0 adds SitLean; a person without a clip never gets it).
const SEATED_LOOPS := ["Sit", "SitPhone", "SitType", "SitLean", "SitTalk"]
## Under this age a person is a minor (data/people.json "age"; 2.0): no Hit and no Fall among their clips (the build
## bakes none); the rest of the reaction layer is everyone's.
const MINOR_AGE := 18
const START_RAMP := 0.45      # seconds a walk takes to come up to its speed (a run, a step out of the way, two thirds)
const SLOW_FROM := 0.7        # metres before where it is going that it starts to slow down
const URGENT_TURN := 1.8      # how much faster a turn clip plays before an urgent start (a flight, making way)
const LEAVE_CLEAR := 0.7      # metres the one served walks off its mark before the next in line steps up to it
const REVERSE_FROM := 100.0   # degrees: a new way this far off its facing as it walks, it stops and turns first

## Which person this is (a key of data/people.json); the scenes in people/ set it.
@export var person := "office_worker":
	set(v):
		person = v
		_wear.clear()
		data = {}
		_refresh()
		notify_property_list_changed()
## The look: 1, 2 or 3 (data/people.json lists them).
@export_range(1, 3) var look := 1:
	set(v):
		look = clampi(v, 1, 3)
		_wear.clear()
		_refresh()
		notify_property_list_changed()
@export var mode: Mode = Mode.STAY
## STAY: the spot it starts at, doing what it says; SPOT: the spot it walks to.
@export var spot: CordatixBystanderSpot
## WANDER: the spots it goes between (empty: every spot within wander_radius of where it starts).
@export var spots: Array[CordatixBystanderSpot] = []
@export var wander_radius := 12.0
## STAY with no spot: the clip it plays (Idle, IdleShift, IdleWait, PhoneLook, PhoneCall, LeanWall, Cower...).
@export var idle_clip := "Idle":
	set(v):
		idle_clip = v
		_refresh()
## The gait it walks with: Walk, or Stroll (slower), or PhoneWalk (looking at the phone).
@export var walk_clip := "Walk"
## Carries a box (2.0): it walks with Carry and stands with CarryIdle, the box in both hands (it turns standing, so the
## box never leaves its hands on the way); at a spot that is not WAIT, LOOK or QUEUE the box is set aside while it is
## there, and a wanderer that carries one only goes to those.
@export var carrying := false:
	set(v):
		carrying = v
		if anim and not Engine.is_editor_hint() and state in ["idle", "spot"] and clip in ["Idle", "CarryIdle"]:
			_play(_stand_clip(), 0.3)
## Walks looking at the phone (2.0): its walk is PhoneWalk instead of `walk_clip` (a crowd sets it on some of the
## people it lets wander: CordatixBystanderCrowd.phone_walk).
@export var phone_walk := false
## Turns its head and chest to the player who comes within look_distance in front of it.
@export var look_at_player := true
@export var look_distance := 4.0
## What the head turns to (empty: the player's camera; CordatixBystanderLook.default_target for all of them).
@export var look_target: Node3D
## 0 = smooth 30 fps clips; 12 or 15 = PS1-style stepped animation. It can change at run time.
@export var stepped_fps := 0.0:
	set(v):
		stepped_fps = v
		_step_t = 0.0
		_step_held = false
		if anim:
			anim.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL if v > 0.0 \
				else AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_IDLE
		if model and v <= 0.0:
			model.transform = _model_rest
		if look_mod:
			look_mod.stepped_fps = v
		if feet:
			feet.stepped_fps = v
## PS1 vertex snapping and affine textures (the shared PSX shaders).
@export var psx := false:
	set(v):
		psx = v
		_apply_materials()
## Off: it only plays what it is told (a showcase, a cut scene).
@export var behaviour_enabled := true
## Steps aside for the player who walks at it (standing to wait, in a line, looking, talking, or walking its way), and
## back once the player has passed. It never pushes the player: the bodies only meet.
@export var make_way := true
## How far this person's pace may differ from the clips' (each picks its own from its name, within this): its clips
## play that much faster or slower and it walks that much faster or slower, the feet still planted. In a crowd the
## same cycles at the same speed fall into step; 0 keeps every person at the clips' own pace.
@export_range(0.0, 0.15) var pace_spread := 0.06

var data: Dictionary = {}
var _pair_seated := false              # (2.0) seated beside its SEAT partner, the two talking in turn
var _head_node: Node3D = null          # (2.0) head_point()
var anim: AnimationPlayer
var model: Node3D
var skeleton: Skeleton3D
var agent: NavigationAgent3D
var look_mod: CordatixBystanderLook
var feet: CordatixBystanderFeet
## What it is doing: idle, walk, turn, spot, talk_player, react, down.
var state := "idle"
var clip := ""
## The spot it uses, or walks to.
var current_spot: CordatixBystanderSpot

static var _data_cache: Dictionary = {}

var _wear: Dictionary = {}            # accessory -> worn, where the look's default is overridden
var _meshes: Dictionary = {}          # mesh name -> MeshInstance3D
var _materials: Dictionary = {}       # "<look>" / "accessories" -> StandardMaterial3D
var _events: Dictionary = {}
var _last_pos := 0.0
var _clock := 0.0
var _rng := RandomNumberGenerator.new()
var _pace := 1.0
var _gravity: float = ProjectSettings.get_setting("physics/3d/default_gravity", 9.8)
var _model_rest := Transform3D.IDENTITY
var _step_t := 0.0
var _step_held := false
var _step_xform := Transform3D.IDENTITY
var _home := Vector3.ZERO
var _homed := false
# walking
var _dest := Vector3.INF
var _dest_yaw := NAN                  # the way to face once there (NAN: as it arrives)
var _then := Callable()               # what to do once there and turned
var _settling := false
var _walk_t := 0.0
var _walk_limit := 0.0
var _blocked_t := 0.0
var _nav_target := Vector3.INF
# turning
var _turn_from := 0.0
var _turn_need := 0.0                 # degrees still to turn when the turn began
var _turn_clip := ""
var _turn_then := Callable()
# at a spot
var _spot_t := 0.0                    # seconds until the spot's next change of clip
var _stay_t := 0.0                    # WANDER: seconds left at this spot
var _talking := false                 # TALK: its turn to speak
var _talk_t := 0.0
var _queue_t := 0.0
# the player
var _player_near := false
var _aside_from := Vector3.INF        # making way: where it stepped from (INF: not stepping aside)
var _resume := Callable()
# after a reaction (backing away, cowering, a flight) it goes back to the spot it left (taken meanwhile: another)
var _return_spot: CordatixBystanderSpot = null
var _return_t := -1.0                 # seconds until it walks back (-1: not waiting)
var _fleeing := false
var _placed := false                  # placed already (place_at_spot, load_save): _begin leaves it where it is
# _begin has run: it does nothing on its own before (made a physics frame into a level, a wanderer took a spot given to
# another before that one began)
var _begun := false
var _unsettle := Vector3.INF          # leaving a mark off the mesh (by furniture): the first steps, without physics
# a one-shot that travels (BackAway): carried along its facing as it plays
var _carry_clip := ""
var _carry_dir := Vector3.ZERO        # the way it travels (unit, flat)
var _carry_blend := 0.0               # the clip seconds it blends in over
var _carry_done := 0.0                # metres carried so far
var _flee_from := Vector3.ZERO
var _rate := 1.0                      # the gait's playback against its own speed: the body's speed over the gait's
var _ramp_t := 0.0                    # seconds since it set off (or walked on after being held up)
var _gait := ""                       # the gait of the walk it is on
var _urgent := false                  # a flight or a step out of the player's way: turns quicker, sets off at once
var _startle_yaw := NAN               # a start: the way it turns to, over the clip's first 0.15 s
var _arrive_t := 0.0                  # arrived and about to turn: seconds it has stood for its feet to come together
var _arrive_yaw := 0.0                # the way it turns to then
var _arrive_then := Callable()


static func load_data() -> Dictionary:
	if _data_cache.is_empty():
		var f := FileAccess.open(DATA_PATH, FileAccess.READ)
		if f:
			_data_cache = JSON.parse_string(f.get_as_text())
	return _data_cache


## Every person's key in data/people.json (sorted).
static func people() -> Array:
	var keys := load_data().keys()
	keys.sort()
	return keys


## Tells every person within `radius` of `pos` that something happened there: "startle", "back_away", "cower" or
## "flee".
static func alarm(tree: SceneTree, pos: Vector3, radius: float, reaction := "startle") -> void:
	for b in tree.get_nodes_in_group(GROUP):
		if not is_instance_valid(b) or b.is_queued_for_deletion() or not b is CordatixBystander:
			continue
		if b.global_position.distance_to(pos) <= radius:
			match reaction:
				"cower":
					b.cower()
				"flee":
					b.flee(pos)
				"back_away":
					b.back_away(pos)
				_:
					b.startle(pos)


# -------------------------------------------------------------------------------------------- setup
func _ready() -> void:
	_find_parts()
	_refresh()
	if Engine.is_editor_hint():
		return
	add_to_group(GROUP)
	_rng.seed = hash(name) * 31 + hash(person)
	_pace = 1.0 + _rng.randf_range(-pace_spread, pace_spread)
	if data.is_empty():
		push_error("CordatixBystander: no data for person '%s'" % person)
		return
	if skeleton:
		feet = CordatixBystanderFeet.new()
		feet.name = "Feet"
		feet.stepped_fps = stepped_fps
		skeleton.add_child(feet)
		look_mod = CordatixBystanderLook.new()
		look_mod.name = "Look"
		look_mod.stepped_fps = stepped_fps
		skeleton.add_child(look_mod)
	if anim:
		if stepped_fps > 0.0:
			anim.callback_mode_process = AnimationMixer.ANIMATION_CALLBACK_MODE_PROCESS_MANUAL
		anim.speed_scale = _pace
		anim.animation_finished.connect(_on_finished)
	if agent:
		agent.path_desired_distance = 0.35
		agent.target_desired_distance = 0.1
	if spot and behaviour_enabled:
		# its spot is its own from now on, wherever it stands in the tree: a crowd filling itself once the level is ready
		# skips it (a level's own person after the crowd in the tree began after the crowd had given its spot away, and
		# stood inside the one there)
		spot.claim(self)
	_begin.call_deferred()


func _find_parts() -> void:
	data = load_data().get(person, {})
	model = get_node_or_null("Model")
	if model:
		_model_rest = model.transform
		anim = model.find_child("AnimationPlayer", true, false)
		skeleton = model.find_child("Skeleton3D", true, false)
		_meshes.clear()
		for n in model.find_children("*", "MeshInstance3D", true, false):
			_meshes[String(n.name)] = n
	agent = get_node_or_null("NavigationAgent3D")
	_events.clear()
	if anim:
		for c in data.get("clips", {}):
			var info: Dictionary = data["clips"][c]
			_events[c] = info.get("events", [])
			if anim.has_animation(c):
				anim.get_animation(c).loop_mode = Animation.LOOP_LINEAR if info.get("loop", false) \
					else Animation.LOOP_NONE


func _refresh() -> void:
	if not is_inside_tree():
		return
	if model == null or data.is_empty():
		_find_parts()
	if data.is_empty():
		return
	_apply_look()
	if Engine.is_editor_hint() and anim and anim.has_animation(idle_clip):
		anim.play(idle_clip)
		anim.seek(0.0, true)
		anim.pause()


# -------------------------------------------------------------------------------------------- looks
## The looks' data (key, name, role, note, mesh, triangles, wears).
func looks() -> Array:
	return data.get("looks", [])


func look_key() -> String:
	var ls := looks()
	return ls[clampi(look - 1, 0, ls.size() - 1)]["key"] if ls.size() > 0 else ""


## Whether this person is under MINOR_AGE (2.0: the children and the teenagers; no Hit and no Fall among their clips).
func is_minor() -> bool:
	# (2.0) from the person's own data even before its _ready (a game spawning people gates on it at once)
	var d: Dictionary = data if not data.is_empty() else load_data().get(person, {})
	return float(d.get("age", 40)) < MINOR_AGE


## Whether this person has the clip `c` (a minor has no Hit and no Fall; 1.0's people's files have 1.0's 31).
func has_clip(c: String) -> bool:
	if anim == null:
		# (2.0) before its _ready: from the data's clips (a minor's have no Hit and no Fall)
		var d: Dictionary = data if not data.is_empty() else load_data().get(person, {})
		return c in d.get("clips", [])
	return anim.has_animation(c)


## Whether `acc` belongs to a look's role (data/people.json "role": a helmet, a police cap, a medical bag): a crowd keeps
## it with its own look (2.0).
func role_accessory(acc: String) -> bool:
	return bool(data.get("accessories", {}).get(acc, {}).get("role", false))


## What it stands in between things: CarryIdle while it carries a box, else Idle.
func _stand_clip() -> String:
	return "CarryIdle" if carrying and has_clip("CarryIdle") else "Idle"


## The gait it walks with: Carry while it carries, PhoneWalk if it walks on the phone, else walk_clip.
func _walk_gait() -> String:
	if carrying and has_clip("Carry"):
		return "Carry"
	if phone_walk and has_clip("PhoneWalk"):
		return "PhoneWalk"
	return walk_clip


## The accessories this person has (keys), the phone among them.
func accessory_keys() -> Array:
	return data.get("accessories", {}).keys()


## Whether the look wears `acc` unless told otherwise.
func default_wear(acc: String) -> bool:
	var ls := looks()
	if ls.is_empty():
		return false
	return acc in ls[clampi(look - 1, 0, ls.size() - 1)].get("wears", [])


func wears(acc: String) -> bool:
	return _wear.get(acc, default_wear(acc))


## Whether `acc` is worn only standing (data/people.json: a bag on the back): off while it sits or leans.
func standing_only(acc: String) -> bool:
	return bool(data.get("accessories", {}).get(acc, {}).get("standing", false))


## Whether `acc` shows now: the phone in the phone clips; the rest when worn, unless it is worn only standing and the
## person sits or leans.
func shows(acc: String) -> bool:
	if acc == "phone":
		return clip in PHONE_CLIPS
	if acc == "box":
		return clip in BOX_CLIPS
	return wears(acc) and not (standing_only(acc) and clip in STOWED_IN)


func set_look(n: int) -> void:
	look = n


func set_accessory(acc: String, on: bool) -> void:
	if acc == "phone" or acc == "box":
		return                     # the phone comes with the phone clips, the box with the carry clips
	_wear[acc] = on
	_apply_look()


func _apply_look() -> void:
	var lk := look_key()
	for l in looks():
		var m: MeshInstance3D = _meshes.get(l["mesh"])
		if m:
			m.visible = l["key"] == lk
	_show_accessories()
	_apply_materials()


func _show_accessories() -> void:
	var acc: Dictionary = data.get("accessories", {})
	for a in acc:
		var m: MeshInstance3D = _meshes.get(acc[a]["mesh"])
		if m:
			m.visible = shows(a)


func _material(which: String) -> Material:
	var mat: Material = _materials.get(which)
	if mat == null:
		var path := MATERIALS + "%s_%s.tres" % [person, which]
		if ResourceLoader.exists(path):
			mat = load(path)
			_materials[which] = mat
	if mat and psx and mat is StandardMaterial3D:
		var key := "psx_" + which
		if not _materials.has(key):
			_materials[key] = load(PSX_PATH).to_psx(mat)
		return _materials[key]
	return mat


func _apply_materials() -> void:
	if data.is_empty():
		return
	for l in looks():
		var m: MeshInstance3D = _meshes.get(l["mesh"])
		if m:
			m.set_surface_override_material(0, _material(l["key"]))
	var acc: Dictionary = data.get("accessories", {})
	for a in acc:
		var m: MeshInstance3D = _meshes.get(acc[a]["mesh"])
		if m:
			m.set_surface_override_material(0, _material("accessories"))


func set_psx(on: bool) -> void:
	psx = on


# the accessories as properties of their own: ticked in the inspector, saved with the scene
func _get_property_list() -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for a in accessory_keys():
		if a != "phone" and a != "box":
			out.append({"name": "wear_" + a, "type": TYPE_BOOL, "usage": PROPERTY_USAGE_DEFAULT})
	return out


func _get(p: StringName) -> Variant:
	var s := String(p)
	if s.begins_with("wear_") and s.substr(5) in accessory_keys():
		return wears(s.substr(5))
	return null


func _set(p: StringName, v: Variant) -> bool:
	var s := String(p)
	if s.begins_with("wear_"):
		_wear[s.substr(5)] = bool(v)
		_apply_look()
		return true
	return false


func _property_can_revert(p: StringName) -> bool:
	return String(p).begins_with("wear_")


func _property_get_revert(p: StringName) -> Variant:
	return default_wear(String(p).substr(5))


# -------------------------------------------------------------------------------------------- clips
## Plays `c`, blending over `blend` seconds. With `at` (seconds) it starts there (a gait at a foot's mid-stance, Idle
## after a turn at its first frame); else a loop free to start anywhere starts anywhere in its cycle.
func _play(c: String, blend := 0.25, at := -1.0) -> void:
	if anim == null or not anim.has_animation(c):
		return
	var looped := anim.get_animation(c).loop_mode != Animation.LOOP_NONE
	if looped and c == clip and anim.current_animation == c and anim.is_playing():
		return
	clip = c
	if not c in GAITS:
		anim.speed_scale = _pace           # a gait plays at the speed the body moves (_match_rate)
	anim.play(c, blend)
	_last_pos = 0.0 if looped else -0.001
	_carry_clip = ""
	if not looped and absf(clip_speed(c)) > 0.001:
		var f := _flat(-global_transform.basis.z).normalized()
		_carry_clip = c
		_carry_dir = f * signf(clip_speed(c))
		_carry_blend = blend
		_carry_done = 0.0
	if at >= 0.0:
		anim.seek(at, false)
		_last_pos = at
	elif looped and c in PHASE_FREE and pace_spread > 0.0:
		# a loop that follows no other clip's last pose starts anywhere in its cycle: people who start talking
		# together are not in step
		var r := _rng.randf() * anim.get_animation(c).length
		anim.seek(r, false)
		_last_pos = r
	_step_t = 0.0
	_show_accessories()
	if feet:
		feet.weight = 0.0 if c in OFF_FEET else 1.0
		feet.hold_facing = not c in GAITS


## Plays a clip as it is (a showcase, a cut scene): turn the behaviour off first, or it carries on after. A one-shot
## that travels (BackAway) carries the body with it, as in a reaction.
func play(c: String, blend := 0.2) -> void:
	_play(c, blend)


func clip_length(c: String) -> float:
	return float(data.get("clips", {}).get(c, {}).get("length", 1.0))


## The speed (m/s) this person moves at in a gait: the clip's own, times its pace.
func clip_speed(c: String) -> float:
	return float(data.get("clips", {}).get(c, {}).get("speed", 0.0)) * _pace


## This person's pace (1.0: the clips' own).
func pace() -> float:
	return _pace


func _process(delta: float) -> void:
	if Engine.is_editor_hint() or anim == null:
		return
	_hold_model()
	_fire_events()


func _fire_events() -> void:
	if clip == "" or not anim.is_playing():
		return
	var pos := anim.current_animation_position
	var evs: Array = _events.get(clip, [])
	if pos < _last_pos:
		for e in evs:
			if e[0] > _last_pos:
				_event(e[1], e[2])
		_last_pos = -0.001
	for e in evs:
		if e[0] > _last_pos and e[0] <= pos:
			_event(e[1], e[2])
	_last_pos = pos


func _event(n: String, d) -> void:
	var dd: Dictionary = d if d is Dictionary else {}
	match n:
		"sit":
			sat_down.emit()
		"stand":
			stood_up.emit()
	bystander_event.emit(n, dd)


func _step_pose(delta: float) -> void:
	## Stepped animation: the pose moves on in steps, and the model with it; between two steps the model stays where
	## the body was at the last one, so a planted foot stays planted while the body moves on underneath.
	if stepped_fps <= 0.0 or anim == null:
		return
	if not _step_held or not anim.is_playing():
		_step_xform = global_transform
		_step_held = true
	if anim.is_playing():
		_step_t += delta
		var step := 1.0 / stepped_fps
		if _step_t >= step - 0.0001:
			while _step_t >= step - 0.0001:
				anim.advance(step)
				_step_t -= step
			if _carry_clip != "":
				_carry(delta)                # with the step: the model is held where the body is now
			_step_xform = global_transform
	_hold_model()


func _hold_model() -> void:
	if stepped_fps > 0.0 and _step_held and model:
		model.global_transform = _step_xform * _model_rest


# -------------------------------------------------------------------------------------------- the brain
func _begin() -> void:
	if is_queued_for_deletion():
		return                          # taken out before it began (a crowd's populate() or load_save() again)
	if not is_inside_tree():
		if not tree_entered.is_connected(_begin):
			tree_entered.connect(_begin, CONNECT_ONE_SHOT | CONNECT_DEFERRED)     # it begins once it is back in
		return
	_begun = true
	_home = global_position
	if _placed:
		# place_at_spot() or load_save() put it where it belongs before it began (a level's own _ready, a crowd's
		# load): it carries on from there
		if mode == Mode.WANDER and _stay_t <= 0.0:
			_stay_t = _rng.randf_range(4.0, 12.0)
		return
	if not behaviour_enabled:
		_play(idle_clip, 0.0)
		return
	# a spot someone else holds already: the nearest free one of its kind, at once (not left where it was made)
	var at := spot
	if at and not at.claim(self):
		at = _nearest_free([at.kind])
		if at and mode != Mode.SPOT:
			at.claim(self)
	match mode:
		Mode.STAY:
			if at:
				place_at_spot(at)
			else:
				_go_idle()
		Mode.SPOT:
			if at:
				use_spot(at)
			else:
				_go_idle()
		Mode.WANDER:
			if at:
				place_at_spot(at)
				_stay_t = _rng.randf_range(at.stay.x, at.stay.y)
			else:
				_go_idle()
				_stay_t = _rng.randf_range(1.0, 4.0)


func _go_idle(c := "") -> void:
	state = "idle"
	_play(c if c != "" else (_stand_clip() if idle_clip == "Idle" else idle_clip))


## Lets go of the spot it held from its _ready (`spot`) when it is put somewhere else before it began (a save loaded,
## place_at_spot()).
func _release_early(keep: CordatixBystanderSpot) -> void:
	if not _begun and spot and spot != keep and is_instance_valid(spot) and spot.occupant == self:
		spot.release(self)


## Walks to `pos` (on the navigation mesh), and calls `then` once there. With `yaw` (radians) it turns to it first.
func go_to(pos: Vector3, then := Callable(), yaw := NAN) -> void:
	_leave_spot_now()
	_start_walk(pos, then, yaw)


func _start_walk(pos: Vector3, then: Callable, yaw: float, gait := "") -> void:
	if state == "spot" and clip in SEATED:
		_stand_then(_start_walk.bind(pos, then, yaw, gait))     # seated: up first
		return
	var moving := state == "walk" and clip in GAITS
	_dest = pos
	_dest_yaw = yaw
	_then = then
	_settling = false
	_gait = gait if gait != "" else _walk_gait()
	_fleeing = _gait == "Flee"
	_urgent = _gait in ["Run", "Flee"] or _aside_from != Vector3.INF
	_walk_t = 0.0
	_blocked_t = 0.0
	_nav_target = Vector3.INF
	# standing on a mark off the navigation mesh (by a seat, a desk, a counter, a wall: the mesh keeps its agent's
	# radius from them), the first steps go to the mesh without physics, as the last steps onto a mark do: a clerk between
	# a desk and a chair, both solid, could not get out of them by walking
	_unsettle = Vector3.INF
	var m := _on_mesh(global_position)
	var off := _flat(m - global_position).length()
	if off > 0.05 and off <= 0.9:
		_unsettle = Vector3(m.x, global_position.y, m.z)
	var length := _flat(pos - global_position).length()
	_walk_limit = length * 2.5 / maxf(clip_speed(_gait), 0.3) + 4.0
	state = "walk"
	if length < 0.05 and _unsettle == Vector3.INF and not moving:
		_arrive()                          # there already: only the turn, if any
		return
	# it sets off the way its path leads: a way more than TURN_CLIP_FROM off its facing it turns to first, with the turn
	# clips (quicker when urgent), and the walk starts straight (turning as it set off, its feet slid 0.3-0.45 m). On its
	# way already, a new way more than REVERSE_FROM off its facing (back the way it came) it stops for and turns to as
	# from standing (turning as it walked, its legs crossed and the hips came down 6 cm for the foot left behind)
	var way := _first_way(pos)
	if way != Vector3.ZERO:
		var yaw_to := atan2(-way.x, -way.z)
		var turn := absf(rad_to_deg(wrapf(yaw_to - rotation.y, -PI, PI)))
		if not moving and turn >= TURN_CLIP_FROM:
			_turn_to(yaw_to, _set_off)
			return
		if moving and turn >= REVERSE_FROM:
			_stop_then_turn(yaw_to)
			return
	if moving:
		# already on its way (a flight while it walks, a step round the player): it turns as it goes
		if clip != _gait:
			_ramp_t = minf(_ramp_t, 0.15)    # into another gait: up to its speed again
			_play(_gait, 0.2, _gait_start(_gait))
		return
	_set_off()


## Stops where it walks (its feet come under it), then turns to `yaw` and sets off on the walk _start_walk set up.
func _stop_then_turn(yaw: float) -> void:
	if feet:
		feet.settle_now()
	velocity = Vector3(0.0, velocity.y, 0.0)
	_play(_stand_clip(), 0.25)
	state = "arrive"
	_arrive_t = 0.0
	_arrive_yaw = yaw
	_arrive_then = _set_off


func _set_off() -> void:
	state = "walk"
	_walk_t = 0.0
	_ramp_t = 0.0
	# a run blends in quickly: its stance is short, and the foot set down in the blend falls behind the body (with 0.15
	# s the hips came down 5 cm for it)
	_play(_gait, 0.1 if _gait in ["Run", "Flee"] else 0.25, _gait_start(_gait))
	_rate = 0.12
	if anim and clip in GAITS:
		anim.speed_scale = _pace * _rate


## The way its path to `pos` sets off from where it stands (flat, unit; zero when it is there): the first corner of the
## navigation mesh's path, or straight there without a mesh.
func _first_way(pos: Vector3) -> Vector3:
	var to := _flat(pos - global_position)
	var map := get_world_3d().navigation_map
	if NavigationServer3D.map_get_iteration_id(map) > 0 and not NavigationServer3D.map_get_regions(map).is_empty():
		var path := NavigationServer3D.map_get_path(map, global_position, pos, true)
		for q in path:
			var d := _flat(q - global_position)
			if d.length() > 0.3:
				to = d
				break
	return to.normalized() if to.length() > 0.05 else Vector3.ZERO


## Where a gait starts: a foot at mid-stance, under the hips with the other foot passing it in the air, the pose nearest
## standing; which foot by chance, a little either way (people setting off together are not in step).
func _gait_start(c: String) -> float:
	var info: Dictionary = data.get("clips", {}).get(c, {})
	var length := maxf(float(info.get("length", 1.0)), 0.01)
	var mids := []
	for st in info.get("stance", []):
		mids.append(fposmod((float(st[1]) + float(st[2])) * 0.5, length))
	if mids.is_empty():
		# no stance times: 0.3 of a stride after each step's event (a walk's mid-stance)
		var ts := []
		for e in info.get("events", []):
			if e[1] == "step":
				ts.append(float(e[0]))
		var half := length / maxf(ts.size(), 1.0)
		for t in ts:
			mids.append(fposmod(t + 0.6 * half, length))
	if mids.is_empty():
		return -1.0
	var m: float = mids[_rng.randi() % mids.size()]
	return fposmod(m + _rng.randf_range(-0.03, 0.03) * length, length)


## Walks to `s` and does what it says there.
func use_spot(s: CordatixBystanderSpot) -> bool:
	if s == null or not s.claim(self):
		return false
	if current_spot and current_spot != s:
		current_spot.release(self)
	current_spot = s
	_start_walk(s.global_position, _arrive_spot.bind(s), s.yaw())
	return true


## Puts it at `s` at once, already doing what the spot says (seated on the seat, at the counter...).
func place_at_spot(s: CordatixBystanderSpot) -> void:
	_release_early(s)
	if current_spot and current_spot != s:
		current_spot.release(self)
	current_spot = s
	s.claim(self)
	_placed = true
	_return_spot = null
	_return_t = -1.0
	global_position = s.global_position
	rotation.y = s.yaw()
	_home = global_position
	_homed = true
	reset_physics_interpolation()
	if feet:
		feet.reset()
	state = "spot"
	_spot_begin(true)


## Leaves its spot (stands up first if seated) and stands where it is.
func leave_spot() -> void:
	if current_spot == null:
		return
	if clip in SEATED:
		_stand_then(_left_spot)
	else:
		_left_spot()


func _left_spot() -> void:
	_leave_spot_now()
	_go_idle()


func _leave_spot_now() -> void:
	if current_spot:
		current_spot.release(self)
	current_spot = null
	_talking = false


func _stand_then(then: Callable) -> void:
	state = "react"
	_resume = then
	_play("StandUp", 0.2)


func _arrive_spot(s: CordatixBystanderSpot) -> void:
	state = "spot"
	arrived.emit(s)
	_spot_begin(false)


func _spot_begin(at_once: bool) -> void:
	var s := current_spot
	if s == null:
		_go_idle()
		return
	_spot_t = _rng.randf_range(6.0, 14.0)
	match s.kind:
		CordatixBystanderSpot.Kind.SEAT, CordatixBystanderSpot.Kind.DESK:
			if at_once:
				_play(_seated_clip(), 0.0)
			else:
				_play("SitDown", 0.15)
		CordatixBystanderSpot.Kind.COUNTER:
			if s.served:
				_queue_t = _rng.randf_range(s.serve_time.x, s.serve_time.y)
			_play("CounterIdle", 0.0 if at_once else 0.3)
		CordatixBystanderSpot.Kind.LEAN:
			_play("LeanWall", 0.0 if at_once else 0.4)
		CordatixBystanderSpot.Kind.TALK:
			_talking = false
			_talk_t = 0.0
			_play("Listen" if _partner() else "IdleShift", 0.0 if at_once else 0.3)
		CordatixBystanderSpot.Kind.QUEUE:
			_queue_t = _rng.randf_range(s.serve_time.x, s.serve_time.y)
			_play("CarryIdle" if carrying and has_clip("CarryIdle") else "IdleShift", 0.0 if at_once else 0.3)
		CordatixBystanderSpot.Kind.LOOK:
			_play(_stand_clip(), 0.0 if at_once else 0.3)
		_:
			_play(_wait_clip(s), 0.0 if at_once else 0.3)


func _seated_clip() -> String:
	var s := current_spot
	if s and s.kind == CordatixBystanderSpot.Kind.DESK:
		return "SitType" if _rng.randf() < 0.75 else "Sit"
	var r := _rng.randf()
	if s and r < s.phone:
		return "SitPhone"
	if s and r < s.phone + s.lean and has_clip("SitLean"):
		return "SitLean"
	return "Sit"


func _wait_clip(s: CordatixBystanderSpot) -> String:
	if carrying and has_clip("CarryIdle"):
		return "CarryIdle"
	var r := _rng.randf()
	if r < s.phone:
		return "PhoneLook" if _rng.randf() < 0.7 else "PhoneCall"
	return ["Idle", "IdleShift", "IdleWait"][_rng.randi() % 3]


func _partner() -> CordatixBystander:
	if current_spot == null or current_spot.partner == null:
		return null
	var o = current_spot.partner.occupant
	if not is_instance_valid(o) or o.is_queued_for_deletion() or not o is CordatixBystander:
		return null
	if o.state == "spot" and o.current_spot == current_spot.partner:
		return o
	return null


func _spot_tick(delta: float) -> void:
	var s := current_spot
	if s == null:
		return
	_spot_t -= delta
	match s.kind:
		CordatixBystanderSpot.Kind.SEAT, CordatixBystanderSpot.Kind.DESK:
			if s.kind == CordatixBystanderSpot.Kind.SEAT and _seat_pair_tick(delta):
				pass
			elif clip in ["Sit", "SitPhone", "SitType", "SitLean", "SitTalk"] and _spot_t <= 0.0:
				_spot_t = _rng.randf_range(8.0, 20.0)
				_play(_seated_clip(), 0.4)
		CordatixBystanderSpot.Kind.TALK:
			_talk_tick(delta)
		CordatixBystanderSpot.Kind.COUNTER:
			if s.served:
				_served_tick(delta)
		CordatixBystanderSpot.Kind.QUEUE:
			_queue_tick(delta)
		CordatixBystanderSpot.Kind.WAIT:
			if _spot_t <= 0.0 and anim.get_animation(clip).loop_mode != Animation.LOOP_NONE:
				_spot_t = _rng.randf_range(6.0, 14.0)
				var c := _wait_clip(s)
				if _rng.randf() < 0.2 and not carrying:
					c = "LookAround"
				_play(c, 0.35)
		CordatixBystanderSpot.Kind.LOOK:
			if _spot_t <= 0.0 and clip == "Idle":
				_spot_t = _rng.randf_range(8.0, 16.0)
				_play("IdleShift" if _rng.randf() < 0.5 else "LookAround", 0.35)
	if mode == Mode.WANDER and not (s.kind == CordatixBystanderSpot.Kind.QUEUE or
			(s.kind == CordatixBystanderSpot.Kind.COUNTER and s.served)):
		# (in a line, or at a served counter, it stays until it is served: then it leaves)
		_stay_t -= delta
		if _stay_t <= 0.0 and not clip in ["SitDown", "StandUp", "Nod", "LookAround"]:
			_wander_next()


func _talk_tick(delta: float) -> void:
	var p := _partner()
	if p == null:
		_talking = false
		if not clip in ["IdleShift", "PhoneLook"]:
			_play("IdleShift", 0.35)
		return
	# the one of the pair with the lower id leads: it says whose turn it is
	if get_instance_id() < p.get_instance_id():
		_talk_t -= delta
		if _talk_t <= 0.0:
			var me := not _talking
			_talk_t = _rng.randf_range(3.0, 7.0)
			_set_talking(me)
			p._set_talking(not me)
	if not _talking and clip == "Listen" and _rng.randf() < delta * 0.12:
		_play("Nod", 0.2)


func _set_talking(on: bool) -> void:
	_talking = on
	if state == "spot" and not clip in ["Nod"]:
		_play("Talk" if on else "Listen", 0.35)


## SEAT with a `partner` (2.0): two seats side by side, both taken and both seated: they take turns, the one talking
## SitTalk, the other Sit, their heads turned to each other. False when there is no seated pair (each seat then does
## what a seat does).
func _seat_pair_tick(delta: float) -> bool:
	if current_spot == null or current_spot.partner == null or not has_clip("SitTalk"):
		_pair_seated = false
		return false
	var p := _partner()
	if p == null or not p.has_clip("SitTalk") or clip in ["SitDown", "StandUp"] or p.clip in ["SitDown", "StandUp"] \
			or not p.clip in SEATED_LOOPS:
		if _pair_seated:
			_pair_seated = false
			_talking = false
			if clip == "SitTalk":
				_play("Sit", 0.4)
		return false
	_pair_seated = true
	# the one of the pair with the lower id leads: it says whose turn it is
	if get_instance_id() < p.get_instance_id():
		_talk_t -= delta
		if _talk_t <= 0.0:
			var me := not _talking
			_talk_t = _rng.randf_range(3.0, 7.0)
			_set_seat_talking(me)
			p._set_seat_talking(not me)
	return true


func _set_seat_talking(on: bool) -> void:
	_talking = on
	_pair_seated = true
	if state == "spot" and clip in SEATED_LOOPS:
		var want := "SitTalk" if on else "Sit"
		if clip != want:
			_play(want, 0.4)


## A node at this person's head (a seated partner turns its head to it; 2.0).
func head_point() -> Node3D:
	if _head_node == null and skeleton and skeleton.find_bone("Head") >= 0:
		var ba := BoneAttachment3D.new()
		ba.name = "HeadPoint"
		ba.bone_name = "Head"
		skeleton.add_child(ba)
		_head_node = ba
	return _head_node


## The seated partner's head while the two talk, else null.
func _pair_head() -> Node3D:
	if not _pair_seated:
		return null
	var p := _partner()
	return p.head_point() if p else null


func _queue_tick(delta: float) -> void:
	var s := current_spot
	if s.ahead and s.ahead.is_free() and not clip in ["Walk", "Stroll"] and _mark_clear(s.ahead):
		use_spot(s.ahead)                      # the place ahead is free and the one served off it: step up
		return
	if s.ahead == null:
		_served_tick(delta)


## Whether nobody stands within LEAVE_CLEAR of `s`'s mark: the one served there has turned and walked off it (stepping
## up as soon as the spot was free, the next walked into the one turning on the mark to leave).
func _mark_clear(s: CordatixBystanderSpot) -> bool:
	for n in get_tree().get_nodes_in_group(GROUP):
		if n != self and n is Node3D and _flat((n as Node3D).global_position - s.global_position).length() < LEAVE_CLEAR:
			return false
	return true


## The head of a line (a QUEUE spot with none ahead, or a served COUNTER): done after serve_time, it leaves.
func _served_tick(delta: float) -> void:
	_queue_t -= delta
	if _queue_t <= 0.0:
		_queue_t = 1e9
		_wander_next(true)


## WANDER: on to another free spot (or a few metres away if there is none). `leaving`: done at the head of a line
## or at a served counter, it goes anywhere but a line or a counter (not back to the end of its own line).
func _wander_next(leaving := false) -> void:
	var pool: Array = spots.duplicate()
	if pool.is_empty():
		for n in get_tree().get_nodes_in_group(CordatixBystanderSpot.GROUP):
			if n is CordatixBystanderSpot and n.global_position.distance_to(_home) <= wander_radius:
				pool.append(n)
	var free: Array = []
	for s in pool:
		if s == current_spot or not s.is_free() or s.reserved:
			continue
		if leaving:
			if s.kind == CordatixBystanderSpot.Kind.QUEUE or (s.kind == CordatixBystanderSpot.Kind.COUNTER and s.served):
				continue
		elif not _can_join(s):
			continue
		if carrying and not s.kind in [CordatixBystanderSpot.Kind.WAIT, CordatixBystanderSpot.Kind.LOOK,
				CordatixBystanderSpot.Kind.QUEUE]:
			continue
		free.append(s)
	if free.is_empty():
		_stay_t = _rng.randf_range(3.0, 6.0)
		if leaving:
			# out of the line to one side and a little ahead (a random way led some back through the line); from a
			# counter, to one side and back from it: a place on the mesh nobody stands on or goes to (two served in
			# a row went to one of two points and stood inside each other)
			var f := -current_spot.global_basis.z if current_spot else Vector3.FORWARD
			f = Vector3(f.x, 0.0, f.z).normalized()
			var first := 1.0 if _rng.randf() < 0.5 else -1.0
			var at_counter := current_spot != null and current_spot.kind == CordatixBystanderSpot.Kind.COUNTER
			var tries: Array = []
			for k in 6:
				var sd := Vector3(-f.z, 0.0, f.x) * (first if k % 2 == 0 else -first)
				var out := 2.2 + 0.5 * floorf(k / 2.0) + _rng.randf() * 0.4
				tries.append(_on_mesh(global_position + sd * out + f * ((-1.0 if at_counter else 1.0)
					* (0.6 + _rng.randf() * 0.8))))
			go_to(_free_place(tries))
		return
	var next: CordatixBystanderSpot = free[_rng.randi() % free.size()]
	_stay_t = _rng.randf_range(next.stay.x, next.stay.y)
	use_spot(next)


## A wanderer's next spot: a line only at its end, a served counter only with nobody waiting in line for it.
func _can_join(s: CordatixBystanderSpot) -> bool:
	if s.kind == CordatixBystanderSpot.Kind.QUEUE:
		return s.ahead == null or not s.ahead.is_free()
	if s.kind == CordatixBystanderSpot.Kind.COUNTER and s.served:
		for n in get_tree().get_nodes_in_group(CordatixBystanderSpot.GROUP):
			if n is CordatixBystanderSpot and n.ahead == s and not n.is_free():
				return false
	return true


# -------------------------------------------------------------------------------------------- making way
## The kinds of spot it stands at and may step off for the player (not a seat, a desk, a counter or a wall).
const MAKE_WAY_KINDS := [CordatixBystanderSpot.Kind.WAIT, CordatixBystanderSpot.Kind.QUEUE,
	CordatixBystanderSpot.Kind.LOOK, CordatixBystanderSpot.Kind.TALK]


func _make_way_check() -> void:
	if _aside_from != Vector3.INF:
		if not state in ["walk", "turn", "aside"]:
			_aside_from = Vector3.INF             # something else took over (a talk, a fright): no more stepping aside
		return
	if state == "spot":
		if current_spot == null or not current_spot.kind in MAKE_WAY_KINDS or clip in SEATED:
			return
	elif state != "idle":
		return
	var p := _player()
	if p == null or not "velocity" in p:
		return
	var off := _flat(global_position - p.global_position)
	var pv := _flat(p.velocity)
	var d := off.length()
	# the player walks at it: within the distance the player covers in 1.3 s, 1.8 s facing them (it turns aside first),
	# 1.6 to 4 m (a step aside starts slowly, its feet planted: from 1.8 m the player at the demo's 2.4 m/s caught up
	# with it), coming on at a walk, its way passing within 0.7 m of it
	var fwd := _flat(-global_transform.basis.z).normalized()
	var lead := 1.3 + 0.5 * clampf(fwd.dot(-pv.normalized()), 0.0, 1.0) if pv.length() > 0.01 else 1.3
	var reach := clampf(pv.length() * lead, 1.6, 4.0)
	if d > reach or d < 0.01 or pv.length() < 0.6 or off.dot(pv.normalized()) < 0.3:
		return
	var across := off - pv.normalized() * off.dot(pv.normalized())
	if across.length() > 0.7:
		return
	_step_aside(pv)


## How far off the player's way a step aside takes it (from its middle to the line the player walks).
const ASIDE_CLEAR := 0.9


func _step_aside(way: Vector3) -> void:
	## Off the player's way, then back once they have passed: to the side of the way it stands on (across it only where
	## that side is walled), straight aside or aside and on along the player's way, whichever it turns to the least:
	## facing the way the player goes it walks off at 45 degrees as it stands, facing the player it turns aside
	## first. Never back toward the player; where no place 0.8 m off the way is free of walls, it stays.
	var p := _player()
	var pd := _flat(way).normalized()
	var side := Vector3(-pd.z, 0.0, pd.x)
	var off := _flat(global_position - p.global_position)
	if off.dot(side) < 0.0:
		side = -side
	var lat := (off - pd * off.dot(pd)).length()
	var fwd := _flat(-global_transform.basis.z).normalized()
	var to := Vector3.INF
	for s in [side, -side]:
		var step := maxf(ASIDE_CLEAR - lat, 0.6) if s == side else ASIDE_CLEAR + lat
		var best := INF
		for ahead in [0.0, step]:
			var q := _on_mesh(global_position + s * step + pd * ahead)
			var go := _flat(q - global_position)
			var rel := _flat(q - p.global_position)
			if go.length() < 0.25 or (rel - pd * rel.dot(pd)).length() < ASIDE_CLEAR - 0.1:
				continue                     # walled: it would still stand in the way
			var turn := absf(fwd.signed_angle_to(go.normalized(), Vector3.UP))
			if turn < best:
				best = turn
				to = q
		if to != Vector3.INF:
			break
	if to == Vector3.INF:
		return
	_aside_from = global_position
	_start_walk(to, func(): state = "aside", NAN)


func _on_mesh(p: Vector3) -> Vector3:
	## The nearest point to `p` on the navigation mesh, or `p` where there is none (a level without one).
	var map := get_world_3d().navigation_map
	if NavigationServer3D.map_get_iteration_id(map) == 0 or NavigationServer3D.map_get_regions(map).is_empty():
		return p
	return NavigationServer3D.map_get_closest_point(map, p)


## The first of `places` that no other person stands on or walks to (0.75 m); the first if none is free.
func _free_place(places: Array) -> Vector3:
	for p in places:
		var taken := false
		for b in get_tree().get_nodes_in_group(GROUP):
			if b == self or not is_instance_valid(b) or b.is_queued_for_deletion() or not b is CordatixBystander:
				continue
			if _flat(b.global_position - p).length() < 0.75 or \
					(b._dest != Vector3.INF and _flat(b._dest - p).length() < 0.75):
				taken = true
				break
		if not taken:
			return p
	return places[0]


## Where a flight goes: on the navigation mesh, 7 to 10 m from where it stands, the reachable place furthest from
## `from` of seven ways tried round straight away from it (its own way first: people flee apart); INF where none is
## 3 m off or reachable (it cowers where it stands). A level without a mesh: straight away (its walls stop it).
func _flee_goal(from: Vector3) -> Vector3:
	var away := _flat(global_position - from)
	away = away.normalized() if away.length() > 0.05 else _flat(-global_transform.basis.z).normalized()
	var reach := _rng.randf_range(7.0, 10.0)
	var map := get_world_3d().navigation_map
	if NavigationServer3D.map_get_iteration_id(map) == 0 or NavigationServer3D.map_get_regions(map).is_empty():
		return global_position + away * reach
	var start := NavigationServer3D.map_get_closest_point(map, global_position)
	var best := Vector3.INF
	var best_score := -INF
	for deg in [0.0, 30.0, -30.0, 60.0, -60.0, 90.0, -90.0]:
		var dir := away.rotated(Vector3.UP, deg_to_rad(deg))
		var p := NavigationServer3D.map_get_closest_point(map, global_position + dir * reach)
		var go := _flat(p - global_position)
		if go.length() < 3.0:
			continue
		var path := NavigationServer3D.map_get_path(map, start, p, true)
		if path.is_empty() or _flat(path[path.size() - 1] - p).length() > 0.5:
			continue
		var score := _flat(p - from).length() + 0.5 * go.dot(away)
		if score > best_score:
			best_score = score
			best = p
	return best


func _player_ahead(dist: float) -> bool:
	var p := _player()
	if p == null:
		return false
	var to := _flat(p.global_position - global_position)
	return to.length() < dist and (-global_transform.basis.z).dot(to.normalized()) > 0.5


## The player or another person within `dist` in front of it (what holds up a walk).
func _someone_ahead(dist: float) -> bool:
	if _player_ahead(dist):
		return true
	var fwd := _flat(-global_transform.basis.z).normalized()
	for b in get_tree().get_nodes_in_group(GROUP):
		if b == self or not is_instance_valid(b) or b.is_queued_for_deletion() or not b is CordatixBystander:
			continue
		var to := _flat(b.global_position - global_position)
		if to.length() < dist and fwd.dot(to.normalized()) > 0.5:
			return true
	return false


## Whether nobody else stands within `r` of `p` (floor distance).
func _room_at(p: Vector3, r: float) -> bool:
	for b in get_tree().get_nodes_in_group(GROUP):
		if b != self and b is Node3D and is_instance_valid(b) and _flat((b as Node3D).global_position - p).length() < r:
			return false
	return true


func _side_step_walk() -> bool:
	## Walking into the player or another person: a step to its right (off their way), then on to where it was going,
	## in the gait it went in.
	## (2.0) A side with someone standing there is no way round (in a gap between a wall and a person at a spot, two
	## coming the other way stood in it for good: the side step went into the one at the spot); with neither side
	## free it steps back the way it came, a random way back, to let the other by. Returns whether it stepped.
	var resume := [_dest, _then, _dest_yaw, _gait]
	var fwd := _flat(-global_transform.basis.z).normalized()
	var right := Vector3(-fwd.z, 0.0, fwd.x)
	var to := Vector3.INF
	for side in [right, -right]:
		var t := _on_mesh(global_position + side * 0.7)
		if _flat(t - global_position).length() >= 0.35 and _room_at(t, 0.5):
			to = t
			break
	if to == Vector3.INF:
		to = _on_mesh(global_position - fwd * _rng.randf_range(0.6, 1.2))
		if _flat(to - global_position).length() < 0.35 or not _room_at(to, 0.5):
			return false                          # (nor back into someone behind it)
	_aside_from = global_position
	_start_walk(to, func():
		_aside_from = Vector3.INF
		_start_walk(resume[0], resume[1], resume[2], resume[3]), NAN)
	return true


func _aside_tick() -> void:
	## Stood aside: back to the spot (or where it stood) once the player is 1.6 m away.
	var p := _player()
	if p and _flat(p.global_position - global_position).length() < 1.6:
		return
	_aside_from = Vector3.INF
	if current_spot and current_spot.occupant == self:
		_back_to(current_spot)
	else:
		_go_idle()


# -------------------------------------------------------------------------------------------- saves
## What it is and where it is, to put it back as it was (load_save): the person, the look, the accessories it wears
## other than the look's own, its spot (by path), the clip, where it stands, the look at the player.
func get_save() -> Dictionary:
	return {"person": person, "look": look, "wear": _wear.duplicate(), "mode": int(mode),
		"spot": String(get_path_to(current_spot)) if current_spot else "", "clip": clip, "state": state,
		"position": [global_position.x, global_position.y, global_position.z], "yaw": rotation.y,
		"look_at_player": look_at_player}


## Puts it back as get_save() found it: at its spot doing what the spot says (seated on its seat, in its line...), or
## where it stood in the clip it played.
func load_save(d: Dictionary) -> void:
	if d.get("person", person) != person:
		person = String(d["person"])
	look = int(d.get("look", look))
	_wear.clear()
	var w: Dictionary = d.get("wear", {})
	for a in w:
		_wear[a] = bool(w[a])
	_apply_look()
	mode = int(d.get("mode", mode)) as Mode
	look_at_player = bool(d.get("look_at_player", look_at_player))
	var at: Array = d.get("position", [])
	if at.size() == 3:
		global_position = Vector3(at[0], at[1], at[2])
	rotation.y = float(d.get("yaw", rotation.y))
	reset_physics_interpolation()
	if feet:
		feet.reset()
	_aside_from = Vector3.INF
	_placed = true                         # before it began (a level's _ready): _begin leaves it as loaded
	_return_spot = null
	_return_t = -1.0
	_fleeing = false
	_dest = Vector3.INF
	var sp: Node = get_node_or_null(NodePath(String(d.get("spot", "")))) if String(d.get("spot", "")) != "" else null
	_release_early(sp as CordatixBystanderSpot)
	if sp is CordatixBystanderSpot and (sp.is_free() or sp.occupant == self):
		place_at_spot(sp)
	else:
		if current_spot:
			current_spot.release(self)
		current_spot = null
		state = "idle"
		var c := String(d.get("clip", idle_clip))
		_play(c if anim and anim.has_animation(c) and not c in SEATED else idle_clip, 0.0)


# -------------------------------------------------------------------------------------------- the player
func _player() -> Node3D:
	var ps := get_tree().get_nodes_in_group("player")
	return ps[0] if ps.size() > 0 else null


func _look_point() -> Node3D:
	if is_instance_valid(look_target):
		return look_target
	if is_instance_valid(CordatixBystanderLook.default_target):
		return CordatixBystanderLook.default_target
	return get_viewport().get_camera_3d()


func _update_look() -> void:
	if look_mod == null:
		return
	var p := _player()
	var near := false
	if p and look_at_player and not state in ["react", "down"]:
		var to := _flat(p.global_position - global_position)
		var fwd := -global_transform.basis.z
		near = to.length() <= look_distance and (to.length() < 0.6 or fwd.angle_to(to.normalized()) < deg_to_rad(110.0))
	if state == "talk_player":
		near = true
	if near and not _player_near:
		noticed_player.emit(p)
	elif not near and _player_near and p and _flat(p.global_position - global_position).length() < look_distance + 1.0:
		near = true                     # it keeps looking until the player is a metre further away
	_player_near = near
	var pair := _pair_head() if not near else null
	if pair:
		look_mod.target = pair                 # a seated pair turn their heads to each other (2.0)
		look_mod.weight = 1.0
		return
	look_mod.target = _look_point()
	look_mod.weight = 1.0 if near else 0.0


## Stops what it does, turns to the player and talks (the signal talked_to is where your dialogue begins); a seated
## person stays seated and turns its head. end_talk() sends it back to what it was doing.
func talk_to_player(p: Node3D = null) -> void:
	if state in ["down"]:
		return
	p = p if p else _player()
	if p == null:
		return
	_resume = _back_to.bind(current_spot)
	state = "talk_player"
	if clip in SEATED_LOOPS:
		# seated, it talks seated (2.0: SitTalk; a 1.0 file has no SitTalk: it sits on, its head to the player)
		_play("SitTalk" if has_clip("SitTalk") else "Sit", 0.3)
	else:
		var to := _flat(p.global_position - global_position)
		_turn_to(atan2(-to.x, -to.z), _talking_to_player)
	talked_to.emit(p)


func _talking_to_player() -> void:
	state = "talk_player"
	_play("Talk", 0.3)


func end_talk() -> void:
	if state != "talk_player":
		return
	talk_ended.emit()
	var r := _resume
	_resume = Callable()
	if r.is_valid():
		r.call()
	else:
		_go_idle()


func _back_to(s: CordatixBystanderSpot) -> void:
	if s and is_instance_valid(s) and s.occupant == self:
		if _flat(s.global_position - global_position).length() < 0.05:
			if absf(wrapf(s.yaw() - rotation.y, -PI, PI)) > deg_to_rad(5.0):
				_turn_to(s.yaw(), _spot_continue)
			else:
				_spot_continue()
		else:
			use_spot(s)
	else:
		_go_idle()


func _spot_continue() -> void:
	## Back at its spot after a talk or a start: seated, it carries on seated; standing, it does what the spot says.
	state = "spot"
	if clip in SEATED_LOOPS:
		_spot_t = _rng.randf_range(6.0, 14.0)
		_play(_seated_clip(), 0.4)
	else:
		_spot_begin(false)


## A start at a sound or a sight at `from`, then back to what it was doing.
func startle(from := Vector3.INF) -> void:
	if state in ["down"] or clip in ["Startle", "Cower", "Flee"]:
		return
	startled.emit()
	if clip in SEATED_LOOPS or clip == "SitDown":
		return                         # seated: the head turns (the look), no start
	_resume = _back_to.bind(current_spot)
	state = "react"
	if from != Vector3.INF:
		var to := _flat(from - global_position)
		if to.length() > 0.1:
			_startle_yaw = rotate_toward(rotation.y, atan2(-to.x, -to.z), deg_to_rad(40.0))
	_play("Startle", 0.1)


## Steps back from `from` (a sound, a sight, the player too close): turns to face it if it must, then BackAway,
## the body carried back along its facing at the clip's speed (clip_speed, about half a metre in all), and it stands
## where it ends a few seconds, then walks back to the spot it left (taken meanwhile: the nearest free one; WANDER: on
## to another spot after a while). Seated, it stands up first. With no room behind it for the step back (a wall, the
## bench it sits on, someone there), it starts instead (startle: seated, it stays seated).
func back_away(from := Vector3.INF) -> void:
	if state == "down" or clip in ["BackAway", "Cower", "Flee"] or (state == "turn" and _turn_then == _back_step):
		return
	if not room_behind(from):
		startle(from)
		return
	if clip in SEATED and clip != "StandUp":
		_stand_then(back_away.bind(from))
		return
	_keep_return_spot()
	_leave_spot_now()
	_resume = _return_later.bind(2.5, 5.0)
	backed_away.emit()
	if from != Vector3.INF:
		var to := _flat(from - global_position)
		if to.length() > 0.1:
			var yaw := atan2(-to.x, -to.z)
			if absf(wrapf(yaw - rotation.y, -PI, PI)) > deg_to_rad(20.0):
				_turn_to(yaw, _back_step)
				return
	_back_step()


func _back_step() -> void:
	state = "react"
	_play("BackAway", 0.15)


## Whether the way back from `from` (none: straight back) is clear for the whole of BackAway's travel: the body's
## own shape moved that far (CharacterBody3D.test_move) meets nothing.
func room_behind(from := Vector3.INF) -> bool:
	var away := _flat(global_transform.basis.z).normalized()
	if from != Vector3.INF:
		var to := _flat(global_position - from)
		if to.length() > 0.1:
			away = to.normalized()
	var travel := absf(float(data.get("clips", {}).get("BackAway", {}).get("travel", 0.0)))
	return travel <= 0.0 or not test_move(global_transform, away * travel)


func _carry(delta: float) -> void:
	## BackAway plays in place: the body goes with it, `d = v t min(1, t / blend)` metres along its facing at the
	## clip's time t (v its speed), from its first frame: while it blends in, its pose is part the last clip's, whose
	## feet stand where they stood, so the planted foot stays planted (carried at v from the first frame it slid back
	## by v times the blend). Left in place, the feet slid about 0.2 m over the floor and the person ended where it
	## started.
	if anim.current_animation != _carry_clip:
		return
	var length := maxf(anim.get_animation(_carry_clip).length, 0.01)
	var t := clampf(anim.current_animation_position, 0.0, length)
	var total := absf(clip_speed(_carry_clip)) / maxf(_pace, 0.01) * length
	var want := total * t / length * (minf(1.0, t / _carry_blend) if _carry_blend > 0.0 else 1.0)
	_carry_by(want - _carry_done, delta)


func _carry_by(d: float, delta: float) -> void:
	_carry_done += d
	if absf(d) < 1e-6:
		return
	var keep := velocity
	velocity = _carry_dir * (d / maxf(delta, 1e-4))
	move_and_slide()
	velocity = Vector3(0.0, keep.y, 0.0)


## Crouches with the arms over the head until calm().
func cower() -> void:
	if state == "down":
		return
	if clip in SEATED and clip != "StandUp":
		_stand_then(cower)
		return
	_keep_return_spot()
	_leave_spot_now()
	_fleeing = false
	_dest = Vector3.INF
	velocity = Vector3(0.0, velocity.y, 0.0)
	state = "react"
	_resume = Callable()
	_play("Cower", 0.2)


## Out of a cower: it stands, and walks back to the spot it left (taken meanwhile: the nearest free one, _go_back;
## WANDER: on to another).
func calm() -> void:
	if clip == "Cower" and state == "react":
		_go_idle()
		_return_later(0.5, 2.0)


## Runs away from `from` on the navigation mesh (_flee_goal: the reachable place furthest from it), then cowers; it
## cowers where it is when there is nowhere to run, when its way is blocked for a second (a wall, a crowd in a
## doorway) or when it cannot get there. calm() sends it back to the spot it left.
func flee(from: Vector3) -> void:
	if state == "down":
		return
	if clip in SEATED and clip != "StandUp":
		_stand_then(flee.bind(from))
		return
	_keep_return_spot()
	_leave_spot_now()
	fled.emit()
	_flee_from = from
	var goal := _flee_goal(from)
	if goal == Vector3.INF:
		cower()
		return
	_start_walk(goal, cower, NAN, "Flee")


func _keep_return_spot() -> void:
	if current_spot and is_instance_valid(current_spot):
		_return_spot = current_spot


## Idle where it stands, then back to the spot it left (`_return_spot`) in `a` to `b` seconds.
func _return_later(a: float, b: float) -> void:
	if state != "idle":
		_go_idle()
	_return_t = _rng.randf_range(a, b) if _return_spot or mode == Mode.WANDER else -1.0


func _go_back() -> void:
	var s := _return_spot
	_return_spot = null
	_return_t = -1.0
	if mode == Mode.WANDER:
		_wander_next()
	elif s and is_instance_valid(s):
		if s.is_free() or s.occupant == self:
			use_spot(s)
		else:
			# taken while it was away: the nearest free one of its kind (a served counter's customer: the end of a
			# line), else the nearest free one of any kind it may take; with none, it stays where it is
			var other := _nearest_free([s.kind])
			if other == null and s.kind == CordatixBystanderSpot.Kind.COUNTER and s.served:
				other = _nearest_free([CordatixBystanderSpot.Kind.QUEUE])
			if other == null:
				other = _nearest_free([])
			if other:
				use_spot(other)


## The nearest free spot of one of `kinds` (empty: any kind) it may take (its `spots`, or every spot within
## wander_radius; not a reserved one, a line only at its end), or null.
func _nearest_free(kinds: Array) -> CordatixBystanderSpot:
	var pool: Array = spots.duplicate()
	if pool.is_empty():
		for n in get_tree().get_nodes_in_group(CordatixBystanderSpot.GROUP):
			if n is CordatixBystanderSpot and n.global_position.distance_to(global_position) <= wander_radius:
				pool.append(n)
	var best: CordatixBystanderSpot = null
	var best_d := INF
	for sp in pool:
		if (not kinds.is_empty() and not sp.kind in kinds) or not sp.is_free() or sp.reserved or not _can_join(sp):
			continue
		var d: float = sp.global_position.distance_to(global_position)
		if d < best_d:
			best_d = d
			best = sp
	return best


func _on_finished(c: StringName) -> void:
	if String(c) == clip:
		# the events on a one-shot's last frame (StandUp's "stand"): the clip ends before _process reads them
		for e in _events.get(clip, []):
			if e[0] > _last_pos:
				_event(e[1], e[2])
		_last_pos = clip_length(clip) + 1.0
	match String(c):
		"SitDown":
			if state == "spot":
				_play(_seated_clip(), 0.2)
		"StandUp":
			var r := _resume
			_resume = Callable()
			if r.is_valid():
				r.call()
			else:
				_go_idle()
		"Startle", "Hit", "BackAway":
			if String(c) == _carry_clip:
				# the rest of the way, to the clip's whole travel (it ended between two physics frames)
				var total := absf(clip_speed(_carry_clip)) / maxf(_pace, 0.01) * anim.get_animation(_carry_clip).length
				_carry_by(total - _carry_done, get_physics_process_delta_time())
				_carry_clip = ""
			var r := _resume
			_resume = Callable()
			if r.is_valid():
				r.call()
			else:
				_go_idle()
		"TurnLeft", "TurnRight":
			_turn_done()
		"Nod":
			if state == "spot":
				_play("Talk" if _talking else "Listen", 0.25)
		"LookAround", "LookBehind", "Wave", "Point", "ShakeHead":
			if state == "spot":
				_spot_begin(false)
			elif state == "idle":
				_play(idle_clip)
		"Fall":
			state = "down"


# -------------------------------------------------------------------------------------------- moving
func _physics_process(delta: float) -> void:
	if Engine.is_editor_hint():
		return
	_clock += delta
	if not _homed:
		_homed = true
		_home = global_position
	if data.is_empty() or anim == null:
		return
	if _carry_clip != "" and stepped_fps <= 0.0:
		_carry(delta)
	if not is_nan(_startle_yaw):
		# a start turns it toward what startled it over the clip's first 0.15 s (turned at once, its feet jumped 13 cm)
		rotation.y = rotate_toward(rotation.y, _startle_yaw, deg_to_rad(40.0 / 0.15) * delta)
		if clip != "Startle" or absf(wrapf(_startle_yaw - rotation.y, -PI, PI)) < 0.001:
			_startle_yaw = NAN
	if feet:
		feet.calm = state in ["idle", "spot", "aside", "talk_player"] and not clip in GAITS
	if behaviour_enabled and _begun:
		if make_way:
			_make_way_check()
		match state:
			"walk":
				_walk(delta)
			"turn":
				_turning(delta)
			"arrive":
				_arrive_tick(delta)
			"spot":
				_spot_tick(delta)
			"idle":
				if _return_t >= 0.0:
					_return_t -= delta
					if _return_t < 0.0:
						_go_back()
				elif mode == Mode.WANDER:
					_stay_t -= delta
					if _stay_t <= 0.0:
						_wander_next()
			"aside":
				_aside_tick()
	_update_look()
	_step_pose(delta)


func _flat(v: Vector3) -> Vector3:
	return Vector3(v.x, 0.0, v.z)


func _walk(delta: float) -> void:
	_walk_t += delta
	_ramp_t += delta
	var c := clip if clip in GAITS else _gait
	var full := clip_speed(c)
	var from := global_position
	var to_dest := _flat(_dest - global_position)
	# it comes up to speed over START_RAMP (a run, a step out of the way in two thirds of it) and slows down over the
	# last SLOW_FROM metres (a flight runs on), the gait playing as fast as it goes (_match_rate)
	var ramp := smoothstep(0.0, START_RAMP * (0.65 if c in ["Run", "Flee"] or _urgent else 1.0), _ramp_t)
	var slow := 1.0 if _fleeing else clampf(sqrt(to_dest.length() / SLOW_FROM), 0.25, 1.0)
	var speed := full * maxf(ramp, 0.05) * slow
	if _unsettle != Vector3.INF:
		# off a mark by furniture onto the mesh, without physics (_start_walk)
		var to_m := _flat(_unsettle - global_position)
		if to_m.length() < 0.03:
			global_position = Vector3(_unsettle.x, global_position.y, _unsettle.z)
			_unsettle = Vector3.INF
		else:
			_face_toward(global_position + to_m, delta)
			global_position += to_m.normalized() * minf(to_m.length(), speed * delta)
		_match_rate(c, full, from, delta)
		return
	var to_spot := _walking_to_spot()
	if to_spot and (to_dest.length() < SETTLE or _settling):
		# the last steps onto a spot's mark, off the navigation mesh and without physics: a seat's mark is 0.1 m from
		# the seat, a counter's 0.22 m from the counter (the capsule would stop short of it). Only onto a mark, and only
		# its last SETTLE metres: never the way through a wall (a flight that met a wall glided through it)
		_settling = true
		if to_dest.length() < 0.03:
			_arrive()
			return
		_face_toward(global_position + to_dest, delta)
		global_position += to_dest.normalized() * minf(to_dest.length(), speed * delta)
		_match_rate(c, full, from, delta)
		return
	if not to_spot and to_dest.length() < 0.03:
		_arrive(false)                     # a place, not a mark: there, as it stands
		return
	if _walk_t > _walk_limit:
		_give_up()                         # it cannot get there by the mesh
		return
	var next := _dest
	if agent and NavigationServer3D.map_get_iteration_id(agent.get_navigation_map()) > 0:
		if _nav_target.distance_to(_dest) > 0.1:
			_nav_target = _dest
			agent.target_position = _dest
		if not agent.is_navigation_finished():
			next = agent.get_next_path_position()
		if _flat(next - global_position).length() < 0.05:
			next = _dest
	var to := _flat(next - global_position)
	if agent and agent.is_navigation_finished() and to_dest.length() >= SETTLE:
		# the end of the mesh's path, short of the mark (the mark is by furniture): the rest straight
		next = _dest
		to = to_dest
	_face_toward(global_position + to, delta)
	var fwd := -global_transform.basis.z
	var align := clampf(fwd.dot(to.normalized()), 0.0, 1.0)
	if next == _dest:
		speed = minf(speed, to_dest.length() / maxf(delta, 0.0001))    # the last step: onto it, not past it
	# turned away from its way it slows down to turn (a flight does not run on while it faces back)
	var v := fwd * speed * ((align * align) if _fleeing else (0.35 + 0.65 * align))
	velocity = Vector3(v.x, velocity.y, v.z)
	if not is_on_floor():
		velocity.y -= _gravity * delta
	else:
		velocity.y = 0.0
	move_and_slide()
	_match_rate(c, full, from, delta)
	# blocked (by the player, another person): it steps round someone in front of it, or waits where it is and finds its
	# way again; a flight cowers there
	var want := Vector2(v.x, v.z).length()
	if want > 0.05 and _flat(global_position - from).length() < want * delta * 0.2 and _ramp_t > 0.2:
		_blocked_t += delta
		if _fleeing and _blocked_t > 1.0:
			cower()
			return
		if not to_spot and to_dest.length() < 0.25 and _blocked_t > 0.3:
			_arrive(false)                   # all but there, and something stands on it: there, as it stands
			return
		if make_way and _blocked_t > 0.3 and _aside_from == Vector3.INF and not _fleeing and _someone_ahead(1.0) \
				and _side_step_walk():
			_blocked_t = 0.0
			return
		if _blocked_t > 0.5 and clip != "IdleShift" and not _fleeing:
			_play("IdleShift", 0.25)
		if _blocked_t > 2.5:
			_blocked_t = 0.0
			_nav_target = Vector3.INF
	elif _blocked_t > 0.0:
		if clip != c:
			_ramp_t = 0.0                    # held up: it sets off again
			_play(c, 0.25, _gait_start(c))
		_blocked_t = 0.0


## The gait plays as fast as the body moves: a planted foot goes back under the body exactly as fast as the body goes
## on, through a start, a stop and a turn (CordatixBystanderFeet holds the rest). Never slower than an eighth: held
## up in a crowd it marks time.
func _match_rate(c: String, full: float, from: Vector3, delta: float) -> void:
	if anim == null or clip != c or not c in GAITS:
		return
	var moved := _flat(global_position - from).length() / maxf(delta, 0.0001)
	_rate = clampf(moved / maxf(full, 0.01), 0.12, 1.0)
	anim.speed_scale = _pace * _rate


func _face_toward(p: Vector3, delta: float) -> void:
	var to := _flat(p - global_position)
	if to.length() < 0.01:
		return
	rotation.y = rotate_toward(rotation.y, atan2(-to.x, -to.z), deg_to_rad(240.0) * delta)


## Whether it walks to its spot's mark (not a place beside it: a step aside, a way out of a line, a flight).
func _walking_to_spot() -> bool:
	return current_spot != null and is_instance_valid(current_spot) and _dest != Vector3.INF \
		and _flat(_dest - current_spot.global_position).length() < 0.05


func _give_up() -> void:
	## It cannot get there by the navigation mesh (the walk took 2.5 times as long as the way, and 4 s more): never the
	## rest of the way through what stops it. A flight cowers where it is; a spot it walked to is let go (a wanderer
	## goes on to another soon); any other walk ends where it is.
	var to_spot := _walking_to_spot()
	var then := _then
	_then = Callable()
	_settling = false
	_dest = Vector3.INF
	velocity = Vector3(0.0, velocity.y, 0.0)
	if _fleeing:
		cower()
		return
	if to_spot:
		current_spot.release(self)
		current_spot = null
		_go_idle()
		if mode == Mode.WANDER:
			_stay_t = _rng.randf_range(2.0, 5.0)
		return
	_go_idle()
	if then.is_valid():
		then.call()


func _arrive(snap := true) -> void:
	var from_gait := clip in GAITS
	if feet and from_gait:
		feet.settle_now()                  # stopped mid-stride: its feet come under it
	_settling = false
	_fleeing = false
	velocity = Vector3(0.0, velocity.y, 0.0)
	if snap:
		global_position = Vector3(_dest.x, global_position.y, _dest.z)
	var then := _then
	_then = Callable()
	if is_nan(_dest_yaw):
		state = "idle"
		_play(_stand_clip(), 0.25)
		if then.is_valid():
			then.call()
	else:
		_play(_stand_clip(), 0.25)
		if feet and from_gait and absf(rad_to_deg(wrapf(_dest_yaw - rotation.y, -PI, PI))) >= TURN_CLIP_FROM:
			# its feet first: the walk stopped mid-stride, and a turn clip keeps the foot left behind where it is
			# until the clip lifts it (half way through: the hips came down 3 cm for it)
			state = "arrive"
			_arrive_t = 0.0
			_arrive_yaw = _dest_yaw
			_arrive_then = then
			return
		_turn_to(_dest_yaw, then)


func _arrive_tick(delta: float) -> void:
	_arrive_t += delta
	var wait := 0.1 if _urgent else 0.25
	if (_arrive_t > wait and (feet == null or not feet.drifting())) or _arrive_t > 1.0:
		var then := _arrive_then
		_arrive_then = Callable()
		_turn_to(_arrive_yaw, then)


## Turns on the spot to face `yaw` (radians): small turns as it stands, large ones with a turn clip (TurnLeft and
## TurnRight turn 90 degrees; the body turns the rest as the clip plays).
func _turn_to(yaw: float, then := Callable()) -> void:
	var need := rad_to_deg(wrapf(yaw - rotation.y, -PI, PI))
	_turn_then = then
	_turn_from = rotation.y
	_turn_need = need
	state = "turn"
	if absf(need) < TURN_CLIP_FROM or (carrying and has_clip("CarryIdle")):
		_turn_clip = ""
		if not clip in ["Idle", "IdleShift", "Talk", "Listen", "CarryIdle"]:
			_play(_stand_clip(), 0.2)
		return
	_turn_clip = "TurnLeft" if need > 0.0 else "TurnRight"
	_play(_turn_clip, 0.15)
	if _urgent and state == "turn" and _turn_then == _set_off:
		anim.speed_scale = _pace * URGENT_TURN   # a flight, a step out of the way: it turns quicker


func _turning(delta: float) -> void:
	if _turn_clip == "":
		var target := _turn_from + deg_to_rad(_turn_need)
		rotation.y = rotate_toward(rotation.y, target, deg_to_rad(90.0) * delta)
		if absf(wrapf(target - rotation.y, -PI, PI)) < 0.003:
			_turn_done()
		return
	# the clip turns the skeleton 90 degrees; the body turns what the turn needs beyond (or short of) that, as it plays
	var sign := 1.0 if _turn_clip == "TurnLeft" else -1.0
	var rest := _turn_need - 90.0 * sign
	if absf(_turn_need) > 135.0:
		rest = 0.0                         # a half turn: two clips, this one a whole quarter
	var u := clampf(anim.current_animation_position / maxf(clip_length(_turn_clip), 0.01), 0.0, 1.0)
	rotation.y = _turn_from + deg_to_rad(rest * u)


func _turn_done() -> void:
	if _turn_clip != "":
		# the clip ended turned 90 degrees: the body takes the quarter and the clip goes back to its start, at once
		var sign := 1.0 if _turn_clip == "TurnLeft" else -1.0
		var rest := _turn_need - 90.0 * sign
		if absf(_turn_need) > 135.0:
			rest = 0.0
		rotation.y = _turn_from + deg_to_rad(rest + 90.0 * sign)
		reset_physics_interpolation()
		var left := _turn_need - rest - 90.0 * sign
		_turn_clip = ""
		# the turned body and Idle's first pose in the same frame: the clip ends on Idle turned a quarter, and held a
		# frame longer on the turned body it showed the person a quarter too far round (in stepped animation a whole
		# step: 0.17 s at 12 a second)
		_play("Idle", 0.0, 0.0)
		anim.seek(0.0, true)
		if stepped_fps > 0.0:
			_step_xform = global_transform
			_step_t = 0.0
			_hold_model()
		if absf(left) >= 1.0:
			var then := _turn_then
			_turn_to(rotation.y + deg_to_rad(left), then)
			return
	var then := _turn_then
	_turn_then = Callable()
	state = "idle"
	if then.is_valid():
		then.call()
