@tool
class_name CordatixBystanderSpot
extends Marker3D
## Cordatix PSX Bystanders: a place where a person does something (Godot 4.3+).
##
## Put the marker where the person's feet go, its -Z (Godot's forward, the blue arrow's back) the way they face. A
## person who uses the spot walks there, turns to face that way, and does what `kind` says:
##   SEAT     sits down on a seat behind them: its front edge 0.10 m behind the marker, its top 0.45 m high, a back
##            (if it has one) 0.52 m behind the marker; with a `partner` (the SEAT beside it), the two, both seated,
##            talk in turn (2.0: SitTalk and Sit, their heads turned to each other)
##   DESK     sits as on SEAT and types at a desk in front: its top 0.75 m high, its near edge 0.03 m in front
##   COUNTER  stands with the hands on a counter in front: its top 0.95 m high, its near edge 0.22 m in front;
##            `served`: a customer, done and gone after `serve_time` (a ticket window's or a kiosk's; QUEUE spots
##            whose `ahead` is this one make a line in front of it)
##   LEAN     leans on a wall behind: its face 0.20 m behind the marker
##   WAIT     stands and waits (now and then the phone, a look round, the watch)
##   TALK     talks with the person at `partner`, a TALK spot about 1.1 m away facing this one: they take turns
##   QUEUE    stands in a line: `ahead` is the place in front (none: the head of the line; a served COUNTER: the line
##            waits for it); when the place ahead is free the person steps up, and the head of the line leaves after
##            `serve_time`
##   LOOK     stands and looks at `look_at_node` (a board, a window), or straight ahead
## A spot is taken by one person at a time. A `reserved` spot (a clerk's desk, the place behind a counter) is only for
## the person put there: never a wanderer's. `who` says who a crowd puts there.

enum Kind { SEAT, DESK, COUNTER, LEAN, WAIT, TALK, QUEUE, LOOK }

const GROUP := "cordatix_bystander_spot"
## The furniture the clips fit (metres, from the marker).
const SEAT_FRONT := 0.10
const SEAT_HEIGHT := 0.45
const SEAT_BACK := 0.52
const DESK_HEIGHT := 0.75
const DESK_EDGE := 0.03
const COUNTER_HEIGHT := 0.95
const COUNTER_EDGE := 0.22
const WALL_BACK := 0.20

@export var kind: Kind = Kind.WAIT:
	set(v):
		kind = v
		update_gizmos()
## TALK: the other spot of the pair (it should point back at this one). SEAT (2.0): the seat beside it, for a pair
## who talk sitting down.
@export var partner: CordatixBystanderSpot
## QUEUE: the place in front of this one in the line (none: this is the head of the line).
@export var ahead: CordatixBystanderSpot
## QUEUE at the head of a line, or a served COUNTER: seconds before the person there is done and leaves.
@export var serve_time := Vector2(6.0, 12.0)
## COUNTER: a customer's place, served and left after `serve_time` (the head of the line of QUEUE spots behind it).
@export var served := false
## Only for the person put here (CordatixBystander.spot, or a crowd): never a wanderer's next spot, nor where a
## customer goes when served. A clerk's desk, the place behind a counter.
@export var reserved := false
## Who a crowd puts here: person keys ("office_worker") or a person in a look ("security_guard:uniform"), the first
## one free in the crowd's draw; empty: anyone.
@export var who: PackedStringArray = []
## LOOK: what the person looks at (none: straight ahead).
@export var look_at_node: Node3D
## SEAT and WAIT: how often the person has the phone out (0..1).
@export_range(0.0, 1.0) var phone := 0.35
## SEAT: how often the person sits forward, the elbows on the knees (0..1; 2.0, SitLean).
@export_range(0.0, 1.0) var lean := 0.2
## WANDER: seconds a wandering person stays here before it moves on (min, max).
@export var stay := Vector2(12.0, 30.0)

## The person using it (or on the way to it).
var occupant: Node3D = null


func _enter_tree() -> void:
	add_to_group(GROUP)


func is_free() -> bool:
	return occupant == null or not is_instance_valid(occupant) or occupant.is_queued_for_deletion()


## Takes the spot for `who`: false if someone else has it.
func claim(who: Node3D) -> bool:
	if not is_free() and occupant != who:
		return false
	occupant = who
	return true


func release(who: Node3D) -> void:
	if occupant == who:
		occupant = null


## The way a person here faces (on the floor).
func facing() -> Vector3:
	var f := -global_transform.basis.z
	f.y = 0.0
	return f.normalized() if f.length() > 0.001 else Vector3.FORWARD


## The person's yaw here (Godot's rotation.y of a body facing -Z).
func yaw() -> float:
	var f := facing()
	return atan2(-f.x, -f.z)


## The spot's kind as a name ("SEAT", "DESK", ...).
func kind_name() -> String:
	return Kind.keys()[kind]
