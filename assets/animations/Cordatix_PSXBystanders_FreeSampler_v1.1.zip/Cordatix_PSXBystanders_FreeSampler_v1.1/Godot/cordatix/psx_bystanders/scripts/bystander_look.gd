class_name CordatixBystanderLook
extends SkeletonModifier3D
## Cordatix PSX Bystanders: a person turns to look at the player, over the clip that plays (Godot 4.3 has no
## LookAtModifier3D; this is a small one, Silent Dread's look rule under its own name). The turn is shared by several
## bones (the chest a little, the neck more, the head most), held within limits (past a limit the head stays at it: it
## never snaps back or spins round), and slow. It turns about the vertical, and it lifts or lowers the face only as far
## as max_up and max_down allow. `weight` fades it in and out; the person sets it as the player comes near and leaves.
## What the player sees is the turn times the weight: the turn follows the target faster while the weight is low, and
## the weight in use (`applied`) follows `weight` only as fast as what is left, so the head itself never turns faster
## than turn_speed, however the two change together. While nobody sees it, both go straight to where they are going.

## The bones that share the turn, with their shares: [[name, share], ...] (the shares add up to 1). The last one's
## +Z is where the face points.
@export var bones: Array = [["Chest", 0.15], ["Neck", 0.35], ["Head", 0.5]]
## Limits: degrees to each side, and how far it may lower and lift the face from the clip's own pose.
@export var max_yaw := 65.0
@export var max_down := 15.0
@export var max_up := 20.0
## Degrees a second the head turns at, at most.
@export var turn_speed := 30.0
## What it looks at (empty: default_target, else the current camera). The person sets it from its look_target.
@export var target: Node3D
## What every look turns to when its own target is empty: the player's head, set once in the player script (third
## person or fixed cameras), and again when the player is spawned anew: CordatixBystanderLook.default_target = $Head
static var default_target: Node3D
## 0..1: how much of the turn to apply.
@export_range(0.0, 1.0) var weight := 0.0
## The weight in use: it follows `weight` (at once while snapping).
var applied := 0.0
## Goes straight to the target instead of turning to it (a loaded save).
var snap := false
## Holds still while it is not snapping.
var hold := false
## PS1-style steps (the person's stepped_fps): the turn moves this many times a second, as the stepped body does (0:
## every frame).
var stepped_fps := 0.0
var _acc := 0.0

var yaw := 0.0
var pitch := 0.0
## Where the target is, within the limits: the turn it is heading for.
var want_yaw := 0.0
## Where the target is: degrees across the floor from where the face points in the clip alone, before the limits.
var raw_yaw := 0.0
var _behind := false
var _ids: Array = []
var _last_bone := -1


## The bones to turn again (after `bones` changed).
func reset_bones() -> void:
	_ids.clear()


func _resolve(sk: Skeleton3D) -> void:
	_ids.clear()
	for b in bones:
		var i := sk.find_bone(String(b[0]))
		if i >= 0:
			_ids.append([i, float(b[1])])
	_last_bone = _ids[-1][0] if not _ids.is_empty() else -1


func _process_modification() -> void:
	var sk := get_skeleton()
	if sk == null or not sk.is_inside_tree():
		return                          # (a person taken out of the level before its skeleton's update came)
	if _ids.is_empty():
		_resolve(sk)
		if _ids.is_empty():
			return
	want_yaw = 0.0                                         # with no weight it settles back on the clip's own look
	var want_pitch := 0.0
	var dt := get_process_delta_time()
	if stepped_fps > 0.0 and not snap:
		# stepped: the turn moves on the step's clock, a whole step at a time
		_acc += dt
		var st := 1.0 / stepped_fps
		dt = 0.0
		while _acc >= st - 0.0001:
			_acc -= st
			dt += st
	var turn_before := Vector2(yaw, pitch)
	var tgt := _target()
	if tgt and maxf(weight, applied) > 0.0:
		# where the target is against where the face points in the clip alone: across the floor, then up or down
		var g: Transform3D = sk.global_transform * sk.get_bone_global_pose(_last_bone)
		var face := g.basis.z.normalized()
		var to := tgt.global_position - g.origin
		var flat := Vector2(to.x, to.z).length()
		if Vector2(face.x, face.z).length() > 0.05 and flat > 0.05:
			var raw := rad_to_deg(atan2(face.z * to.x - face.x * to.z, face.x * to.x + face.z * to.z))
			raw_yaw = raw
			# behind it (past the face's plane, and past the limit, on the side away from where the head is turned): it
			# holds on the side it last saw you, and never swings round through the front. Behind is where you are, not
			# how far the head lags: in front of it, past the far limit, the head turns across to that limit (run fast
			# across its front and it follows you to the other side). The plane has a margin, so a player standing
			# right at its side does not set it swinging.
			var plane := maxf(max_yaw, 80.0 if _behind else 100.0)
			_behind = absf(raw) > plane and absf(yaw) > max_yaw * 0.5 and signf(raw) != signf(yaw)
			if _behind:
				raw = signf(yaw) * max_yaw
			want_yaw = clampf(raw, -max_yaw, max_yaw)          # past a limit it holds there
			var up := rad_to_deg(atan2(to.y, flat) - asin(clampf(face.y, -1.0, 1.0)))
			want_pitch = clampf(up, -max_down, max_up)
	if snap:
		yaw = want_yaw
		pitch = want_pitch
		applied = weight
	else:
		if not hold:
			# the head turns by (yaw, pitch) x weight, across and up together within turn_speed: while the weight is
			# low the turn may catch up faster, unseen in the head
			var step := turn_speed * dt / maxf(applied, 0.2)
			var gap := Vector2(want_yaw - yaw, want_pitch - pitch)
			var t := gap.limit_length(step) * (0.35 + 0.65 * smoothstep(0.0, 8.0, gap.length()))
			yaw += t.x
			pitch += t.y
		# the weight moves only by what the turn left of turn_speed this frame: what the player sees, the turn and the
		# lift times the weight, never changes faster than turn_speed (a ramp that asks for more waits, and arrives a
		# little later; a head looking up comes down as slowly as it turns)
		var turn := Vector2(yaw, pitch)
		var left := maxf(0.0, turn_speed * dt - (turn - turn_before).length() * applied)
		applied = move_toward(applied, weight, left / maxf(turn.length(), 0.001))
	if applied <= 0.0:
		return
	var vertical := (sk.global_transform.basis.inverse() * Vector3.UP).normalized()
	for e in _ids:
		var i: int = e[0]
		var share: float = e[1] * applied
		# about the vertical through the joint (in the parent's space), then the face up about the bone's own side axis
		var parent := sk.get_bone_parent(i)
		var axis := vertical
		if parent >= 0:
			axis = (sk.get_bone_global_pose(parent).basis.inverse() * vertical).normalized()
		var turn := Quaternion(axis, deg_to_rad(yaw * share))
		var lift := Quaternion(Vector3.RIGHT, deg_to_rad(-pitch * share))
		sk.set_bone_pose_rotation(i, turn * sk.get_bone_pose_rotation(i) * lift)


## The turn the player sees: degrees from the clip's own pose, across and up together.
func visible_turn() -> float:
	return Vector2(yaw, pitch).length() * applied


func _target() -> Node3D:
	if is_instance_valid(target) and target.is_inside_tree():
		return target
	if is_instance_valid(default_target) and default_target.is_inside_tree():
		return default_target
	return get_viewport().get_camera_3d()
