extends RefCounted
## Cordatix sides (Godot 4.3+): a Haunted PSX level in its two states, festive and creepy (each pack's
## data/props.json names its two sides). Every decoration's states are models with the same origin, and every
## ready-made setup comes as one scene per side, so a level holds both and shows one.
##
##   const Sides := preload("res://cordatix/shared/scripts/cordatix_sides.gd")
##   const PACK := "res://cordatix/haunted_psx_halloween_takeover/"
##   Sides.place_setup(self, PACK, "party_corner", Vector3(4, 0, 2), 90.0)   # both sides, the first one shown
##   Sides.show_side(get_tree(), PACK, 1)                                      # every placed copy switches
##   Sides.swap_in_place($Pumpkin, PACK)                                       # one decoration to its other state
##   Sides.link_twins([$Normal, $Cursed])                                      # a level's own side roots: an item
##                                                                             # taken on one side is gone on both
##
## The hidden side is switched off, not only hidden: out of physics and processing, so two candy bowls never
## share one place and the hidden side's lamps do not flicker.

static var _cache := {}


## The pack's two sides, e.g. ["festive", "creepy"].
static func sides(pack: String) -> Array:
	return _data(pack)["switch"]["sides"]


## Instances a setup once per side under `parent`, each copy in the group "cordatix_side_<side>", and shows
## the first side. Returns the copies.
static func place_setup(parent: Node, pack: String, setup_name: String, at: Vector3, turn_deg := 0.0) -> Array:
	var made := []
	var ss := sides(pack)
	for k in ss.size():
		var node: Node3D = load(pack + "setups/" + setup_name + "__" + ss[k] + ".tscn").instantiate()
		node.position = at
		node.rotation_degrees.y = turn_deg
		node.add_to_group("cordatix_side_" + ss[k])
		parent.add_child(node)
		_enable(node, k == 0)
		made.append(node)
	link_twins(made)
	return made


## Ties copies of one layout together (the sides of a placed setup, or a level's side roots): every pickup or
## lock (a node with `twins`, Haunted PSX Props' pickup.gd and use_target.gd) learns its twins at the same path
## in the other copies, so an item taken or a lock opened on one side is gone or open on the others too.
static func link_twins(copies: Array) -> void:
	if copies.size() < 2:
		return
	var first: Node = copies[0]
	for n in first.find_children("*", "", true, false):
		if not "twins" in n:
			continue
		var rel := first.get_path_to(n)
		var group := []
		for c in copies:
			var t: Node = (c as Node).get_node_or_null(rel)
			if t != null and "twins" in t:
				group.append(t)
		for a in group:
			for b in group:
				if a != b and not (b in a.twins):
					a.twins.append(b)


## Shows side `i` of every node in the side groups and switches the other side off.
static func show_side(tree: SceneTree, pack: String, i: int) -> void:
	var ss := sides(pack)
	for k in ss.size():
		for n in tree.get_nodes_in_group("cordatix_side_" + ss[k]):
			_enable(n, k == i)


## The other state of a decoration variant (festive to creepy and back), or "" when it has none.
static func pair_of(pack: String, variant: String) -> String:
	for p in _data(pack)["props"]:
		var pairs: Dictionary = p["pairs"]
		if pairs.has(variant):
			return pairs[variant]
		for k in pairs:
			if pairs[k] == variant:
				return k
	return ""


## Replaces a placed decoration (an instance of props/<variant>.tscn, or its __rigid, __flicker, __pickup or __use
## scene) with its other state at the same transform, under the same parent, with the same name, groups and twins.
## Returns the new node, or the old one when it has no other state.
static func swap_in_place(node: Node3D, pack: String) -> Node3D:
	var file := node.scene_file_path.get_file().get_basename()
	# the physics or flicker scene the item was placed as; kept across a state that has none, so a round trip
	# returns a flickering lamp or a pushable bowl as it was
	var suffix: String = node.get_meta("cordatix_suffix", "")
	for sfx in ["__rigid", "__flicker", "__pickup", "__use"]:
		if file.ends_with(sfx):
			suffix = sfx
			file = file.trim_suffix(sfx)
	var other := pair_of(pack, file)
	if other == "":
		return node
	var path := pack + "props/" + other + suffix + ".tscn"
	if not ResourceLoader.exists(path):        # the other state has no rigid or flicker scene of its own
		path = pack + "props/" + other + ".tscn"
	var n: Node3D = load(path).instantiate()
	n.transform = node.transform
	if suffix != "":
		n.set_meta("cordatix_suffix", suffix)
	for g in node.get_groups():
		n.add_to_group(g)
	_carry_twins(node, n)
	var parent := node.get_parent()
	var at := node.get_index()
	var name := node.name
	parent.remove_child(node)
	node.queue_free()
	parent.add_child(n)
	parent.move_child(n, at)
	n.name = name
	return n


## A swapped pickup or lock keeps its twins: the new node takes the old one's place in their lists.
static func _carry_twins(old: Node, new: Node) -> void:
	for o in [old] + old.find_children("*", "", true, false):
		if not "twins" in o or (o.twins as Array).is_empty():
			continue
		var m: Node = new if o == old else new.get_node_or_null(old.get_path_to(o))
		if m == null or not "twins" in m:
			continue
		m.twins = (o.twins as Array).duplicate()
		for t in o.twins:
			if is_instance_valid(t):
				t.twins.erase(o)
				t.twins.append(m)


static func _enable(n: Node, on: bool) -> void:
	if n is Node3D:
		(n as Node3D).visible = on
	n.process_mode = Node.PROCESS_MODE_INHERIT if on else Node.PROCESS_MODE_DISABLED


static func _data(pack: String) -> Dictionary:
	if not _cache.has(pack):
		_cache[pack] = JSON.parse_string(FileAccess.get_file_as_string(pack + "data/props.json"))
	return _cache[pack]
