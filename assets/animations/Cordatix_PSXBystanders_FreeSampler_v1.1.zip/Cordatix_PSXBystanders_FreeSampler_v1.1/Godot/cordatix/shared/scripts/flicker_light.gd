extends Node
## Cordatix flicker (Godot 4.3+): makes a lamp flicker, its light and the glow of the lamp together.
## The Haunted PSX "__flicker" scenes carry it as a child named Flicker. To use it on a lamp of your
## own, add a Node with this script under the lamp and point `light` at its Light3D and `glow` at the
## MeshInstance3D whose glowing surfaces should dim with the light (`glows` takes more, e.g. the faces
## of a row of carved pumpkins lit by one light).
##
## Photosensitivity: the default modes never make more than 3 bright flashes in any one second (a flash
## is a rise from below half to above half of the light's full energy; the packs' tests count them).
##   candle       a gentle waver between about 75 and 100 %, never a flash
##   fluorescent  steady, with a short drop-out (one or two blinks) every few seconds
##   bulb         steady, with a rare dip or a slow brown-out
##   harsh        violent stutters. NOT a default: it can exceed 3 flashes a second. Use it only with a
##                warning to your players, and keep it out of trailers and store GIFs.
## Each lamp gets its own pattern from `seed` (0 = from its path in the scene tree), so neighbouring
## lamps never flicker in step.

@export_enum("candle", "fluorescent", "bulb", "harsh") var mode: String = "bulb"
@export var light: NodePath = ^"../Light"
@export var glow: NodePath = ^"../Mesh"
## More glowing meshes that dim with the same light.
@export var glows: Array[NodePath] = []
@export var seed: int = 0
## Stopped, the lamp burns steadily at `strength` (the same as set_flicker(false)).
@export var running: bool = true:
	set(on):
		running = on
		if not on:
			level = 1.0
		_apply()
## Scales the light and its glow (a dimmed room), running or stopped; the flicker pattern is unchanged.
@export var strength: float = 1.0:
	set(v):
		strength = v
		_apply()

## Current brightness, 0..1 of the light's own energy (read it to sync other effects).
var level := 1.0

var _light: Light3D
var _glows: Array[MeshInstance3D] = []
var _energy := 1.0
var _applied := -1.0          # the level x strength last given to the light
var _t := 0.0
var _rng := RandomNumberGenerator.new()
var _phase := [0.0, 0.0, 0.0]
var _next := 0.0
var _dips: Array = []        # [start, end, depth]: the light holds `depth` between start and end
var _ramps: Array = []       # [start, low_from, low_to, end, depth]: a slow fall, a hold and a rise
var _glow_mats := {}         # "mesh id:surface" -> [material it was copied from, own copy, base emission, level]


func _ready() -> void:
	_light = null if light.is_empty() else get_node_or_null(light) as Light3D
	for p in [glow] + glows:
		var g: MeshInstance3D = null if p.is_empty() else get_node_or_null(p) as MeshInstance3D
		if g != null and not _glows.has(g):
			_glows.append(g)
	if _light != null:
		_energy = _light.light_energy
	_rng.seed = seed if seed != 0 else hash(str(get_path()))
	_phase = [_rng.randf() * TAU, _rng.randf() * TAU, _rng.randf() * TAU]
	_t = _rng.randf() * 4.0                 # lamps that load together start out of step
	_next = _t + _gap()
	_apply()


func _process(delta: float) -> void:
	if running:
		_t += delta
		level = sample(_t)
	_apply()


## Start or stop the flicker; stopped, the lamp burns steadily at `strength`.
func set_flicker(on: bool) -> void:
	running = on


## Gives the light and the glow the current level x strength. Stopped, it only acts on a change (or on a
## material swapped by a PSX look), so a script of yours may set the light's energy itself.
func _apply() -> void:
	if not is_node_ready():
		return
	var lv := level * strength
	if _light != null and lv != _applied:
		_light.light_energy = _energy * lv
	_applied = lv
	for g in _glows:
		if is_instance_valid(g):
			_dim_glow(g, lv)


## Brightness at time t (seconds on this lamp's own clock). Call with rising t.
func sample(t: float) -> float:
	if mode == "candle":
		var w := 0.0625 * sin(TAU * 1.7 * t + _phase[0]) + 0.04 * sin(TAU * 3.9 * t + _phase[1]) \
				+ 0.0225 * sin(TAU * 7.3 * t + _phase[2])
		return clampf(0.875 + w, 0.75, 1.0)
	while t >= _next:
		_schedule(_next)
	var lv := 1.0
	for d in _dips:
		if t >= d[0] and t < d[1]:
			lv = minf(lv, d[2])
	for r in _ramps:
		if t >= r[0] and t < r[3]:
			var k := 1.0
			if t < r[1]:
				k = (t - r[0]) / (r[1] - r[0])
			elif t > r[2]:
				k = (r[3] - t) / (r[3] - r[2])
			lv = minf(lv, lerpf(1.0, r[4], smoothstep(0.0, 1.0, k)))
	_dips = _dips.filter(func(d): return d[1] > t)
	_ramps = _ramps.filter(func(r): return r[3] > t)
	if mode == "fluorescent":
		lv *= 0.985 + 0.015 * sin(TAU * 0.6 * t + _phase[0])   # a faint uneven hum, never a flash
	return lv


func _gap() -> float:
	match mode:
		"fluorescent":
			return _rng.randf_range(2.0, 6.0)
		"harsh":
			return _rng.randf_range(0.8, 2.5)
		_:
			return _rng.randf_range(5.0, 12.0)


## Adds the drop-outs of one event starting at `t0` and sets the time of the next event.
## Default modes keep their drop-outs at least 0.35 s apart: at most 3 flashes in any second.
func _schedule(t0: float) -> void:
	var t := t0
	match mode:
		"fluorescent":
			var blinks := 1 if _rng.randf() < 0.7 else 2
			for b in blinks:
				var off := _rng.randf_range(0.05, 0.10)
				_dips.append([t, t + off, 0.12])
				t += off + _rng.randf_range(0.30, 0.40)
		"bulb":
			if _rng.randf() < 0.7:
				var off := _rng.randf_range(0.08, 0.15)
				_dips.append([t, t + off, 0.35])
				t += off
			else:   # brown-out: down to 60 %, never below half, so not a flash
				var hold := _rng.randf_range(0.5, 1.0)
				_ramps.append([t, t + 0.4, t + 0.4 + hold, t + 0.7 + hold, 0.6])
				t += 0.7 + hold
		"harsh":
			for b in _rng.randi_range(3, 6):
				var off := _rng.randf_range(0.03, 0.06)
				_dips.append([t, t + off, 0.05])
				t += off + _rng.randf_range(0.04, 0.08)
	_next = maxf(t + 0.35, t0 + _gap())


func _dim_glow(g: MeshInstance3D, lv: float) -> void:
	var mesh := g.mesh
	if mesh == null:
		return
	for i in mesh.get_surface_count():
		var cur: Material = mesh.surface_get_material(i)
		if cur == null:
			continue
		var key := "%d:%d" % [g.get_instance_id(), i]
		var entry: Array = _glow_mats.get(key, [])
		if entry.is_empty() or entry[0] != cur:     # first frame, or the material was swapped (PSX look)
			var base := _emission(cur)
			if base <= 0.0:
				_glow_mats[key] = [cur, null, 0.0, lv]
				g.set_surface_override_material(i, null)
				continue
			var own: Material = cur.duplicate()
			g.set_surface_override_material(i, own)
			entry = [cur, own, base, -1.0]
			_glow_mats[key] = entry
		if entry[1] == null or entry[3] == lv:
			continue
		entry[3] = lv
		var e: float = entry[2] * lv
		if entry[1] is StandardMaterial3D:
			(entry[1] as StandardMaterial3D).emission_energy_multiplier = e
		elif entry[1] is ShaderMaterial:
			(entry[1] as ShaderMaterial).set_shader_parameter("emission_energy", e)


func _emission(m: Material) -> float:
	if m is StandardMaterial3D:
		var s := m as StandardMaterial3D
		return s.emission_energy_multiplier if s.emission_enabled else 0.0
	if m is ShaderMaterial:
		var v = (m as ShaderMaterial).get_shader_parameter("emission_energy")
		return float(v) if v != null else 0.0
	return 0.0
