// Cordatix PSX effect card, alpha-blended (Godot 4.3+): fog, dust, mist, cobweb haze, silhouettes and
// rain behind windows. Haunted PSX packs ship their cards with it; any engine can rebuild the same card
// as an alpha-blended plane (the README of each pack says how).
//   lit = 1: the card takes the room's light, so fog stays dark in a dark corner and glows by a lamp.
//   lit = 0: the card shows its own colours (a view outside a window, a backlit silhouette).
// Soft edges and a camera fade keep a card from showing a hard line where it meets a wall or a floor,
// and from filling the screen when the camera walks into it.
shader_type spatial;
render_mode blend_mix, depth_draw_never, cull_disabled, diffuse_lambert_wrap, specular_disabled;

uniform sampler2D tex : source_color, filter_nearest, repeat_enable;
uniform vec4 tint : source_color = vec4(1.0);
uniform float opacity : hint_range(0.0, 1.0) = 1.0;
uniform float lit : hint_range(0.0, 1.0) = 1.0;
// Texture repeats across the card, and a scroll in repeats per second (rain).
uniform vec2 uv_scale = vec2(1.0);
uniform vec2 uv_scroll = vec2(0.0);
// Fade over this share of the card at each UV border (0 = hard edges).
uniform float edge_fade : hint_range(0.0, 0.5) = 0.0;
// Fade out within this distance of the camera, in metres (0 = never).
uniform float camera_fade = 0.0;
// PS1 vertex snapping: vertical resolution of the grid, 0 = off.
uniform float snap_resolution : hint_range(0.0, 1080.0) = 240.0;

varying float view_depth;

void vertex() {
	vec4 view = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	view_depth = -view.z;
	vec4 clip = PROJECTION_MATRIX * view;
	if (snap_resolution > 0.0 && clip.w > 0.25) {
		vec2 grid = vec2(snap_resolution * VIEWPORT_SIZE.x / VIEWPORT_SIZE.y, snap_resolution) * 0.5;
		clip.xy = round(clip.xy / clip.w * grid) / grid * clip.w;
	}
	POSITION = clip;
}

void fragment() {
	vec2 uv = UV * uv_scale + uv_scroll * TIME;
	vec4 c = texture(tex, uv) * tint;
	float a = c.a * opacity;
	if (edge_fade > 0.0) {
		vec2 e = min(UV, vec2(1.0) - UV);
		a *= smoothstep(0.0, edge_fade, min(e.x, e.y));
	}
	if (camera_fade > 0.0) {
		a *= smoothstep(0.0, camera_fade, view_depth - 0.05);
	}
	NORMAL = FRONT_FACING ? NORMAL : -NORMAL;   // both sides of the card take the light
	ALBEDO = c.rgb * lit;
	EMISSION = c.rgb * (1.0 - lit);
	ROUGHNESS = 1.0;
	ALPHA = a;
}
