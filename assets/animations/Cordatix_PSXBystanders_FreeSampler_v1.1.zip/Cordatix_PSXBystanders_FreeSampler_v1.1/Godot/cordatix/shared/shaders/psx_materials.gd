extends RefCounted
## Cordatix PSX helper (Godot 4.3+): turns any StandardMaterial3D from a Cordatix pack into a
## ShaderMaterial that uses psx_surface.gdshader (vertex snapping + affine texture warping),
## psx_surface_cutout.gdshader for a material with alpha scissor (decals, grates), or
## psx_surface_blend.gdshader for a see-through one (glass).
##
##   const PSX := preload("res://cordatix/shared/shaders/psx_materials.gd")
##   var mat: StandardMaterial3D = load("res://cordatix/liminal_psx_textures/materials/carpet_loop_beige_damp.tres")
##   $Floor.material_override = PSX.to_psx(mat)
##
## World materials (materials_world/) keep their world-space projection.
## Snapping and affine warping look right on meshes subdivided to about 0.5 m; on large
## single quads (CSG boxes, blockouts) pass a lower affine_strength, e.g. to_psx(mat, 240.0, 0.25).

const SURFACE := preload("res://cordatix/shared/shaders/psx_surface.gdshader")
const CUTOUT := preload("res://cordatix/shared/shaders/psx_surface_cutout.gdshader")
const BLEND := preload("res://cordatix/shared/shaders/psx_surface_blend.gdshader")


static func to_psx(m: StandardMaterial3D, snap_resolution := 240.0, affine_strength := 1.0) -> ShaderMaterial:
	var s := ShaderMaterial.new()
	var cut := m.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA_SCISSOR
	var blend := m.transparency == BaseMaterial3D.TRANSPARENCY_ALPHA
	s.shader = CUTOUT if cut else (BLEND if blend else SURFACE)
	s.set_shader_parameter("albedo_tex", m.albedo_texture)
	s.set_shader_parameter("albedo_color", m.albedo_color)
	if m.uv1_triplanar:
		s.set_shader_parameter("world_mapping", true)
		s.set_shader_parameter("meters", Vector2(1.0 / m.uv1_scale.x, 1.0 / m.uv1_scale.y))
	else:
		s.set_shader_parameter("uv_scale", Vector2(m.uv1_scale.x, m.uv1_scale.y))
	# thin parts (a bulb's cord) carry metadata psx_no_snap: snapped, a cord thinner than a pixel breaks into dashes
	s.set_shader_parameter("snap_resolution", 0.0 if m.get_meta("psx_no_snap", false) else snap_resolution)
	# an optional depth pull toward the camera (metadata psx_depth_bias, a share of the distance; the packs ship none:
	# from a few metres it pulls a surface through a thin wall, and it also acts in shadow passes)
	s.set_shader_parameter("depth_bias", float(m.get_meta("psx_depth_bias", 0.0)))
	s.set_shader_parameter("affine_strength", affine_strength)
	if m.emission_enabled:
		s.set_shader_parameter("emission_tex", m.emission_texture)
		s.set_shader_parameter("emission_energy", m.emission_energy_multiplier)
	if cut:
		s.set_shader_parameter("alpha_scissor", m.alpha_scissor_threshold)
	return s
