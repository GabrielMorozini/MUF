// Cordatix PSX effect card, additive (Godot 4.3+): light beams through windows and holes, and light
// patches cast through a mask (window panes, blinds, branches) onto a floor or a wall. It adds light and
// never darkens; set it on crossed planes so a beam still reads from the side. Any engine can rebuild it
// as an additive (or emissive, alpha-blended) plane; the packs' READMEs say how.
shader_type spatial;
render_mode unshaded, blend_add, depth_draw_never, cull_disabled;

uniform sampler2D tex : source_color, filter_nearest, repeat_enable;
uniform vec4 tint : source_color = vec4(1.0);
uniform float intensity : hint_range(0.0, 4.0) = 1.0;
uniform vec2 uv_scale = vec2(1.0);
uniform vec2 uv_scroll = vec2(0.0);
// Fade over this share of the card at each UV border (0 = hard edges).
uniform float edge_fade : hint_range(0.0, 0.5) = 0.0;
// Fade out within this distance of the camera, in metres (0 = never).
uniform float camera_fade = 0.0;
uniform float snap_resolution : hint_range(0.0, 1080.0) = 240.0;

varying float view_depth;

void vertex() {
	vec4 view = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	view_depth = -view.z;
	vec4 clip = PROJECTION_MATRIX * view;
	if (snap_resolution > 0.0 && clip.w > 0.25) {
		vec2 grid = vec2(snap_resolution * VIEWPORT_SIZE.x / VIEWPORT_SIZE.y, snap_resolution) * 0.5;
		clip.xy = round(clip.xy / clip.w * grid) / grid * clip.w;
	}
	POSITION = clip;
}

void fragment() {
	vec2 uv = UV * uv_scale + uv_scroll * TIME;
	vec4 c = texture(tex, uv) * tint;
	float k = intensity * c.a;
	if (edge_fade > 0.0) {
		vec2 e = min(UV, vec2(1.0) - UV);
		k *= smoothstep(0.0, edge_fade, min(e.x, e.y));
	}
	if (camera_fade > 0.0) {
		k *= smoothstep(0.0, camera_fade, view_depth - 0.05);
	}
	ALBEDO = c.rgb * k;
}
