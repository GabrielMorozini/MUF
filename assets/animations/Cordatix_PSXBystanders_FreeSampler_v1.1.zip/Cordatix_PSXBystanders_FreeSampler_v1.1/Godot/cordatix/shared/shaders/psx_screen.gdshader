// Cordatix PSX screen filter (Godot 4.3+): 15-bit colour with 4x4 ordered dithering.
// Put it on a SubViewportContainer (with stretch_shrink for the low resolution).
shader_type canvas_item;

uniform bool enabled = true;
// Levels per channel: 31 = PS1 15-bit colour.
uniform float color_levels = 31.0;
uniform float dither_strength : hint_range(0.0, 1.0) = 1.0;

const float BAYER[16] = float[16](
	0.0, 8.0, 2.0, 10.0,
	12.0, 4.0, 14.0, 6.0,
	3.0, 11.0, 1.0, 9.0,
	15.0, 7.0, 13.0, 5.0);

void fragment() {
	vec4 c = texture(TEXTURE, UV);
	if (enabled) {
		ivec2 px = ivec2(UV * vec2(textureSize(TEXTURE, 0)));
		int i = (px.y % 4) * 4 + (px.x % 4);
		float t = (BAYER[i] / 16.0 - 0.5) * dither_strength;
		c.rgb = floor(c.rgb * color_levels + t + 0.5) / color_levels;
	}
	COLOR = c;
}
