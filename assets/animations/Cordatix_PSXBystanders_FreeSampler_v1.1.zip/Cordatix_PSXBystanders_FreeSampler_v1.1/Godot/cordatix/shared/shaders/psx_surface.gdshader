// Cordatix PSX surface shader (Godot 4.3+).
// PS1-style vertex snapping and affine texture mapping for any opaque mesh; psx_surface_cutout.gdshader is
// the same for cut-out textures (decals, grates). Use it on its own ShaderMaterial, or let PSX.to_psx()
// in psx_materials.gd convert StandardMaterial3D on the fly. It writes no ALPHA: a shader that does is
// drawn as a cut-out, and then opaque walls shadow themselves in a crosshatch under a shadow-casting light.
shader_type spatial;
render_mode blend_mix, depth_draw_opaque, cull_back, diffuse_lambert, specular_disabled;

// Nearest with mipmaps: crisp texels up close, no shimmer in the distance.
uniform sampler2D albedo_tex : source_color, filter_nearest_mipmap, repeat_enable;
uniform sampler2D emission_tex : source_color, hint_default_black, filter_nearest_mipmap, repeat_enable;
uniform vec4 albedo_color : source_color = vec4(1.0);
uniform float emission_energy = 0.0;
// Texture repeat in UV space (meshes from the showcase already carry metre-based UVs).
uniform vec2 uv_scale = vec2(1.0);
// Optional planar world projection for untextured blockout meshes: one repeat = `meters`.
uniform bool world_mapping = false;
uniform vec2 meters = vec2(2.0, 2.0);
// Vertical resolution of the vertex-snapping grid; 0 turns snapping off.
uniform float snap_resolution : hint_range(0.0, 1080.0) = 240.0;
// Pulls the surface towards the camera by this share of its distance, in depth only (it stays at the same place on
// screen). 0 in the Cordatix packs: from a few metres the pull takes a surface through a thin wall or door, and it
// acts in shadow passes too. Against thin things sinking into a large snapped surface (a mask on a table), draw the
// large one unsnapped instead (metadata psx_no_snap).
uniform float depth_bias : hint_range(0.0, 0.05) = 0.0;
// 0 = perspective-correct textures, 1 = full PS1 affine warping.
uniform float affine_strength : hint_range(0.0, 1.0) = 1.0;

varying vec3 uv_affine;
varying vec2 uv_persp;

void vertex() {
	vec2 uv = UV * uv_scale;
	if (world_mapping) {
		vec3 wp = (MODEL_MATRIX * vec4(VERTEX, 1.0)).xyz;
		vec3 wn = abs(normalize((MODEL_MATRIX * vec4(NORMAL, 0.0)).xyz));
		if (wn.y >= wn.x && wn.y >= wn.z) {
			uv = wp.xz / meters;
		} else if (wn.x >= wn.z) {
			uv = vec2(wp.z, -wp.y) / meters;
		} else {
			uv = vec2(wp.x, -wp.y) / meters;
		}
	}
	vec4 view = MODELVIEW_MATRIX * vec4(VERTEX, 1.0);
	view.xyz *= 1.0 - depth_bias;
	vec4 clip = PROJECTION_MATRIX * view;
	// No snapping for vertices at or behind the camera plane: dividing by a tiny or negative w
	// would throw them across the screen and tear holes in walls you walk along.
	if (snap_resolution > 0.0 && clip.w > 0.25) {
		vec2 grid = vec2(snap_resolution * VIEWPORT_SIZE.x / VIEWPORT_SIZE.y, snap_resolution) * 0.5;
		clip.xy = round(clip.xy / clip.w * grid) / grid * clip.w;
	}
	POSITION = clip;
	// Affine weight: clip.w, but never below 1 m. Vertices close to or behind the camera
	// (long walls you walk along) otherwise blow the warp up into texture garbage; PS1 games
	// avoided this by subdividing, here it is simply clamped.
	float wa = max(clip.w, 1.0);
	uv_affine = vec3(uv * wa, wa);
	uv_persp = uv;
}

void fragment() {
	vec2 uv = mix(uv_persp, uv_affine.xy / uv_affine.z, affine_strength);
	vec4 c = texture(albedo_tex, uv) * albedo_color;
	ALBEDO = c.rgb;
	EMISSION = texture(emission_tex, uv).rgb * emission_energy;
	ROUGHNESS = 1.0;
}
