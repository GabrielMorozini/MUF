extends Node3D
## Cordatix door: swings the "Hinge" child open and closed.
## Call toggle() from your own interaction code, or leave auto_open on: the door opens when a
## node in group "player" comes within open_distance, and closes again after it leaves
## (add your player with add_to_group("player")). Turn auto_open off to keep a door shut.
## The Hinge is an AnimatableBody3D: the leaf's collision swings with it and pushes physics bodies.

@export var open_degrees := -95.0
## 240 deg/s with open_distance 2.5: the leaf has swung far enough to pass before a player walking
## (3 m/s) or running (6 m/s) reaches it (tested). A faster runner can be bumped aside or pinned
## against the wall by the swinging leaf: raise open_distance (3 is tested up to 8 m/s, 4.5 up to 12).
@export var speed_deg := 240.0
@export var auto_open := true
@export var open_distance := 2.5
@export var start_open := false

var is_open := false
var _angle := 0.0
@onready var _hinge: Node3D = $Hinge


func _ready() -> void:
	is_open = start_open
	_angle = open_degrees if start_open else 0.0
	_hinge.rotation_degrees.y = _angle


func toggle() -> void:
	is_open = not is_open


## Open or close at once, without the swing (e.g. for screenshots).
func set_open_now(open: bool) -> void:
	is_open = open
	_angle = open_degrees if open else 0.0
	_hinge.rotation_degrees.y = _angle


func _physics_process(delta: float) -> void:
	if auto_open:
		var near := false
		for body in get_tree().get_nodes_in_group("player"):
			if body is Node3D and (body as Node3D).global_position.distance_to(global_position) < open_distance:
				near = true
		is_open = near
	var target := open_degrees if is_open else 0.0
	_angle = move_toward(_angle, target, speed_deg * delta)
	_hinge.rotation_degrees.y = _angle
