# PSX Bystanders NPC Pack Free Sampler

Two people from *PSX Bystanders NPC Pack* (20 people in 60 looks), free: Office Worker (Office) and Young Man (Courier), each in its first look with all 36 clips, the Godot NPC layer and the crowd that run them, and a small waiting room to try them in. For Godot 4, Unity, Unreal and Blender. By Cordatix.

- **2 people, 2 looks**, aged 24 to 34, 1,994-2,178 triangles a look with the accessories it wears; a 256 x 256 texture a look and one for the accessories (at most 64 colours, light and shade baked in, nearest filtering)
- **36 clips at 30 fps**, keyed every frame and baked to each person's own skeleton (a stride that fits the legs, the hips on the seat): the gaits play in place with their speeds; turns and one-shots end in Idle
- **One skeleton for all:** 28 bones, 24 of them named for Godot's humanoid profile and all of those but Root for Unity's Humanoid (the hands' Fingers and Thumb bones are the pack's own), bound in a T-pose, each person with its own lengths (1.66-1.84 m tall); in Godot, clips of another humanoid retarget onto them and theirs onto yours (tested in Godot 4.3 and 4.7.2, and in Blender)
- **Accessories as their own meshes** (glasses, hats, bags, a lanyard, a helmet...): each look wears its own, any can be switched on or off in any look; the phone shows in the phone clips, the box in Carry and CarryIdle
- **Godot 4.3+:** `CordatixBystander` (spots to sit, type, stand at a counter, lean, wait, talk, queue or look; seated neighbours who talk in turn; it carries a box or walks looking at its phone; the head turns to the player; it makes way, talks to the player, starts, backs away, cowers and flees), `CordatixBystanderSpot`, `CordatixBystanderCrowd` (fills a level's spots from a seed); the small waiting room and a showcase
- **The demo's two props and four finishes** in every format (station bench, station lamp; the room's walls, floor, ceiling and window glass)
- Formats: GLB and FBX (Unity, Unreal) with every clip, each look and accessory alone as FBX too (for Unreal), OBJ + MTL (each look in the Idle pose), Data (every clip's length, speed and events; the props' spots and lights; CSV and JSON) and a Blender asset library
- Metres, +Y up, the origin on the floor; every person and prop faces +Z in GLB, FBX and OBJ (in Godot, -Z: its scene turns it)

## What's new

- **1.1:** The full pack's five new clips (SitLean, SitTalk, PhoneWalk, Carry and CarryIdle, with the box both people now hold) and its 2.0 NPC layer. Free for everyone who has an earlier version.

## The people

| Person | Age, height | Looks (who they are) | Triangles with accessories | Accessories (worn in) |
|---|---|---|---|---|
| Office Worker | 34, 1.66 m | Office (office worker) | 1,994 | Glasses (office), Lanyard (office), Phone (the phone clips), Box (Carry and CarryIdle) |
| Young Man | 24, 1.84 m | Courier (courier) | 2,178 | Cap (courier), Satchel (courier; standing only), Phone (the phone clips), Box (Carry and CarryIdle) |

The Catalog lists every look and accessory with its triangles, texture and files. A look's mesh is named after the look (`Office`), an accessory's after it (`Glasses`), the skeleton after the person (`Office Worker`), in every format.

Worn only standing: Young Man's satchel. Seated, it would go through a seat's back, and leaning, through the wall, so in Godot the person takes it off from SitDown to StandUp and in LeanWall and has it back on standing (a crowd leaves it off on the people it seats, leans or lets wander); in another engine, hide its mesh in those clips.

## The clips

One set of clips, made once and baked to each person: every clip plays on every person, in every engine, with no retargeting. 30 fps, keyed every frame.

| Clip | What it does | Loop |
|---|---|---|
| **Standing** | | |
| `Idle` | standing, breathing | yes |
| `IdleShift` | the weight from foot to foot | yes |
| `IdleWait` | arms folded, a look at the watch | yes |
| `LookAround` | a look round, once |  |
| `LookBehind` | a look over the shoulder, once |  |
| **Moving (in place, with speeds)** | | |
| `Walk` | a walk | yes |
| `Stroll` | a slower walk | yes |
| `Run` | a run | yes |
| `Flee` | a scared run, the arms up | yes |
| `TurnLeft` | a quarter turn left |  |
| `TurnRight` | a quarter turn right |  |
| **With others** | | |
| `Talk` | talking, the hands with the words | yes |
| `Listen` | listening, with small nods | yes |
| `Nod` | yes |  |
| `ShakeHead` | no |  |
| `Wave` | a wave |  |
| `Point` | pointing ahead |  |
| **Phone** | | |
| `PhoneLook` | looking at the phone | yes |
| `PhoneCall` | on the phone | yes |
| **Seat, desk, counter, wall** | | |
| `SitDown` | sits down on a seat behind |  |
| `Sit` | seated | yes |
| `SitPhone` | seated, looking at the phone | yes |
| `SitType` | seated, typing at a desk | yes |
| `StandUp` | stands up from the seat |  |
| `CounterIdle` | the hands on a counter | yes |
| `LeanWall` | leaning on a wall | yes |
| **Fright** | | |
| `Startle` | a start, then back to Idle |  |
| `Cower` | crouched, the arms over the head | yes |
| `BackAway` | a few steps back, the palms out |  |
| `Hit` | struck, recovers (not on a minor) |  |
| `Fall` | falls and lies on the left side (not on a minor) |  |
| **New in 2.0** | | |
| `SitLean` | seated, leaning forward, the elbows on the knees | yes |
| `SitTalk` | seated, talking with the hands | yes |
| `PhoneWalk` | walking, looking at the phone (with its speed) | yes |
| `Carry` | walking with a box in both hands (with its speed) | yes |
| `CarryIdle` | standing with the box | yes |

**Speeds** (metres a second at which the feet stay planted: move the body at this speed while the gait plays in place; each person's own, from its stride):

| Person | Walk | Stroll | Run | Flee | PhoneWalk | Carry | BackAway |
|---|---|---|---|---|---|---|---|
| Office Worker | 1.12 | 0.74 | 2.76 | 3.58 | 0.92 | 0.90 | 0.55 m back over 1.6 s |
| Young Man | 1.26 | 0.83 | 3.10 | 4.03 | 1.03 | 1.01 | 0.62 m back over 1.6 s |

- **Turns:** TurnLeft and TurnRight turn the body 90 degrees in place and end turned; turn the character's root by the same at their end.
- **BackAway** carries the body back as it plays: move the root backwards along its facing by the clip's travel, at the speed the table gives (in Godot the layer does it; the feet stay planted).
- **Fall** ends lying on the left side, the knees bent: it needs about 1 m of clear floor to the person's left.
- **Events** (`Data/events.csv`, with the frame, the seconds and the normalized time; for Unity's Animation Events and Unreal's Notifies): `step` (with the foot), `voice` (Talk, SitTalk, PhoneCall), `phone` (show the phone), `box` (show the box: Carry, CarryIdle), `sit`, `stand`, `type` (SitType's keystrokes), `gasp`, `fall`, `land`. No sounds are included.
- Lengths, speeds, travels, turns and events of every person's clips: `Data/clips.csv`.

## The furniture the clips fit

Measured from where the feet stand (a spot's marker in Godot), the person facing the furniture's way:

| Clip | Furniture |
|---|---|
| SitDown, Sit, SitPhone, SitLean, SitTalk, StandUp | a seat 0.45 m high, its front edge 0.10 m behind the feet (a child's feet hang off it, as a child's do) |
| SitType | that seat, and a desk 0.75 m high, its near edge 0.03 m in front of the feet |
| CounterIdle | a counter 0.95 m high, its near edge 0.22 m in front of the feet (toe space under it up to 0.15 m) |
| LeanWall | a wall 0.20 m behind the feet |
| Carry, CarryIdle | the box each person has, about 0.40 x 0.30 x 0.28 m (a child's smaller, by their height), held by its sides in front of the belly |

Each person's hips land on the seat by their own build, and the hands rest on the desk and the counter over the thickest sleeve. The chairs and lobby seats of Liminal PSX Office Props are 0.45 m high and its desks 0.74 m, the heights these clips fit.

## Downloads and folders

The sampler comes as two downloads that unzip into the same folder, `Cordatix_PSXBystanders_FreeSampler_v1.1/`; each has this README, the LICENSE and the Catalog:

- `Cordatix_PSXBystanders_FreeSampler_v1.1.zip`: start here: the Godot project (the people, the NPC layer and the crowd, the small waiting room and the showcase)
- `Cordatix_PSXBystanders_FreeSampler_v1.1_Models.zip`: GLB, FBX and OBJ of the people and the props, Data, the Finishes and the Blender asset library

| Folder | What it is |
|---|---|
| `Godot/` | Godot 4.3+ project: open `project.godot` and press Play for the small waiting room; F1 there opens the showcase, and F1 in the showcase comes back. Or copy the `cordatix` folder into your project: the paths are the full pack's |
| `GLB/People/` | `<person>.glb`: the skeleton, every look's mesh, every accessory's and every clip, the textures embedded |
| `GLB/Props/` | `<prop>.glb`: each prop, its texture embedded |
| `FBX/People/` | `<person>.fbx`: the same for Unity, every clip a take (`<Person>\|<Clip>`), with `textures/`; `Meshes/<person>_<mesh>.fbx`: each look and each accessory alone on the person's skeleton, no clips (for Unreal) |
| `FBX/Props/` | `<prop>.fbx`, with `textures/` |
| `OBJ/People/` | `<person>_<look>.obj`: each look in the Idle pose with the accessories it wears, no skeleton, with `textures/` |
| `OBJ/Props/` | `<prop>.obj`, with `textures/` |
| `Data/` | `clips.csv` (every person's clips: loop, frames, length, speed, travel, turn, events), `events.csv` (every event: clip, frame, seconds, normalized time), `people.json` (the people, looks, accessories and clips, as the Godot layer reads them), `spots.csv` and `lights.csv` (the props') |
| `Finishes/` | the room's finishes: seamless textures, 2 x 2 m a tile at 64 px per metre |
| `Blender/` | `People/`: a .blend a person, each look a collection asset with a preview, every clip an action; `Props/`: a .blend a prop; the textures packed inside (Blender 5.2) |
| `Catalog.csv` | every look, accessory, prop and finish: triangles, texture, size, files |

## Godot 4

1. Copy `Godot/cordatix/` into your project (keep the folder name): the people are in `cordatix/psx_bystanders/`, the shared PSX shaders in `cordatix/shared/`, and the free room pieces the demo is built from in `cordatix/haunted_psx_spaces/` (the same files as in every Cordatix PSX Horror pack).
2. Drop `people/<person>.tscn` into a level (`office_worker.tscn`...): a CharacterBody3D with a capsule, a NavigationAgent3D and `scripts/bystander.gd`. In the inspector: `look` (1-3), `mode` (STAY where it stands, SPOT to walk to its `spot`, WANDER from spot to spot), `spot`, `idle_clip`, `walk_clip` (Walk or Stroll), `look_at_player`, `make_way`, `stepped_fps` (0, or 12 or 15 for PS1-style stepped animation; it may change while it runs), `psx` (vertex snapping and affine textures) and each accessory on or off.
3. A navigation mesh for them to walk on, baked with Cell Size 0.1, Cell Height 0.1, Agent Radius 0.3 and Agent Max Climb 0.2, and Project Settings > Navigation > 3D > Default Cell Size and Height 0.1 (the project sets them; Godot's defaults close the series' 1.0 m doorways). The player is the body in the group `player`: a person turns its head to the player's camera (or to `look_target`; `CordatixBystanderLook.default_target` for all of them, for third person or fixed cameras).
4. **Spots** (`CordatixBystanderSpot`, a Marker3D: its marker where the feet go, its -Z the way they face): SEAT, DESK, COUNTER, LEAN, WAIT, TALK (a pair, each the other's `partner`), QUEUE (each place's `ahead` is the one in front; the head of a line waits for a served counter) and LOOK (`look_at_node`). A spot is taken by one person at a time; `reserved` keeps it for the person put there (a clerk's desk), `served` makes a counter a customer's, done and gone after `serve_time`; `who` says who a crowd puts there. The props' scenes (`props/`) carry their own spots.
5. **A crowd** (`CordatixBystanderCrowd`, a node over a level's spots): `populate(seed)` puts a person at each spot, already doing what it says, in a look and with accessories drawn from the seed: never the same person in the same look twice, the same person at most `max_same` times; `fill` leaves some spots empty, `wanderers` walk from spot to spot, `people` limits who comes, `feed_lines` sends one of the wanderers (the one longest out of a line) to the end of a line with fewer than two waiting (a served line needs `wanderers` at 2 or more: with none, it empties as its people are served and go; the more wanderers, the more faces take a turn). The same seed gives the same crowd. `populate()` and `load_save()` make the members anew: connect your signals to them on the crowd's `populated(count)` signal (`members()` gives them).
6. **The player:** `talk_to_player(player)` (it stops, turns to the player and talks; seated, it talks seated, SitTalk; `talked_to` is where your dialogue starts) and `end_talk()`, which your game calls when the talk is over (nothing ends it by itself; the demo ends it when the player walks 3.5 m away); a person in the player's way steps aside and back (`make_way`: it reads the player's `velocity`, as a CharacterBody3D has it). **Reactions:** `startle(from)`, `back_away(from)` (BackAway, carried back along its facing), `cower()`, `flee(from)` (away on the navigation mesh, then it cowers), `calm()`; `CordatixBystander.alarm(get_tree(), position, radius, reaction)` tells everyone near a point at once. **Doing:** `go_to(position)`, `use_spot(spot)`, `place_at_spot(spot)`, `leave_spot()`, `play(clip)`, `set_look(n)`, `set_accessory(name, on)`.
7. Signals: `arrived(spot)`, `sat_down`, `stood_up`, `noticed_player(player)`, `talked_to(player)`, `talk_ended`, `startled`, `backed_away`, `fled`, `bystander_event(event_name, data)` (the clips' events: `step`, `voice`, `phone`, `box`, `sit`, `stand`, `type`, `gasp`, `fall`, `land`). Saves: `get_save()` and `load_save(data)` for a person and for a crowd.
8. **2.0:** `carrying` (Carry and CarryIdle, the box in both hands: it turns standing so the box stays in its hands, sets it aside at a spot to sit, type, lean or stand at a counter, and as a wanderer goes only to places to wait, look or queue), `phone_walk` (it walks with PhoneWalk); a SEAT's `partner` (the seat beside it: the two, both seated, talk in turn, SitTalk and Sit, their heads turned to each other) and `lean` (how often its person sits forward, SitLean); `is_minor()` (under 18: no Hit and no Fall, which the layer never plays on them; `startle`, `back_away`, `cower` and `flee` work on everyone), `has_clip(clip)`, `role_accessory(name)`. The crowd's `minors` (off: nobody under 18 placed), `phone_walk` and `carry` (the shares of its wanderers who walk on their phones or carry a box).

The demos: `demo/room.tscn` (the main scene) is a small waiting room of the free room pieces with two benches and the two people in it; `demo/hall.tscn` is the full pack's waiting hall, and with the sampler's files it has the benches and lamps only. WASD move, mouse look, Shift run, E talk to the one you face, X scare (once: the near ones back away, the others start; again: they flee), C calm, L day / night, N a new crowd, R the same crowd again, P PSX look, O stepped animation, F1 the showcase, Esc the closing screen (Rate on itch, back, quit). `demo/showcase.tscn`: every person in every look, a button for every clip (with a stand-in seat, desk, counter or wall), the accessories on and off, the head to the camera.

The demo's lights: the project sets Rendering > Limits > OpenGL > Max Renderable Lights 64 and Max Lights Per Object 32 (Godot's defaults are 32 and 8); copy them if you run the demo in your own project.

Godot 4.3 run headless (a dedicated server, a CI job) prints one engine line, `Parameter "m" is null` (mesh_get_surface_count), when a skinned model is freed: any skinned GLB does it, with or without these scripts. It is harmless; Godot 4.7.2, and 4.3 drawing on screen, do not print it.

## Retargeting

- **Godot:** the people's bones carry the names of Godot's humanoid profile, so the importer maps them by itself, but for the hands' LeftFingers, LeftThumb, RightFingers, RightThumb: those are the pack's own, a Bone Map leaves them unmapped and a finger pose does not carry over. To play a clip of another humanoid skeleton on them (or theirs on your own character), import both with a Bone Map of `SkeletonProfileHumanoid` (the Advanced Import Settings: Skeleton3D > Retarget > Bone Map) and the importer's rest fixer (Fix Silhouette, Overwrite Axis): the clips then share one set of bone names. Tested in Godot 4.3 and 4.7.2 with a skeleton of other names, proportions and bone axes, both ways: each bone turns as the clip turns it, each limb points where the clip points it, the planted feet stay on the floor.
- **Blender:** every person's clips are actions on bones of the same names, each with the same slot (`Bystander`) every rig remembers: assign one to any look's rig, or append it to another person's file and assign it to their rig (the Action Editor), and it plays at once. A clip keeps its own person's hip height (the Hips' place is keyed): on a taller or shorter person, another person's seated and floor clips put the body into the seat or the floor or above it, and its desk and counter clips put the hands into the top or above it. Each file has all 36 clips of its own person (a child's or a teenager's 34: no Hit, no Fall); for a character of your own, retarget in Godot as above.
- **Unity and Unreal:** the skeleton is named and posed for Unity's Humanoid (Hips, Spine, Chest, UpperChest, Neck, Head, LeftShoulder, LeftUpperArm, LeftLowerArm, LeftHand, LeftUpperLeg, LeftLowerLeg, LeftFoot, LeftToes and the right side; the Jaw is optional there, and the hands' Fingers and Thumb bones have no Humanoid slot of that name: map them by hand to Index Proximal and Thumb Proximal, or leave the fingers empty) and for Unreal's IK Retargeter, bound in a T-pose. We have not tested retargeting in those engines.

## Unity and Unreal

- **FBX:** Unity Scale Factor 1 with Convert Units on; Unreal Import Uniform Scale 1 with Convert Scene Unit on. `FBX/People/<person>.fbx` has every look, every accessory and every clip (30 fps takes named `<Person>|<Clip>`, for example `Office Worker|Walk`); turn on looping for the clips `Data/clips.csv` marks `loop`.
- **Unity:** Animation Type Humanoid (see Retargeting) or Generic (every bone plays as made). Show one look's mesh and hide the others; each accessory is a mesh to show or hide.
- **Unreal:** import a look from `FBX/People/Meshes/` as a Skeletal Mesh (it makes the person's Skeleton), then `FBX/People/<person>.fbx` with Import Mesh off and Import Animations on, onto that Skeleton; import each accessory from `Meshes/` as a Skeletal Mesh on the same Skeleton and let it follow the body (Set Leader Pose Component).
- **Root motion:** the gaits play in place; move the character at the clip's speed (`Data/clips.csv`, the Speeds table above) so the feet stay planted. A turn ends turned (turn the root by its `turn_deg` at its end); BackAway travels back (`travel_m`).
- **Compression:** the clips are keyed every frame and checked so (no hand through the body, the hands on the desk); an engine's key reduction can move a hand or a foot a little (Godot's key optimizer moved a joint up to 15 mm, so its import turns it off). In Unity, Anim. Compression Off; in Unreal, lower the compression error if a hand goes into a desk.
- **Textures:** point (nearest) filtering, no compression. Thin parts seen from both sides are modelled with both faces, so back-face culling stays on. The textures with cut-out texels (`office_worker_accessories.png`; the Catalog's `cut_out`) need alpha clipping at 0.5 (Unity: Alpha Clipping 0.5; Unreal: Blend Mode Masked).
- **Glow:** the phone's screen, station lamp shine through an emission map beside its texture, `<texture>_emit.png` (the Catalog's `glow`). Unity: Emission on, Emission Map = the `_emit.png`, colour white. Unreal: the `_emit` texture into Emissive Color. GLB and .blend carry it.
- **The behaviour is Godot's:** in another engine, the models, looks, accessories, clips, speeds and events work as they are, and the spots, the look at the player and the crowd are yours to build: a spot is a place, a facing and a clip (the furniture table above; `Data/spots.csv` gives the props'), the look turns the Chest 0.15, the Neck 0.35 and the Head 0.5 of the angle to the player's head, at most 65 degrees to a side and 30 degrees a second.

## Blender

Add the `Blender/` folder as an asset library (Preferences > File Paths > Asset Libraries) and drag a look or a prop in from the Asset Browser, or open its .blend. Each look is a collection asset with its own rig standing in the Idle pose (the rest pose is the T-pose) and every accessory, the ones it does not wear hidden. Its clips are actions: pick one in the Action Editor (Dope Sheet > Action); their events are markers.

## The props and the finishes

| Prop | Triangles | Size w x d x h (m) | Spots | Lights |
|---|---|---|---|---|
| Station Bench | 204 | 2 x 0.56 x 0.8 | Seat1 (SEAT), Seat2 (SEAT), Seat3 (SEAT) | none |
| Station Lamp | 170 | 0.36 x 0.36 x 0.83 | none | Lamp |

Finishes: `ceiling_paint_station`, `floor_terrazzo_station`, `wall_paint_station`, `window_glass_day` (seamless, 2 x 2 m a tile at 64 px per metre). In Godot the demo lays them over the free room pieces' wallpaper, carpet, plaster and night glass (`demo/hall.gd`); use them in your own rooms as you like.

In Godot each prop is a scene in `props/` with its collision boxes, its spots and its lights (no shadows); for the other engines, `Data/spots.csv` and `Data/lights.csv` give them in the prop's GLB and FBX space (metres, +Y up, the prop's front +Z).

## The people's content

Ordinary adults in everyday clothes; no children. Hit and Fall are there for games whose bystanders are in danger: no blood, no injury, no weapon. No brand, logo or lettering on anyone.

## License

Use in unlimited personal and commercial projects. Edit freely. Do not resell or redistribute the assets themselves. Credit appreciated but not required. See LICENSE.txt.

## Works with

- PSX Horror Villagers: villagers on the same 28-bone skeleton, so the clips play on both: by day they are Bystanders, by night they hunt: https://cordatix.itch.io/psx-horror-villagers
- Liminal PSX Office Props: chairs, lobby seats (0.45 m) and desks (0.74 m) at the heights the seated and desk clips fit: https://cordatix.itch.io/liminal-psx-office-props

## More Cordatix packs

- PSX Bystanders NPC Pack, the full pack (20 people in 60 looks): https://cordatix.itch.io/psx-bystanders-npc-pack
- Cordatix PSX Mega Pack: every paid Cordatix pack, present and future, in one purchase: https://cordatix.itch.io/cordatix-psx-mega-pack
- Standalone Packs: the packs that fit any world, on one page: https://itch.io/c/8378189/standalone-packs
- Cordatix Sampler Box: every free Cordatix sampler in one place: https://cordatix.itch.io/cordatix-sampler-box

Used this pack in your game? A rating on its itch.io page helps other developers find it: https://cordatix.itch.io/psx-bystanders-npc-pack-free/rate

Made with procedural code and AI assistance, checked with automated tests and in-engine renders.
