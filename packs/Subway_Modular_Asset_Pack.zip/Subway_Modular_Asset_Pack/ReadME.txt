Hello, thank you for using my asset pack!

Include 59 ASSETS: 

- BEAM
- BENCH HALL
- BENCH METRO
- BENCH TOILET
- CEILING (11 various types)
- DOOR
- DOORWAY
- EMERGENCY EXIT
- FLOOR
- FLUSH TOILET
- GATE
- GRAVEL BASE
- HAND DRYER
- LADDER
- LADDER PLATFORM
- LAMP
- LID TOILET
- MIRROR (3 various types)
- PILLAR 
- PIPE (6 various types)
- PLATFORM EDGE (3 various types)
- RAILS 
- SINK TOILET (3 various types)
- TOILET DOOR
- TOILET PAPER HOLDER 
- TOILET WALL (2 various types)
- TRASH CAN 
- VENDING MACHINE (3 various types)
- WALL (6 various types)

_________________________________________

Note on AI & Materials: Generative AI was used only for the graphics and textures of the Vending Machine assets. 
All other textures and materials used in this pack were sourced from ambientCG (under CC0 licensing). 
All 3D models were completely hand-crafted.
