PSX Abandoned Hospital - Modular Low Poly Horror Pack  -  Free edition  (v1.0)
by Imersa Studios  -  https://imersastudios.itch.io

FOLDERS
  Textures/   every PNG texture, shared by all formats (keep it next to the model folders)
  FBX/        one .fbx per model, sorted in Building/, Props/, Decals/ and Assembled/
  glTF/       the same models as .gltf + .bin (textures point to ../Textures)
  OBJ/        the same models as .obj + .mtl (single models only)
  Blender/    PSX_Abandoned_Hospital_Free.blend: scene ASSETS (every model laid out by category),
              scene PREFABS (rooms + corridor modules) and the assembled scene.

MODELS (56)
  Building kit (walls, floors, ceilings, doors, exterior) (20): Ceiling Tile 2×2, Ceiling Tile Light 2×2, Ceiling Tile Missing 2×2, Door Swing, Door Wood, Door Wood Window, Floor Sheet 2×2, Floor VCT 2×2, Floor VCT 4×4, Handrail 2m, Hall 2m, Hall 4m, Hall Corner, Hall Door, Hall Double Door, Hall Opening, Hall Window, Ward 2m, Ward Door, Ward Window
  Medical (10): Bed A, Bed B, Bed C, Bedside Cabinet A, Bedside Cabinet B, IV Pole A, Overbed Table A, Stretcher A, Stretcher B, Wheelchair
  Furniture (3): Beam Seating 3, Chair Guest A, Chair Guest B
  Office (2): Paper A, Paper B
  Fixtures (7): Blinds A, Blinds B, Curtain A, Exit Sign, Overbed Light A, Radiator, Wall Clock
  Architecture details (pipes, duct, ceiling debris) (2): ARC Ceiling Debris, ARC Pipe Run 2m
  Misc props (4): Bin A, Pillow A, Plush Toy A, Poster A
  Debris (4): Cardboard, Ceiling Tile A, Plaster, Wood Plank
  Decals (4): Dirt Floor, Graffiti Dont Leave, Paper Scatter, Water Stain

ASSEMBLED ROOMS (2): Patient Room, Private Room
CORRIDOR MODULES (5): Corner, Door L, Door R, Straight, T
ASSEMBLED SCENE: Demo_Free: an L-shaped wing (16 m corridor + 8 m branch) with three patient rooms and two private rooms

HOW THE KIT WORKS
  - Real-world metres. Everything snaps on a 2 m grid; walls are 3 m high (exterior 4 m with parapet).
  - Wall panels are 10 cm thick and sit on the LEFT of their run: the finished face points +Y in Blender.
    A wall between two spaces is two panels back to back, so each side keeps its
    own finish and there are no coplanar faces (no z-fighting).
  - Doors: 1.2 x 2.3 m opening centred in a 2 m panel; double doors 2.4 x 2.5 m in a 4 m panel.
    Door leaves pivot on the hinge: place them at the panel origin + 0.4 m (double: + 0.8 m and + 3.2 m).
  - Floors are 2 x 2 / 4 x 4 m with their top at 0. Ceiling tiles sit at 3.0 m.
  - Every room prefab has its door on its front wall, so it fits any corridor door module.
  - Corridor modules are 4 m wide; corners / T / cross / end are 4 x 4 m, straight pieces 2 m long.
  - Assembled rooms and scenes are exported as one root with every piece as a child, so they stay editable.
  - Low-res PSX textures: use point / nearest filtering in your engine for the crunchy look.
    Unity: Filter Mode = Point. Godot: Texture Filter = Nearest. Unreal: Filter = Nearest.

Questions or requests: leave a comment on the itch.io page.
